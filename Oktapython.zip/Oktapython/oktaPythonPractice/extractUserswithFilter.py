'''
Created on Oct 11, 2018

@author: sumanth.raichur
'''
import requests
import json
import milestokmfunction
import rectareafunction
import csv
import os

def GETObject(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def PUTRequest(url):
    response = requests.request("PUT",url, headers=headers,verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response

def Enquiry(lis1):
    if len(lis1) == 0:
        return 0
    else:
        return 1
#============ MY DEV  API TOKEN ==================================================
headers = {
    'Accept': "application/json",
    'Content-Type': "application/json",
    'Authorization': "SSWS 00ajIu_pDtYFXCQYKq1FFhJkrrvI8gUE6t8FK_fBG0"
    }
orgName = "dev-397928.oktapreview"

#===============================================================================
# #============ SIT API TOKEN ==================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
#     }
# 
# 
# fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\AppAssignment.csv'
# orgName="mlclimited-sit.oktapreview"
#===============================================================================

fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\MLC Docs\\ActiveCardHolder.csv'
#listManagerUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(dict[managerId])+"\")"
#========================== Reading CSV file ================================================
with open(fileName) as csv_file:
    csv_reader = csv.DictReader(csv_file, delimiter=',')
    line_count = 1
    for row in csv_reader:
        
        empId = row['Employee ID']
        print("Count == "+str(line_count))
        line_count=line_count+1
        print("User Login is =="+str(empId))
        
        
        #============== START Code to get User ID ==================
        listUserUrl = "https://" + orgName + ".com/api/v1/users?search=profile.employeeNumber eq \""+str(empId)+"\""#employeeNumber,nabEmployeeID
        userData = GETObject(listUserUrl)
        print("User List is =="+str(userData))
        with open("C:\\Users\\s.anand.raichur\\Desktop\\Python\\MLC Docs\\ActiveCardwithemail.csv", 'a',newline='') as csvfile:
            filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
            filewriter.writerow(['User ID','User Login','E-mail','Employee ID'])
            for user in userData:
                userId=user["id"]
                print("User ID is =="+str(userId))
                userLogin=user["profile"]['login']
                print("User Login is =="+str(userLogin))
                useremail=user["profile"]['email']
                print("User Email is =="+str(useremail))
                userempId = user["profile"]['nabEmployeeID']
                print("User EMP ID is =="+str(userempId))
        #============== END Code to get User ID ====================
