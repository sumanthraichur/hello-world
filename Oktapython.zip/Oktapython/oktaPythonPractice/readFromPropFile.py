'''
Created on Oct 23, 2018

@author: sumanth.raichur
'''
import configparser

config = configparser.ConfigParser()
config.sections()
config.read('config.properties')
config.sections()

#===============================================================================
# # print("Columns Names:")
# oktaLogger.info("Columns Names:")
#===============================================================================

for key in config['column']: 
    # print(key)
    column = config['column']
    #grpUrl = (column['grpUrl'])
    #ruleUrl = (column['ruleUrl'])
    fileName = (column['fileName'])
    cascadeGroupName = (column['cascadeGroupName'])
    filterUserLogin = (column['filterUserLogin'])
    userUrl = (column['userUrl'])
    userLogin = (column['userLogin'])
    appUrl = (column['appUrl'])
    oktaUrl = (column['oktaUrl'])
    notifyIP = (column['notifyIP'])
    notifyPort = (column['notifyPort'])
    notifyFromaddr = (column['notifyFromaddr'])
    notifyToaddr = (column['notifyToaddr'])
    mlcOktaUrl = (column['mlcOktaUrl'])
    mlcUserUrl = (column['mlcUserUrl'])
    orgName = (column['orgName'])
    attributeNameStatus = (column['attributeNameStatus'])
    attributeNameID = (column['attributeNameID'])
    attributeManager = (column['attributeManager'])
    attributeManagerID = (column['attributeManagerID'])
    attributePersonID = (column['attributePersonID'])
    attributeNameContractEndDate = (column['attributeNameContractEndDate'])
    attributeInitialLogin = (column['attributeInitialLogin'])
    sendUserPassword = (column['sendUserPassword'])
    search_base = (column['search_base'])
    hostName = (column['hostName'])
    username = (column['username'])
    search_filter = (column['search_filter'])
    ESBUserList = (column['ESBUserList'])
    PersonDetailsFromUAT = (column['PersonDetailsFromUAT'])
    attributeEmail = (column['attributeEmail'])
    attributeManagerEmail = (column['attributeManagerEmail'])
    attributeIsManager = (column['attributeIsManager'])
#===============================================================================
# 
# # print("\n")
# oktaLogger.info("\n")
# 
# # print("csvFile Attribute Name:")
# oktaLogger.info("csvFile Attribute Name:")
#===============================================================================

for key in config['csvFile']: 
    # print(key)
    # oktaLogger.info(key)
    csvFile = config['csvFile']
    groupName = (csvFile['groupName'])
    groupDescription = (csvFile['groupDescription'])
    groupType = (csvFile['groupType'])
    membershipRuleType = (csvFile['membershipRuleType'])
    cascadingGroupName = (csvFile['cascadingGroupName'])
    attributeRule = (csvFile['attributeRule'])
    manualMembershipAssignment = (csvFile['manualMembershipAssignment'])
    groupApplicationAssignment = (csvFile['groupApplicationAssignment'])
    jobFamily = (csvFile['jobFamily'])
    jobFunction = (csvFile['jobFunction'])
    jobRole = (csvFile['jobRole'])
