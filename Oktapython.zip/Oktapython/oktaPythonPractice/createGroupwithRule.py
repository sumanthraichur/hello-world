'''
Created on Oct 8, 2018

@author: sumanth.raichur
'''
import requests
import json
import milestokmfunction
import rectareafunction
import csv
import os
import oktaFunctions

#===============================================================================
# orgName = "dev-397928.oktapreview"
#===============================================================================

#===============================================================================
# #============PROD=======
# orgName = "mlcinsurance.okta"
#===============================================================================

#============TEST===============
orgName="mlclimited-test.oktapreview"

fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\GroupCreation.csv'
#========================== Reading CSV file ================================================
with open(fileName) as csv_file:
    csv_reader = csv.DictReader(csv_file, delimiter=',')
    line_count = 1
    for row in csv_reader:
        
        groupName = row['Group Name']
        groupDesc = row['Description']
        print("\n \nCount == "+str(line_count))
        line_count=line_count+1
        print("Group Name is == "+str(groupName))
        print("Group Description is == "+str(groupDesc))
         
        #=============== Create Group ======================
        groupUrl = "https://" + orgName + ".com/api/v1/groups"
        payload = "{\n  \"profile\": {\n    \"name\": \""+str(groupName)+"\",\n    \"description\": \""+str(groupDesc)+"\"\n  }\n}"
        grpCreated = oktaFunctions.POSTRequest(groupUrl, payload)
        print("Group   =========== "+str(grpCreated))
        if str(grpCreated)=="Error":
            print("Error : Group Not Created")
        else:
            grpId = grpCreated.get('id')
            print("Group ID is == "+str(grpId))
            
            
            #===================================================================
            # #================ Add Rule to Group ==================
            # ruleUrl = "https://" + orgName + ".com/api/v1/groups/rules"
            # rulePayload = "{\n    \"type\": \"group_rule\",\n    \"name\": \"Test Rule "+str(groupName)+"\",\n    \"conditions\": \n    {\n        \"people\": \n        {\n            \"users\": \n            {\n                \"exclude\": []\n            },\n            \"groups\": \n            {\n                \"exclude\": []\n            }\n        },\n        \"expression\": \n        {\n            \"value\": \"user."+fieldName+"==true\",\n            \"type\": \"urn:okta:expression:1.0\"\n        }\n    },\n    \"actions\": \n    {\n        \"assignUserToGroups\": \n        {\n            \"groupIds\": [\""+str(grpId)+"\"]\n        }\n    }\n}"
            # grpRuleCreated = oktaFunctions.POSTRequest(ruleUrl, rulePayload)
            # print("Group Rule  =========== "+str(grpRuleCreated))
            # if str(grpRuleCreated)!= "Error":
            #     ruleId = grpRuleCreated.get('id')
            #     print("Rule ID is == "+str(ruleId))
            #     #================ Activate Rule ==========================
            #     activateUrl = "https://" + orgName +".com/api/v1/groups/rules/"+str(ruleId)+"/lifecycle/activate"
            #     activatedRule = oktaFunctions.POSTActivateRequest(activateUrl)
            #     if str(activatedRule)=="Error":
            #         print("Rule Not Activated")
            #     else:
            #         print("Rule Activated Successfully")
            # else:
            #     print("Rule Not Created")
            #===================================================================
        
        