'''
Created on Sep 25, 2018

@author: sumanth.raichur
'''
import requests
import json

import csv
import os

def GETObject(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
 
def PUTRequest(url):
    response = requests.request("PUT",url, headers=headers,verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response
 
def Enquiry(lis1):
    if len(lis1) == 0:
        return 0
    else:
        return 1
#===============================================================================
# #============ MY DEV  API TOKEN ==================================================
# headers = {
#     'Accept': "application/json",
#     'Content-Type': "application/json",
#     'Authorization': "SSWS 00ajIu_pDtYFXCQYKq1FFhJkrrvI8gUE6t8FK_fBG0"
#     }
#  
#  
# #===============================================================================
#===============================================================================

#============ TEST API TOKEN ==================================================
headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00JT2qgS1sAdPTBIqLqNmC0l4miMh1w_qXd5dIFfdw"
    }
fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\NewUsers.csv'
orgName="mlclimited-test.oktapreview"

#===============================================================================
# #============ SIT API TOKEN ==================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
#     }
#    
#   
# fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\REPAGroups.csv'
# orgName="mlclimited-sit.oktapreview"
#===============================================================================

#===============================================================================
# #============ PROD API TOKEN =================================================
# headers = {
#      'accept': "application/json",
#      'content-type': "application/json",
#      'authorization': "SSWS 00MicNpvJD6Ekwxuc1_J6-KDvlfdjt-gb_EFX8lY21"
#      #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
#      }
# orgName = "mlcinsurance.okta"
# fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\REPAGroups.csv'
#===============================================================================

#========================== Reading CSV file ================================================
with open(fileName) as csv_file:
    csv_reader = csv.DictReader(csv_file, delimiter=',')
    line_count = 1
    #===========================================================================
    # with open("C:\\Users\\s.anand.raichur\\Desktop\\REPAGroupIDs.csv", 'a',newline='') as csvfile:
    #     filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
    #     filewriter.writerow(['Group Name','Group ID'])
    #===========================================================================
    for row in csv_reader:
        
        userLogin = row['Login']
        print("Count == "+str(line_count))
        line_count=line_count+1
        #=======================================================================
        # print("User Login is =="+str(userLogin))
        #userLogin=userLogin+"@ad.mlclife.com.au"
        # userLogin=userLogin+"@mlcinsurance.com.au"
        #=======================================================================
        print("User Login is =="+str(userLogin))
        #============== START Code to get User ID ==================
        listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=profile.login eq \""+str(userLogin)+"\""
        #listUserUrl = "https://" + orgName + ".com/api/v1/users?q=\""+str(userLogin)+"\""
        #print("uRL ====== "+str(listUserUrl))
        userData = GETObject(listUserUrl)
        print("User List is =="+str(userData))
         
        for user in userData:
            userId=user["id"]
            print("User ID is =="+str(userId))
            print("\n \n")
             
        #============== END Code to get User ID ====================
        
        groupName = row['GroupName']
        print("Group Name is =="+str(groupName))
       
        # ============= START Code for Getting Group ID ======================================
        listgroupsUrl = "https://" + orgName + ".com/api/v1/groups?q="+str(groupName)
        groupsList = GETObject(listgroupsUrl)
         
        if Enquiry(groupsList):
            for group in groupsList:
                groupId=group["id"]
                print("Group ID is ==== "+str(groupId))
                #filewriter.writerow([groupName,groupId])
        # ============= END Code for Getting Group ID =========================================
                   
            #============== START Code to Assign Group to User ==================
            assignGroupsUrl="https://"+orgName+".com/api/v1/groups/"+str(groupId)+"/users/"+str(userId)
            response=PUTRequest(assignGroupsUrl)
            if response != "Error":
                print("User :: "+str(userLogin)+" added to :: "+str(groupName)+" group in Okta")
                        
            #============== END Code to Assign Group to User ==================
        else:
            with open("C:\\Users\\s.anand.raichur\\Desktop\\Groups.csv", 'a',newline='') as csvfile:
                filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
                filewriter.writerow([groupName])
    print('\n')        
print("Assigning Groups to Users Completed")
