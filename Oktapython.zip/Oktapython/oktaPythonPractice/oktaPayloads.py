'''
Created on Oct 19, 2018

@author: sumanth.raichur
'''
#AD Mapping Push Payload
def adPayLoad(sourceId, oktaTargetId, getFilteredGroups):
    adPayLoad = "{\r\n   \"sourceId\": \""+str(sourceId)+"\",\r\n   \"targetId\": \""+str(oktaTargetId)+"\",\r\n   \"propertyMappings\": [\r\n      {\r\n         \"targetField\": \"login\",\r\n         \"sourceExpression\": \"appuser.userName\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"firstName\",\r\n         \"sourceExpression\": \"appuser.firstName\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"lastName\",\r\n         \"sourceExpression\": \"appuser.lastName\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"middleName\",\r\n         \"sourceExpression\": \"appuser.middleName\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"email\",\r\n         \"sourceExpression\": \"String.len(appuser.email) > 0?String.stringContains(appuser.email,\\\"DEV-\\\")?appuser.email:\\\"DEV-\\\"+appuser.email:null\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"displayName\",\r\n         \"sourceExpression\": \"appuser.displayName\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"primaryPhone\",\r\n         \"sourceExpression\": \"appuser.telephoneNumber\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"preferredLanguage\",\r\n         \"sourceExpression\": \"appuser.preferredLanguage\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"passwordLastReset\",\r\n         \"sourceExpression\": \"appuser.pwdLastSet\",\r\n         \"pushStatus\": \"PUSH\"\r\n      },\r\n      {\r\n         \"targetField\": \"userGroupMembership\",\r\n         \"sourceExpression\": \""+str(getFilteredGroups)+"\",\r\n         \"pushStatus\": \"PUSH\"\r\n      }\r\n   ]\r\n}"
    return adPayLoad

#Okta Group Create Payload
def oktaGroupPayLoad(name, description):
    oktaGroupPayLoad = "{\n  \"profile\": {\n    \"name\": \""+str(name)+"\",\n    \"description\": \""+str(description)+"\"\n  }\n}"
    return oktaGroupPayLoad

#Group Push Payload
def groupPushPayLoad(userGroupId, distinguishedName, samAccountName):
    groupPushPayLoad = "{\r\n   \"status\": \"ACTIVE\",\r\n   \"userGroupId\": \""+str(userGroupId)+"\",\r\n   \"groupPushAttributes\": {\r\n      \"groupScope\": \"GLOBAL\",\r\n      \"groupType\": \"SECURITY\",\r\n      \"distinguishedName\": \""+str(distinguishedName)+"\",\r\n      \"samAccountName\": \""+str(samAccountName)+"\"\r\n   }\r\n}"
    return groupPushPayLoad

#Assign App to Group with Profile & Role Payload
def appTOGroupWithProfileRole(groupId, profile, role):
    appTOGroupWithProfileRole = "{\r\n   \"id\": \""+str(groupId)+"\",\r\n   \"profile\": {\r\n      \"profile\": \""+str(profile)+"\",\r\n      \"role\": \""+str(role)+"\"\r\n   }\r\n}\r\n\r\n"
    return appTOGroupWithProfileRole

#Assign App to Group with Profile & Role Payload
def updateRule(excludeUsers):
    updateRule = "{\r\n   \"type\": \"group_rule\",\r\n   \"status\": \"INACTIVE\",\r\n   \"id\": \"0prfr4wsr0EHddk7L0h7\",\r\n   \"name\": \"RECM Base Access\",\r\n   \"created\": \"2018-07-18T08:31:51.000Z\",\r\n   \"lastUpdated\": \"2018-07-18T08:31:51.000Z\",\r\n   \"allGroupsValid\": true,\r\n   \"conditions\": {\r\n      \"expression\": {\r\n         \"type\": \"urn:okta:expression:1.0\",\r\n         \"value\": \"isMemberOfAnyGroup(\\\"00gf42fno9T7Cm4yI0h7\\\")\"\r\n      },\r\n      \"people\": {\r\n         \"users\": {\r\n            \"exclude\": [\r\n               "+str(excludeUsers)+"\r\n            ]\r\n         },\r\n         \"groups\": {\r\n            \"exclude\": []\r\n         }\r\n      }\r\n   },\r\n   \"actions\": {\r\n      \"assignUserToGroups\": {\r\n         \"groupIds\": [\r\n            \"00gf7t58btAatu3WL0h7\",\r\n            \"00gf7su5620v0jW5R0h7\"\r\n         ]\r\n      }\r\n   },\r\n   \"_embedded\": {\r\n      \"groupIdToGroupNameMap\": {\r\n         \"00gf7t58btAatu3WL0h7\": \"SG-MLCL-RECM-UAT-Brava_Redact_TFN\",\r\n         \"00gf7su5620v0jW5R0h7\": \"SG-MLCL-RECM-UAT-Brava_Redact_CreditCard\",\r\n         \"00gf42fno9T7Cm4yI0h7\": \"SG-MLCL-RECM-UAT-User\"\r\n      }\r\n   }\r\n}"
    return updateRule

#Assign App to Group with Profile & Role Payload
def groupToAppAssignment(groupId):
    groupToAppAssignment = "{\"id\":\""+str(groupId)+"\"}"
    return groupToAppAssignment

#Group Rule Payload
def groupRule(ruleName,groupsId,assignToGroup):
    groupRule = "{\n        \"type\": \"group_rule\",\n        \"status\": \"INACTIVE\",\n        \"name\": \""+str(ruleName)+"\",\n        \"conditions\": {\n            \"expression\": {\n                \"value\": \"isMemberOfAnyGroup("+str(groupsId)+")\",\n                \"type\": \"urn:okta:expression:1.0\"\n            }\n        },\n        \"actions\": {\n            \"assignUserToGroups\": {\n                \"groupIds\": [\n                    "+str(assignToGroup)+"\n                ]\n            }\n        },\n        \"allGroupsValid\": true\n    }"
    return groupRule

#Okta External Group Push Payload
def oktaExternalGroupPushPayLoad(userGroupId):
    groupPushPayLoad = "{\"status\":\"ACTIVE\",\"userGroupId\":\""+str(userGroupId)+"\"}"
    return groupPushPayLoad

#Okta External Group Push Payload
def changeUsernamePayload(userId,userName,orgName,groupName,appId,groupId):
    groupPushPayLoad = payload = "{\r\n   \"id\": \""+str(userId)+"\",\r\n   \"externalId\": null,\r\n   \"scope\": \"GROUP\",\r\n   \"status\": \"ACTIVE\",\r\n   \"passwordChanged\": null,\r\n   \"syncState\": \"DISABLED\",\r\n   \"credentials\": {\r\n      \"userName\": \""+str(userName)+"\"\r\n   },\r\n   \"profile\": {},\r\n   \"_links\": {\r\n      \"app\": {\r\n         \"href\": \"https://"+orgName+".com/api/v1/apps/"+str(appId)+"\"\r\n      },\r\n      \"user\": {\r\n         \"href\": \"https://"+orgName+".com/api/v1/users/"+str(userId)+"\"\r\n      },\r\n      \"group\": {\r\n         \"name\": \""+str(groupName)+"\",\r\n         \"href\": \"https://"+orgName+".com/api/v1/groups/"+str(groupId)+"\"\r\n      }\r\n   }\r\n}"
    return groupPushPayLoad

