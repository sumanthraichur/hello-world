'''
Created on Oct 8, 2018

@author: sumanth.raichur
'''
try:
    import requests
    import sys
    import json
    from datetime import datetime
    from dateutil import tz
except:
    print("Please install okta/Python libaries. Refer to documentation for help :: Class Functions")
    sys.exit()

#===============================================================================
# #============ MY DEV  API TOKEN ==================================================
# headers = {
#     'Accept': "application/json",
#     'Content-Type': "application/json",
#     'Authorization': "SSWS 00ajIu_pDtYFXCQYKq1FFhJkrrvI8gUE6t8FK_fBG0"
#     }
#===============================================================================


#===============================================================================
# #============ DEV API TOKEN ===================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 00pCgoznpH2YD1vE4PFdHpFXCDm0ncUFUgIs90Hiih"
#     }
#===============================================================================


#===============================================================================
# #============ SIT API TOKEN ==================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA" #0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA
#     }
#===============================================================================


#============ TEST API TOKEN ==================================================
headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00JT2qgS1sAdPTBIqLqNmC0l4miMh1w_qXd5dIFfdw"
    }


#===============================================================================
# #============ PROD-SUP API TOKEN =================================================
# headers = {
#      'accept': "application/json",
#      'content-type': "application/json",
#      'authorization': "SSWS 00T8khxWUn2VUkRm1zcmNRcs-ot-KlMVH_0JSXVBZK"
#      #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
#      }
#===============================================================================


#===============================================================================
# #============ PROD API TOKEN =================================================
# headers = {
#      'accept': "application/json",
#      'content-type': "application/json",
#      'authorization': "SSWS 00MicNpvJD6Ekwxuc1_J6-KDvlfdjt-gb_EFX8lY21"
#      #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
#      }
#===============================================================================

#===============================================================================
# #============ Okta External PROD API TOKEN =================================================
# headers = {
#      'accept': "application/json",
#      'content-type': "application/json",
#      'authorization': "SSWS 006fAZyXLxqJVpmAyHLSEuu4G46XpgLrzP3unmzu2E"
#      }
#===============================================================================

def GETRequest(url, params):
    if params != "":
        response = requests.request("GET", url, params=params, headers=headers)
    else:
        response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    dictList = []
    for key, value in responseList.items():
        dictList.append([key,value])
    returnResponseList = returnResponseList+dictList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
    
    
def GETObject(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
    
def GETGroupRequest(url, params):
    if params != "":
        response = requests.request("GET", url, params=params, headers=headers)
    else:
        response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            print ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers,verify=False)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers,verify=False)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()
    
def POSTRuleRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response
    
def POSTActivateRequest(url):
    response = requests.request("POST", url, headers=headers,verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response

def PUTRequest(url,data):
    if data!="":
        response = requests.request("PUT",url, data=data,headers=headers)
    else:
        response = requests.request("PUT",url, headers=headers)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()
    
def PUTmappingRequest(url, data):
    response = requests.request("PUT",url, data=data, headers=headers)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response
    
def DELETEuser(url):
    response = requests.request("DELETE", url, headers=headers)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response

def POSTRequestPassword(url, querystring):
    if querystring != "":
        response = requests.post(url, headers=headers, params=querystring)
        response = "[" + response.text + "]"
        json_response = json.loads(response)
        for item in json_response:
            seacrhPassword = item['tempPassword']
            passwordList = []
            passwordList = seacrhPassword
        return passwordList

def remafterellipsis(text):
    where_ellipsis = text.find('+')
    if where_ellipsis == -1:
        return text
    return text[:where_ellipsis]
   
def LDAPToHumanTime(time):
    if time!=0:
        to_zone = tz.gettz('Australia/Sydney')
        humanTime = datetime.fromtimestamp((time - 116444736000000000) // 10000000)
        humanTime = str(humanTime)
        humanTime=datetime.strptime(humanTime, '%Y-%m-%d %H:%M:%S')
        humanTime = str(humanTime.astimezone(to_zone))
        humanTime = remafterellipsis(humanTime)
        humanTime = humanTime + str(" AEDT")
    else:
        humanTime = "None"
    return humanTime

def Enquiry(lis1):
    if len(lis1) == 0:
        return 0
    else:
        return 1