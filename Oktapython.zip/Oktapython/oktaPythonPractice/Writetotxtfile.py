'''
Created on Sep 21, 2018

@author: sumanth.raichur
'''
ids=["B1","\nB2","\nB3","\nB4"]
with open("C:\\Users\\s.anand.raichur\\Desktop\\Python\\testing.txt", 'w') as file:
    for id in ids:
        file.write(id)
print("File Write Completed")
file=open("C:\\Users\\s.anand.raichur\\Desktop\\Python\\testing.txt", 'r')
content=file.read()
print(content)