'''
Created on Sep 20, 2018

@author: sumanth.raichur
'''
def milestokms(miles):
    kms=miles*1.609344
    return kms