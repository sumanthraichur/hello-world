import requests
import json
import milestokmfunction
import rectareafunction
import csv
import os
import oktaFunctions


#===============================================================================
# #============ SIT API TOKEN ==================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
#     }
#===============================================================================

#===============================================================================
# headers = {
#     'Accept': "application/json",
#     'Content-Type': "application/json",
#     'Authorization': "SSWS 00pCgoznpH2YD1vE4PFdHpFXCDm0ncUFUgIs90Hiih",
#     'Cache-Control': "no-cache",
#     'Postman-Token': "4bc90813-e19b-47fb-a58a-72074b80ead9"
#     }
#===============================================================================

#orgName = "mlclimited.oktapreview" #"dev-397928.oktapreview"
#orgName = "dev-397928.oktapreview"

#============SIT============
orgName="mlclimited-sit.oktapreview"

#===============================================================================
# #==============PROD==============
# orgName = "mlcinsurance.okta"
#===============================================================================
#listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\")"
listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\" or status eq \"STAGED\" or status eq \"DEPROVISIONED\" or status eq \"RECOVERY\" or status eq \"LOCKED_OUT\" or status eq \"PASSWORD_EXPIRED\")"
response = oktaFunctions.GetPaginatedResponse(listUserUrl)
#===============================================================================
# returnResponseList = []
# returnResponseList = response
#===============================================================================

    
with open("C:\\Users\\s.anand.raichur\\Desktop\\Python\\SITUsers261018.csv", 'w',newline='') as csvfile:
    filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
    filewriter.writerow(['User Login','User ID','Status','MLC User Status','MLC User ID','Manager','Manager ID','Person ID','Creation Date','Modified Date','Start Date','Employee Number','First Name','Middle Name','Last Name','Display Name',
                         'E-mail','Second E-mail','User Type','Location','Business Unit','Title','Mobile Phone',
                         'Street Address','City','State','zipCode','Country','Country Code','Organization',
                         'Department','Gender','Initial Login','isHCMUser','jobCode','Custom ID','Custom Status'])
    for user in response:
        userId = user["id"]
        userstatus=user["status"]
        creationDate=user["created"]
        modifiedDate=user["lastUpdated"]
        profile= user["profile"]
        login = profile['login']
        firstName=user["profile"]['firstName']
        if ('middleName' in profile):
            middleName=user["profile"]['middleName']
        else:
            middleName=""
        lastName=user["profile"]['lastName']
        email=user["profile"]['email']
        if ('location' in profile):
            location=user["profile"]['location']
        else:
            location=""
        if ('businessUnit' in profile):
            businessUnit=user["profile"]['businessUnit']
        else:
            businessUnit=""
        if ('title' in profile):
            title=user["profile"]['title']
        else:
            title=""
        if ('displayName' in profile):
            displayName=user["profile"]['displayName']
        else:
            displayName=""
        secondEmail=user["profile"]['secondEmail']
        mobilePhone=user["profile"]['mobilePhone']
        if ('streetAddress' in profile):
            streetAddress=user["profile"]['streetAddress']
        else:
            streetAddress=""
        if ('city' in profile):
            city=user["profile"]['city']
        else:
            city=""
        if ('state' in profile):
            state=user["profile"]['state']
        else:
            state=""
        if ('zipCode' in profile):
            zipCode=user["profile"]['zipCode']
        else:
            zipCode=""
        if ('countryCode' in profile):
            countryCode=user["profile"]['countryCode']
        else:
            countryCode=""
        if ('userType' in profile):    
            userType=user["profile"]['userType']
        else:
            userType=""
        if ('employeeNumber' in profile):
            employeeNumber=user["profile"]['employeeNumber']
        else:
            employeeNumber=""
        if ('organization' in profile):
            organization=user["profile"]['organization']
        else:
            organization=""
        if ('department' in profile):
            department=user["profile"]['department']
        else:
            department=""
        if ('managerId' in profile):    
            managerId=user["profile"]['managerId']
        else:
            managerId=""
        if ('gender' in profile):
            gender=user["profile"]['gender']
        else:
            gender=""
        if ('country' in profile):
            country=user["profile"]['country']
        else:
            country=""
        if ('mlcUserStatus' in profile):
            mlcUserStatus=user["profile"]['mlcUserStatus']
        else:
            mlcUserStatus=""
        if ('startDate' in profile):    
            startDate=user["profile"]['startDate']
        else:
            startDate=""
        if ('PersonId' in profile):    
            PersonId=user["profile"]['PersonId']
        else:
            PersonId=""
        if ('initialLogin' in profile):
            initialLogin=user["profile"]['initialLogin']
        else:
            initialLogin=""
        if ('isHCMUser' in profile):
            isHCMUser=user["profile"]['isHCMUser']
        else:
            isHCMUser=""
        if ('jobCode' in profile):
            jobCode=user["profile"]['jobCode']
        else:
            jobCode=""
        if ('customID' in profile):
            customID=user["profile"]['customID']
        else:
            customID=""
        if ('customStatus' in profile):
            customStatus=user["profile"]['customStatus']
        else:
            customStatus=""
        if('manager' in profile):
            manager = user["profile"]['manager']
        else:
            manager=""
        if ('mlcUserId' in profile):
            mlcUserId=user["profile"]['mlcUserId']
        else:
            mlcUserId=""
            
        filewriter.writerow([login,userId,userstatus,mlcUserStatus,mlcUserId,manager,managerId,PersonId,creationDate,modifiedDate,startDate,employeeNumber,firstName,middleName,lastName,displayName,
                                         email,secondEmail,userType,location,businessUnit,title,mobilePhone,
                                         streetAddress,city,state,zipCode,country,countryCode,organization,department,gender,
                                         initialLogin,isHCMUser,jobCode,customID,customStatus])
        
        #=======================================================================
        # if ('isHCMUser' not in profile):
        #     if('employeeType' in profile):
        #         employeeType = user["profile"]['employeeType']
        #         if employeeType == "Contingent Worker":
        #             filewriter.writerow([userId,userstatus,mlcUserStatus,mlcUserId,employeeType,creationDate,modifiedDate,startDate,employeeNumber,PersonId,login,firstName,middleName,lastName,displayName,
        #                                  email,secondEmail,userType,managerId,location,businessUnit,title,mobilePhone,
        #                                  streetAddress,city,state,zipCode,country,countryCode,organization,department,gender,
        #                                  initialLogin,isHCMUser,jobCode,customID,customStatus])
        #=======================================================================
        
        #=======================================================================
        # else:
        #     employeeType=""
        #     filewriter.writerow([userId,userstatus,mlcUserStatus,mlcUserId,employeeType,creationDate,modifiedDate,startDate,employeeNumber,PersonId,login,firstName,middleName,lastName,displayName,
        #                                  email,secondEmail,userType,managerId,location,businessUnit,title,mobilePhone,
        #                                  streetAddress,city,state,zipCode,country,countryCode,organization,department,gender,
        #                                  initialLogin,isHCMUser,jobCode,customID,customStatus])
        #  
        #=======================================================================
    
