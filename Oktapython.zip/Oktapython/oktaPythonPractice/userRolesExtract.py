'''
Created on Oct 3, 2018

@author: sumanth.raichur
'''
import requests
import json
import milestokmfunction
import rectareafunction
import csv
import os

def GETObject(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def Enquiry(lis1):
    if len(lis1) == 0:
        return 0
    else:
        return 1
    
def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        print("\nYou encountered following Error: \n")
        print(responseJSON)
        print ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            print ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

#===============================================================================
# headers = {
#     'Accept': "application/json",
#     'Content-Type': "application/json",
#     'Authorization': "SSWS 00ajIu_pDtYFXCQYKq1FFhJkrrvI8gUE6t8FK_fBG0",
#     'Cache-Control': "no-cache",
#     'Postman-Token': "a61ca360-633d-4660-8301-29bc4e6e3821"
#     }
# 
# orgName = "dev-397928.oktapreview"
#===============================================================================

#============ SIT API TOKEN ==================================================
headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
    }
 
 
fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\UserRolesSITnew.csv'
orgName="mlclimited-sit.oktapreview"
listUserUrl = "https://" + orgName + ".com/api/v1/users/"
response = GetPaginatedResponse(listUserUrl)

    
with open(fileName, 'w',newline='') as csvfile:
    filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
    filewriter.writerow(['User ID','User Login','First Name','Last Name','E-mail','Roles'])
    for user in response:
        userId = user["id"]
        
        listUserGroupsUrl = "https://" + orgName + ".com/api/v1/users/"+str(userId)+"/groups"
        groupResponse = GETObject(listUserGroupsUrl)
        if Enquiry(groupResponse):
            for group in groupResponse:
                groupId=group["id"]
                groupName=group["profile"]['name']
                profile= user["profile"]
                login = profile['login']
                firstName=user["profile"]['firstName']
                lastName=user["profile"]['lastName']
                email=user["profile"]['email']
                filewriter.writerow([userId,login,firstName,lastName,email,groupName])
        else:
            groupName=""
            profile= user["profile"]
            login = profile['login']
            firstName=user["profile"]['firstName']
            lastName=user["profile"]['lastName']
            email=user["profile"]['email']
            filewriter.writerow([userId,login,firstName,lastName,email,groupName])
        
    
