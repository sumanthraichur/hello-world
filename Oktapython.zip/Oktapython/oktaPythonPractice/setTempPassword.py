'''
Created on Sep 26, 2018

@author: sumanth.raichur
'''
import requests
import json
import csv
import string
from random import choice
from errno import errorcode


def GETObject(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
    
def POSTObject(url,queryString):
    response = requests.request("POST", url, headers=headers,params=queryString)
    if "errorCode" in response:
        print ("\nYou encountered following Error: \n")
        print (response)
        print ("\n")
        return "Error"
    else:
        return response.text
    

def GenPasswd2(length, chars):
    return '1'.join([choice(chars) for i in range(length)])

def PUTRequest(setPwdUrl,payload):
        response = requests.request("PUT",setPwdUrl, data=payload, headers=headers)
        responseJSON = response
        if "errorCode" in responseJSON:
            print ("\nYou encountered following Error: \n")
            print (responseJSON)
            print ("\n")
            return "Error"
        else:
            return response
    
headers = {
    'Accept': "application/json",
    'Content-Type': "application/json",
    'Authorization': "SSWS 00ajIu_pDtYFXCQYKq1FFhJkrrvI8gUE6t8FK_fBG0"
    }

orgName = "dev-397928.oktapreview"
#/lifecycle/expire_password"?filter=profile.login eq \""+str(userLogin)+"\""

with open("C:\\Users\\s.anand.raichur\\Desktop\\Python\\SetTempPwdUsers.csv") as csv_file:
    csv_reader = csv.DictReader(csv_file, delimiter=',')
    line_count = 1
    with open("C:\\Users\\s.anand.raichur\\Desktop\\Python\\UserPasswords.csv", 'w',newline='') as csvfile:
        filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
        filewriter.writerow(['User ID','Password'])
        print("File Write Start")
        for row in csv_reader:
            line_count=line_count+1
            userLogin = row['Username']
            print("User Login is =="+str(userLogin))
            
            #============== START Code to get User ID ==================
            listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=profile.login eq \""+str(userLogin)+"\""
            userData = GETObject(listUserUrl)
        
            for user in userData:
                userId=user["id"]
                print("User ID is =="+str(userId))
            #============== END Code to get User ID ====================
            
            #=======================================================================
            # #============== START Code to set Temp Password ==================
            # queryString={"tempPassword":"true"}
            # tempPwdUrl = "https://" + orgName + ".com/api/v1/users/"+str(userId)+"/lifecycle/expire_password"
            # print(tempPwdUrl)
            # response=POSTObject(tempPwdUrl, queryString)
            # print(response)
            # #============== END Code to set Temp Password ==================
            #=======================================================================
            
            password = GenPasswd2(5, string.ascii_uppercase+string.ascii_lowercase+string.digits)
            print(password)
            setPwdUrl = "https://" + orgName + ".com/api/v1/users/"+str(userId)
            payload = "{\n  \"credentials\": {\n    \"password\" : { \"value\": \""+str(password)+"\" }\n  }\n}"
            response=PUTRequest(setPwdUrl, payload)
            
            if "errorCode" in response.text:
                print("Failure")
            else:
                print("Success, write to file")
                filewriter.writerow([userLogin,password])
print("Complete")
                
        