'''
Created on Sep 20, 2018

@author: sumanth.raichur
'''
def rectarea(len,bred):
    area=len*bred
    return area