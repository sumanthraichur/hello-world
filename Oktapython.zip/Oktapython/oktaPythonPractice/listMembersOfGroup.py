'''
Created on Oct 19, 2018

@author: sumanth.raichur
'''
import requests
import json
import milestokmfunction
import rectareafunction
import csv
import os
import oktaFunctions

#===============================================================================
# #=========My Dev============
# orgName = "dev-397928.oktapreview"
#===============================================================================

#===============================================================================
# #============PROD=======
# orgName = "mlcinsurance.okta"
#===============================================================================

#============SIT==========
orgName="mlclimited-sit.oktapreview"

readfileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\Groups.csv'
writefileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\TaleoGroupListSIT.csv'
#========================== Reading CSV file ================================================
with open(readfileName) as csv_file:
    csv_reader = csv.DictReader(csv_file, delimiter=',')
    line_count = 1
    with open(writefileName, 'w',newline='') as csvfile:
        filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
        filewriter.writerow(['Group ID','Group Name','Group Description'])
        for row in csv_reader:
            groupName = row['Group Name']
            
            # ============= START Code for Getting Group ID ======================================
            listgroupsUrl = "https://" + orgName + ".com/api/v1/groups?q="+str(groupName)
            groupsList = oktaFunctions.GETObject(listgroupsUrl)
            if oktaFunctions.Enquiry(groupsList):
                for group in groupsList:
                    groupId=group["id"]
                    print("Group ID is ==== "+str(groupId))
                    groupDesc = group["profile"]['description']
                    filewriter.writerow([groupId,groupName,groupDesc])
            # ============= END Code for Getting Group ID =========================================
            
            #===================================================================
            # # ============= START Code to list Group Members ======================================
            # listmembersUrl = "https://" + orgName + ".com/api/v1/groups/"+str(groupId)+"/users"
            # membersList = oktaFunctions.GETObject(listmembersUrl)
            # if oktaFunctions.Enquiry(membersList):
            #     for member in membersList:
            #         memberId=member["id"]
            #         memberLogin = member["profile"]['login']
            #         print("Member Login Before is === "+str(memberLogin))
            #         head , sep , tail = memberLogin.partition('@')
            #         memberLogin=head
            #         print("Member Login After is === "+str(memberLogin))
            #         filewriter.writerow([memberLogin,groupName])
            #===================================================================