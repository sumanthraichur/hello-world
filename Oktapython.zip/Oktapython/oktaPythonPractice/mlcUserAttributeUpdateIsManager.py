'''
Created on Oct 23, 2018

@author: sumanth.raichur
'''
try:
    import sys
    import readFromPropFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    import OktaApiTokDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = readFromPropFile.orgName #orgname
attributeNameStatus = readFromPropFile.attributeNameStatus #mlcUserStatus
attributeNameID = readFromPropFile.attributeNameID #mlcUserId
attributeManager = readFromPropFile.attributeManager #manager
attributeManagerID = readFromPropFile.attributeManagerID #managerId
attributeIsManager = readFromPropFile.attributeIsManager #isManager


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS "+ OktaApiTokDecrypt.apiKeyOktaDecoded
    }

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()
    
def GetObject(url):
    response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

def GETObject(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            logger.info ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
   
try:
    userSchemaUrl = "https://" + orgName + ".com/api/v1/meta/schemas/user/default"
    userSchema = GetObject(userSchemaUrl)
    baseAttributesList = userSchema["definitions"]["base"]["properties"]
    customAttributesList = userSchema["definitions"]["custom"]["properties"]
    if (((attributeNameStatus in baseAttributesList) or (attributeNameStatus in customAttributesList)) and ((attributeNameID in baseAttributesList) or (attributeNameID in customAttributesList))):
        listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\")"
        userList = GetPaginatedResponse(listUserUrl)
        dict = {}  # @ReservedAssignment
        for user in userList:
            profile = user['profile']
            if ("PersonId" in profile):
                dict[profile["PersonId"]] = profile["login"]
        for user in userList:
            userId = user["id"]
            profile = user['profile']
            login = profile['login']
            userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
            user_info = {}
            user_info['profile'] = {}
            # User coming from Oracle HCM where mlcUserStatus is always set to 'Active' and isHCMUser is always set to 'True' 
            if "isHCMUser" in profile:
                isHCMUser = profile['isHCMUser']
                if isHCMUser == True:
                    if ("mlcUserStatus" in profile):
                        mlcUserStatus = profile["mlcUserStatus"]
                        if (mlcUserStatus.upper() == "ACTIVE"):
                            if ("mlcUserId" not in profile):
                                logger.info("mlcUserStatus " + mlcUserStatus + " in profile but mlcUserId not in profile for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                                user_info['profile'] [attributeNameStatus] = user["status"]
                                user_info['profile'] [attributeNameID] = user["id"]
                                if("managerId" in profile) and ("PersonId" in profile) :
                                    managerId = profile["managerId"]
                                    PersonId = profile["PersonId"]
                                    if (managerId in dict.keys()):
                                        logger.info("User Login : " + profile["login"])
                                        logger.info("Manager ID : " + managerId)
                                        logger.info("Person ID : " + PersonId)
                                        logger.info("Manager Login: " + dict[managerId])
                                        listManagerUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(dict[managerId])+"\")"
                                        logger.info(listManagerUserUrl)
                                        managerUserList = GETObject(listManagerUserUrl)
                                        for managerInfo in managerUserList:
                                            managerUserId = managerInfo["id"]
                                            managerProfile = managerInfo['profile']
                                            managerUserUrl = "https://" + orgName + ".com/api/v1/users/" + str(managerUserId)
                                            managerUser_info = {}
                                            managerUser_info['profile'] = {}
                                            
                                            if("isManager" not in managerProfile):
                                                managerUser_info['profile'] [attributeIsManager] = True
                                                managerUser_info_json = json.dumps(managerUser_info)
                                                response = POSTRequest(managerUserUrl, managerUser_info_json)
                                                if response != "Error":
                                                    logger.info ("Attribute " + attributeIsManager + " Set to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                                    
                                            elif("isManager" in managerProfile):
                                                    isManager = managerProfile["isManager"]
                                                    if (isManager == True):
                                                        logger.info ("Attribute " + attributeIsManager + " is already set to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                                    elif (isManager != True):
                                                        managerUser_info['profile'] [attributeIsManager] = True
                                                        managerUser_info_json = json.dumps(managerUser_info)
                                                        response = POSTRequest(managerUserUrl, managerUser_info_json)
                                                        if response != "Error":
                                                            logger.info ("Attribute " + attributeIsManager + " already in manager profile, Setting it to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                        
                                        user_info['profile'] [attributeManager] = dict[managerId]
                                           
                                user_info_json = json.dumps(user_info)
                                response = POSTRequest(userUrl, user_info_json)
                                if response != "Error":
                                    logger.info ("Attribute " + attributeNameStatus + " Set to " + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                                    logger.info ("Attribute " + attributeNameID + " Set to " + str(user["id"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                                    logger.info ("Attribute " + attributeManager + " Set to " + str(dict[managerId]) + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                                    logger.info ("\n")
            
            # Contingent Worker :: Users not coming from Oracle HCM , manually created in Okta      
            elif "isHCMUser" not in profile:
                if "employeeType" in profile:
                    employeeType = profile['employeeType']
                    if employeeType == "Contingent Worker":
                        # Change to update mlcUserId for Contingent Worker
                        user_info['profile'] [attributeNameID] = user["id"]
                        user_info_json = json.dumps(user_info)
                        response = POSTRequest(userUrl, user_info_json)
                        if response != "Error":
                            logger.info ("Attribute " + attributeNameID + " Set to " + str(user["id"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                            logger.info ("\n")                        
                        if ("resourceOwner" in profile):
                            resourceOwner = profile['resourceOwner']
                            logger.info(str(resourceOwner)+ " is manager for Contingent Worker "+str(profile["firstName"]) + " " + str(profile["lastName"]))
                            if (resourceOwner != None) or (resourceOwner != ""):
                                if ("manager" not in profile):
                                    listManagerUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(resourceOwner)+"\")"
                                    listManagerUserList = GETObject(listManagerUserUrl)
                                    for managerUser in listManagerUserList:
                                        managerUserId = managerUser["id"]
                                        managerProfile = managerUser['profile']
                                        isHCMUser = managerProfile['isHCMUser']
                                        if isHCMUser == True:
                                            logger.info("isHCMUser value for  "+str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"])+" is TRUE, so updating manager value")
                                            managerUserUrl = "https://" + orgName + ".com/api/v1/users/" + str(managerUserId)
                                            managerUser_info = {}
                                            managerUser_info['profile'] = {}
                                            user_info['profile'] [attributeManager] = resourceOwner
                                            user_info_json = json.dumps(user_info)
                                            response = POSTRequest(userUrl, user_info_json)
                                            if response != "Error":
                                                logger.info ("Attribute " + attributeManager + " Set to " + str(resourceOwner) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                                            
                                            if ("isManager" in managerProfile):
                                                if managerProfile ['isManager'] != True:
                                                    managerUser_info['profile'] [attributeIsManager] = True
                                                    managerUser_info_json = json.dumps(managerUser_info)
                                                    response = POSTRequest(managerUserUrl, managerUser_info_json)
                                                    if response != "Error":
                                                        logger.info ("Attribute isManager Setting to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                                else:
                                                    logger.info ("Attribute isManager is already TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                            else:
                                                managerUser_info['profile'] [attributeIsManager] = True
                                                managerUser_info_json = json.dumps(managerUser_info)
                                                response = POSTRequest(managerUserUrl, managerUser_info_json)
                                                if response != "Error":
                                                    logger.info ("Attribute isManager not present, so Setting to TRUE  for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                        
                                        elif isHCMUser != True:
                                            logger.info("isHCMUser value for  "+str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"])+" is FALSE, so not updating manager value")            
                                                    
                            else:
                                logger.info ("Attribute resourceOwner has null value for " + str(profile["firstName"]) + " " + str(profile["lastName"]))            
                            logger.info ("\n")
    else:
        logger.info ("Attribute " + attributeNameStatus + " Not Found in User Schema. Please Create and Try Again.")
        logger.info ("Attribute " + attributeNameID + " Not Found in User Schema. Please Create and Try Again.")

except Exception as e:
    logger.info(traceback.format_exc())
