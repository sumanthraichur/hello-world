'''
Created on Oct 19, 2018

@author: sumanth.raichur
'''
import json
import csv
import oktaFunctions
responseJSON = json.dumps({
    "itemsPerPage": 307,
    "startIndex": 1,
    "Resources": [
        {
            "id": "D231108EF25A4342ACF7708CDF110C7A",
            "meta": {
                "created": "2017-09-07 03:11:58.181",
                "lastModified": "2018-10-19 12:45:15.961",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D231108EF25A4342ACF7708CDF110C7A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ASM_APPLICATION_IMPLEMENTATION_CONSULTANT_JOB",
            "displayName": "Application Implementation Consultant",
            "description": "Manages enterprise-wide implementations. Collaborates with specific application administrators to implement consistent enterprise application setup, architecture, information, rules, and access. Has access to all setup tasks across all products.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "47DAAF938F2F7B5BE050F40A76AB350F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA2EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "8C3A4617A6C54C6482A6C59D14133907",
            "meta": {
                "created": "2017-09-07 03:11:58.190",
                "lastModified": "2018-10-19 12:45:15.972",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8C3A4617A6C54C6482A6C59D14133907"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GTG_COMPLIANCE_MANAGER_JOB",
            "displayName": "Compliance Manager",
            "description": "Individual responsible for managing enterprise compliance programs.",
            "category": "JOB"
        },
        {
            "id": "F20A63CFC030472B8BEA09F70DC44686",
            "meta": {
                "created": "2017-09-07 03:11:58.199",
                "lastModified": "2018-10-19 12:45:17.422",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F20A63CFC030472B8BEA09F70DC44686"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PON_CATEGORY_MANAGER_JOB",
            "displayName": "Category Manager",
            "description": "Procurement professional responsible for identifying savings opportunities, determining negotiation strategies, creating request for quote, request for information, request for proposal, or auction events on behalf of their organization and awarding future business typically in the form of contracts or purchase orders to suppliers.",
            "category": "JOB"
        },
        {
            "id": "A1467D5011214ACFBCD1BE12C32F355B",
            "meta": {
                "created": "2017-09-07 03:11:58.207",
                "lastModified": "2018-10-19 12:45:15.983",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A1467D5011214ACFBCD1BE12C32F355B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_CHANNEL_SALES_DIRECTOR_JOB",
            "displayName": "Channel Sales Director",
            "description": "Supervises channel roles to support partner relationships and transactions.",
            "category": "JOB"
        },
        {
            "id": "F56A4E789F15444A8CEEABF9A784A13B",
            "meta": {
                "created": "2017-09-07 03:11:58.273",
                "lastModified": "2018-10-19 12:45:17.449",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F56A4E789F15444A8CEEABF9A784A13B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_GRANTS_ADMINISTRATOR_JOB",
            "displayName": "Grants Administrator",
            "description": "Assists the principal investigator with the administrative functions of an award and its related projects, particularly with data collection and data entry tasks.",
            "category": "JOB"
        },
        {
            "id": "BE9EAE3C43584958907AB88EA0125263",
            "meta": {
                "created": "2017-09-07 03:11:58.283",
                "lastModified": "2018-10-19 12:45:15.993",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BE9EAE3C43584958907AB88EA0125263"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_LINE_MANAGER_ABSTRACT",
            "displayName": "Line Manager",
            "description": "Identifies the person as a line manager.",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE6AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE886E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "101BBD6CD97F4AD0852DF47A1B7B10A1",
            "meta": {
                "created": "2017-09-07 03:11:58.293",
                "lastModified": "2018-10-19 12:45:16.003",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/101BBD6CD97F4AD0852DF47A1B7B10A1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_RCS_SUPPLY_CHAIN_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Supply Chain Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of supply chain management information systems.",
            "category": "JOB"
        },
        {
            "id": "36C52F4B7BC54298B88E687D3D535AB9",
            "meta": {
                "created": "2017-09-07 03:11:58.303",
                "lastModified": "2018-10-19 12:45:16.016",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/36C52F4B7BC54298B88E687D3D535AB9"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CN_INCENTIVE_COMPENSATION_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Incentive Compensation Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of incentive compensation information systems.",
            "category": "JOB"
        },
        {
            "id": "2E324632CA4748A5B070F9334972893D",
            "meta": {
                "created": "2017-09-07 03:11:58.313",
                "lastModified": "2018-10-19 12:45:16.024",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2E324632CA4748A5B070F9334972893D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FOM_ORDER_ENTRY_SPECIALIST_JOB",
            "displayName": "Order Entry Specialist",
            "description": "Individual who is responsible for creating new orders, updating existing orders, and creating order returns.",
            "category": "JOB"
        },
        {
            "id": "A12CAE7F57FF4981B476655D2636D100",
            "meta": {
                "created": "2017-09-07 03:11:58.322",
                "lastModified": "2018-10-19 12:45:16.033",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A12CAE7F57FF4981B476655D2636D100"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CE_CASH_MANAGER_JOB",
            "displayName": "Cash Manager",
            "description": "Protects and develops the company's liquid assets maximizing their use and return to the organization.",
            "category": "JOB",
            "members": [
                {
                    "value": "5E305E87EF9463FDE050790A70402713"
                },
                {
                    "value": "5822400BEA39E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3DE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73192019E2E050790A704031FC"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "745217FBCD274A6081D0B813336BAC7F",
            "meta": {
                "created": "2017-09-07 03:11:58.331",
                "lastModified": "2018-10-19 12:45:16.041",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/745217FBCD274A6081D0B813336BAC7F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZCH_MASTER_DATA_MANAGEMENT_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Master Data Management Application Administrator",
            "description": "Administers the installation and maintenance of customer data management application and foundation model.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "C686E65E9B24405DBBF684D2A92F4CCC",
            "meta": {
                "created": "2017-09-07 03:11:58.339",
                "lastModified": "2018-10-19 12:45:16.050",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/C686E65E9B24405DBBF684D2A92F4CCC"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZSP_SALES_ANALYST_JOB",
            "displayName": "Sales Analyst",
            "description": "Identifies interesting sales trends and customer behavior insights useful to help the overall sales organization to target customers more effectively.",
            "category": "JOB"
        },
        {
            "id": "9643D76FC0D347E990DA178DECD5026B",
            "meta": {
                "created": "2017-09-07 03:11:58.347",
                "lastModified": "2018-10-19 12:45:17.466",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/9643D76FC0D347E990DA178DECD5026B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_QSC_SALES_CATALOG_ADMINISTRATOR_JOB",
            "displayName": "Sales Catalog Administrator",
            "description": "Sets up and maintains sales catalogs for leads, opportunities, quotes and orders. Sets up and maintains rollup catalog for the purpose of forecasting, territory management, and other purposes. Also associates products, promotions, and competitor products to catalogs, and defines eligibility rules. Also manages the bulk export and import of all product group-related objects.",
            "category": "JOB"
        },
        {
            "id": "87CA2BE4397D4D7A9D1757A9F82DD59C",
            "meta": {
                "created": "2017-09-07 03:11:58.356",
                "lastModified": "2018-10-19 12:45:17.477",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/87CA2BE4397D4D7A9D1757A9F82DD59C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_XCC_BUDGET_MANAGER_JOB",
            "displayName": "Budget Manager",
            "description": "Manages one or more control budgets, including relevant setup, budget loading, exception analysis, transactional overrides, and funds available analysis and reporting",
            "category": "JOB"
        },
        {
            "id": "2513294F8B4D4E2BBA2A9DDF8B9F6C8C",
            "meta": {
                "created": "2017-09-07 03:11:58.364",
                "lastModified": "2018-10-19 12:45:16.059",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2513294F8B4D4E2BBA2A9DDF8B9F6C8C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_BEN_BENEFITS_MANAGER_JOB",
            "displayName": "Benefits Manager",
            "description": "Manages implementation and administration of benefits business objects and batch processes.",
            "category": "JOB"
        },
        {
            "id": "A0AB87387B984CB9B905D3C64E828D28",
            "meta": {
                "created": "2017-09-07 03:11:58.372",
                "lastModified": "2018-10-19 12:45:17.489",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A0AB87387B984CB9B905D3C64E828D28"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_BEN_BENEFITS_SPECIALIST_JOB",
            "displayName": "Benefits Specialist",
            "description": "Manages administration of an individual employee's benefits using the service center and professional pages.",
            "category": "JOB"
        },
        {
            "id": "EB1697EC2A5345B3B03144EF59C0AB4C",
            "meta": {
                "created": "2017-09-07 03:11:58.380",
                "lastModified": "2018-10-19 12:45:16.067",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/EB1697EC2A5345B3B03144EF59C0AB4C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_BILLING_SPECIALIST_JOB",
            "displayName": "Project Billing Specialist",
            "description": "Job role that supports the project billing related requirements in a business",
            "category": "JOB"
        },
        {
            "id": "756C75310D2640398AE9682BFE0BEE32",
            "meta": {
                "created": "2017-09-07 03:11:58.388",
                "lastModified": "2018-10-19 12:45:16.075",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/756C75310D2640398AE9682BFE0BEE32"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HRC_HUMAN_CAPITAL_MANAGEMENT_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Human Capital Management Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of human capital management information systems.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "198A8A6E75984C4386A4D0746C41F7C3",
            "meta": {
                "created": "2017-09-07 03:11:58.397",
                "lastModified": "2018-10-19 12:45:17.498",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/198A8A6E75984C4386A4D0746C41F7C3"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EXM_EXPENSE_AUDITOR_JOB",
            "displayName": "Expense Auditor",
            "description": "Reviews and audits expense reports on a daily basis to ensure compliance with the company's reimbursement policy.",
            "category": "JOB"
        },
        {
            "id": "6317E6D545964EFB92D871F943369875",
            "meta": {
                "created": "2017-09-07 03:11:58.405",
                "lastModified": "2018-10-19 12:45:16.083",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6317E6D545964EFB92D871F943369875"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_CUSTOMER_CONTRACT_TEAM_MEMBER_ABSTRACT",
            "displayName": "Customer Contract Team Member",
            "category": "JOB"
        },
        {
            "id": "0F1E7EA8D1394F16BA0B5A75799CCCD5",
            "meta": {
                "created": "2017-09-07 03:11:58.414",
                "lastModified": "2018-10-19 12:45:17.507",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0F1E7EA8D1394F16BA0B5A75799CCCD5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PON_SUPPLIER_BIDDER_ABSTRACT",
            "displayName": "Supplier Bidder",
            "description": "Sales representative from a potential supplier responsible for responding to requests for quote, requests for proposal, requests for information and reverse auctions.",
            "category": "ABSTRACT"
        },
        {
            "id": "65AEA2ED2A67413788E67B14532C2BCA",
            "meta": {
                "created": "2017-09-07 03:11:58.423",
                "lastModified": "2018-10-19 12:45:16.094",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/65AEA2ED2A67413788E67B14532C2BCA"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_INV_WAREHOUSE_MANAGER_JOB",
            "displayName": "Warehouse Manager",
            "description": "Manages and analyzes all warehouse activities including analyzing materials management and logistics performance, managing inventory transactions, managing cycle and physical counts, configuring warehouse setup, and reviewing inventory balances.",
            "category": "JOB"
        },
        {
            "id": "2BBEB361DC66413392C5E3C1D00DDAEF",
            "meta": {
                "created": "2017-09-07 03:11:58.433",
                "lastModified": "2018-10-19 12:45:16.104",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2BBEB361DC66413392C5E3C1D00DDAEF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EXM_EXPENSE_AUDIT_MANAGER_JOB",
            "displayName": "Expense Audit Manager",
            "description": "Plans, leads, and controls the activities of the internal audit staff to achieve the objectives of the Internal Audit function for an organization.",
            "category": "JOB"
        },
        {
            "id": "3A71A0DF980745359C67305460C6484F",
            "meta": {
                "created": "2017-09-07 03:11:58.442",
                "lastModified": "2018-10-19 12:45:17.525",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3A71A0DF980745359C67305460C6484F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_VRM_REVENUE_ANALYST_JOB",
            "displayName": "Revenue Analyst",
            "description": "Manages and implements revenue adjustments, revenue recognition, revenue accounting, creation and processing of revenue documents, and the inquiry of revenue documents and adjustments. Also manages the defining of open and closed periods and transferring entries to the general ledger.",
            "category": "JOB"
        },
        {
            "id": "C1DE4B76F15245E588B2BFE4379607DE",
            "meta": {
                "created": "2017-09-07 03:11:58.450",
                "lastModified": "2018-10-19 12:45:17.516",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/C1DE4B76F15245E588B2BFE4379607DE"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PAY_PAYROLL_MANAGER_JOB",
            "displayName": "Payroll Manager",
            "description": "Manages all aspects of payroll business processes through setup, data entry, running payroll processes and reports, and verifying and correcting calculated results.",
            "category": "JOB"
        },
        {
            "id": "B334C898DE7B4DD08DFA9ACDEDC64C14",
            "meta": {
                "created": "2017-09-07 03:11:58.459",
                "lastModified": "2018-10-19 12:45:16.111",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B334C898DE7B4DD08DFA9ACDEDC64C14"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CZ_PRODUCT_CONFIGURATOR_MANAGER_JOB",
            "displayName": "Product Configurator Manager",
            "description": "Individual responsible for the creation and maintenance of configuration models.",
            "category": "JOB"
        },
        {
            "id": "B441E47D33204CA1ABD6D3CED4D45930",
            "meta": {
                "created": "2017-09-07 03:11:58.468",
                "lastModified": "2018-10-19 12:45:17.533",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B441E47D33204CA1ABD6D3CED4D45930"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZBS_SALES_ADMINISTRATOR_JOB",
            "displayName": "Sales Administrator",
            "description": "Manages sales department and personnel. Performs ongoing administrative tasks, corrects erroneous data, and configures the application according to business needs.",
            "category": "JOB"
        },
        {
            "id": "D2A4AFEFAC734783821F3D3E35FDBF8F",
            "meta": {
                "created": "2017-09-07 03:11:58.484",
                "lastModified": "2018-10-19 12:45:17.542",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D2A4AFEFAC734783821F3D3E35FDBF8F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FUN_FINANCIAL_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Financial Application Administrator",
            "description": "Manages financial application administration. Collaborates with financial application users to maintain consistent financial application setup, rules, and access.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E7EAEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "B8031F74F77949F39979694AD782691D",
            "meta": {
                "created": "2017-09-07 03:11:58.494",
                "lastModified": "2018-10-19 12:45:16.136",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B8031F74F77949F39979694AD782691D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_WIS_MANUFACTURING_ENGINEER_JOB",
            "displayName": "Manufacturing Engineer",
            "description": "Individual responsible for dealing with different manufacturing practices and processes, and for the research and development of systems, processes, machines, tools and equipment that turn raw material into a product.",
            "category": "JOB"
        },
        {
            "id": "4C285370E0D24171AC879ECB5F9A9141",
            "meta": {
                "created": "2017-09-07 03:11:58.505",
                "lastModified": "2018-10-19 12:45:17.550",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4C285370E0D24171AC879ECB5F9A9141"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AR_CREDIT_MANAGER_JOB",
            "displayName": "Credit Manager",
            "description": "Responsible for defining credit management policies and controls, and establishing credit limits. Responsible for management and oversight of credit management activities and authorizing credit exceptions.",
            "category": "JOB"
        },
        {
            "id": "136111E894D441489A7C9BC42EA76016",
            "meta": {
                "created": "2017-09-07 03:11:58.517",
                "lastModified": "2018-10-19 12:45:16.144",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/136111E894D441489A7C9BC42EA76016"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PO_PROCUREMENT_CONTRACT_ADMIN_JOB",
            "displayName": "Procurement Contract Administrator",
            "description": "Procurement professional responsible for creating, managing, and administering procurement contracts.",
            "category": "JOB"
        },
        {
            "id": "B6AF18F2CDFF4170A85AA0D590AC8461",
            "meta": {
                "created": "2017-09-07 03:11:58.528",
                "lastModified": "2018-10-19 12:45:16.151",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B6AF18F2CDFF4170A85AA0D590AC8461"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HES_BURSAR_JOB",
            "displayName": "Bursar",
            "description": "Manages all student receivable activities, including defining policy and controls, establishing processes and procedures, resolving issues, monitoring and analyzing accounts receivable balances, and creating reports and business intelligence.",
            "category": "JOB"
        },
        {
            "id": "A8538773524A4BB1B91D2458B2354A76",
            "meta": {
                "created": "2017-09-07 03:11:58.537",
                "lastModified": "2018-10-19 12:45:16.159",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A8538773524A4BB1B91D2458B2354A76"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MSC_ORDER_PROMISING_MANAGER_JOB",
            "displayName": "Order Promising Manager",
            "description": "Manages commitment of fulfillment dates, allocating scarce supply among competing demands and trading-off service levels with fulfillment costs.",
            "category": "JOB"
        },
        {
            "id": "915D468B79384B2B96E9427F2EEDB7DF",
            "meta": {
                "created": "2017-09-07 03:11:58.546",
                "lastModified": "2018-10-19 12:45:17.566",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/915D468B79384B2B96E9427F2EEDB7DF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZX_TAX_ACCOUNTANT_JOB",
            "displayName": "Tax Accountant",
            "description": "Prepares and files tax returns and reports for an enterprise, including country, federal, state, and local corporate, payroll, and transaction taxes.",
            "category": "JOB"
        },
        {
            "id": "34E5A5100DE5487A991E6ABCEAF968ED",
            "meta": {
                "created": "2017-09-07 03:11:58.554",
                "lastModified": "2018-10-19 12:45:16.167",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/34E5A5100DE5487A991E6ABCEAF968ED"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_RCS_SUPPLY_CHAIN_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Supply Chain Application Administrator",
            "description": "Individual responsible for supply chain application administration. Collaborates with supply chain application users to maintain consistent application setup, rules, and access.",
            "category": "JOB"
        },
        {
            "id": "A54430BE6D2142368869D6EAC71E2726",
            "meta": {
                "created": "2017-09-07 03:11:58.563",
                "lastModified": "2018-10-19 12:45:17.574",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A54430BE6D2142368869D6EAC71E2726"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_PARTNER_SALES_REPRESENTATIVE_JOB",
            "displayName": "Partner Sales Representative",
            "description": "Maintains leads, registers leads, and manages partner opportunities.",
            "category": "JOB"
        },
        {
            "id": "803395641F7442DC99C6E45F51AB3AA9",
            "meta": {
                "created": "2017-09-07 03:11:58.573",
                "lastModified": "2018-10-19 12:45:17.592",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/803395641F7442DC99C6E45F51AB3AA9"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MKT_MARKETING_MANAGER_JOB",
            "displayName": "Marketing Manager",
            "description": "Coordinates marketing messaging content, pricing, segmentation, communication channels, and launch activities for marketing campaigns. Contributes to sales lead pipeline process and estimations, product definitions, and return on investment calculations.",
            "category": "JOB"
        },
        {
            "id": "106CBDDAFA7647849B573EF3847E8CE4",
            "meta": {
                "created": "2017-09-07 03:11:58.583",
                "lastModified": "2018-10-19 12:45:16.175",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/106CBDDAFA7647849B573EF3847E8CE4"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CN_INCENTIVE_COMPENSATION_PLAN_ADMINISTRATOR_JOB",
            "displayName": "Incentive Compensation Plan Administrator",
            "description": "Configure and manage incentive plans, plan components, and classification rules",
            "category": "JOB"
        },
        {
            "id": "9FF0796822A249058FD4BB6C43FECDEB",
            "meta": {
                "created": "2017-09-07 03:11:58.593",
                "lastModified": "2018-10-19 12:45:17.610",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/9FF0796822A249058FD4BB6C43FECDEB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MNT_MAINTENANCE_MANAGER_JOB",
            "displayName": "Maintenance Manager",
            "description": "Individual responsible for ensuring effective maintenance programs are in place and overseeing completion of maintenance tasks.",
            "category": "JOB"
        },
        {
            "id": "C545790639FC44A98CB3ED1EB0874BF0",
            "meta": {
                "created": "2017-09-07 03:11:58.606",
                "lastModified": "2018-10-19 12:45:17.635",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/C545790639FC44A98CB3ED1EB0874BF0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_IEX_COLLECTIONS_AGENT_JOB",
            "displayName": "Collections Agent",
            "description": "This role is the agent user in Collections.",
            "category": "JOB"
        },
        {
            "id": "A4CD7E19A3F84031945425CF48796700",
            "meta": {
                "created": "2017-09-07 03:11:58.617",
                "lastModified": "2018-10-19 12:45:16.191",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A4CD7E19A3F84031945425CF48796700"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMK_TRADING_PARTNER_B2B_ADMINISTRATOR_ABSTRACT",
            "displayName": "Trading Partner B2B Administrator",
            "description": "Trading partner (Supplier or Customer) responsible for accessing self service tools and who is given delegated user administration responsibilities.",
            "category": "ABSTRACT"
        },
        {
            "id": "8B305301DED14E688B2622EFC38AD2F5",
            "meta": {
                "created": "2017-09-07 03:11:58.628",
                "lastModified": "2018-10-19 12:45:17.657",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8B305301DED14E688B2622EFC38AD2F5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AR_BILLING_SPECIALIST_JOB",
            "displayName": "Obsolete: Billing Specialist",
            "description": "Manages the implementation of assigned billing activities.",
            "category": "JOB"
        },
        {
            "id": "F5CB48A3F5854EC4A181761A331BF528",
            "meta": {
                "created": "2017-09-07 03:11:58.638",
                "lastModified": "2018-10-19 12:45:16.200",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F5CB48A3F5854EC4A181761A331BF528"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMP_COMPENSATION_MANAGER_JOB",
            "displayName": "Compensation Manager",
            "description": "Manages compensation business processes and worker compensation details.",
            "category": "JOB",
            "members": [
                {
                    "value": "73A1976DCE97E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "8104CD1F288E4C4685B8D9EA5BEB10AF",
            "meta": {
                "created": "2017-09-07 03:11:58.649",
                "lastModified": "2018-10-19 12:45:17.667",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8104CD1F288E4C4685B8D9EA5BEB10AF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_DOO_ORDER_MANAGER_JOB",
            "displayName": "Order Manager",
            "description": "Manages coordination of fulfillment, which includes expediting orders to ensure they are fulfilled properly and on time. Also manages exceptions and issues with order fulfillment.",
            "category": "JOB"
        },
        {
            "id": "5F6607B8BEAD4DCC8565A043D74D25B1",
            "meta": {
                "created": "2017-09-07 03:11:58.660",
                "lastModified": "2018-10-19 12:45:17.676",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5F6607B8BEAD4DCC8565A043D74D25B1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_WIE_PRODUCTION_OPERATOR_JOB",
            "displayName": "Production Operator",
            "description": "Individual responsible for material handling, fabrication, assembly and finishing of products, and preparing finished products for warehousing and shipping.",
            "category": "JOB"
        },
        {
            "id": "99683D76A1A54FD994447199E241BA1C",
            "meta": {
                "created": "2017-09-07 03:11:58.670",
                "lastModified": "2018-10-19 12:45:17.688",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/99683D76A1A54FD994447199E241BA1C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GL_FINANCIAL_ANALYST_JOB",
            "displayName": "Financial Analyst",
            "description": "Analyzes the financial performance of an enterprise or an organization within an enterprise.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE848E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE906E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE859E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4F9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE713E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9F0E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E7EAEBBE050790A7040267D"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE812E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1556DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE7B5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7BDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE460E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE87BE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1574DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE6AFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "40A45A95B56444DBBFCA0292806E0513",
            "meta": {
                "created": "2017-09-07 03:11:58.681",
                "lastModified": "2018-10-19 12:45:17.696",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/40A45A95B56444DBBFCA0292806E0513"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_CHANNEL_PARTNER_MANAGER_JOB",
            "displayName": "Channel Partner Manager",
            "description": "Defines new channel partner programs.",
            "category": "JOB"
        },
        {
            "id": "AB76663B161B4E2E8CFAF14B16C42398",
            "meta": {
                "created": "2017-09-07 03:11:58.692",
                "lastModified": "2018-10-19 12:45:17.705",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/AB76663B161B4E2E8CFAF14B16C42398"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_EXECUTIVE_MANAGER_ABSTRACT",
            "displayName": "Executive Manager",
            "description": "Leads one or more groups or departments, working directly with the higher levels of management.",
            "category": "ABSTRACT"
        },
        {
            "id": "1A0ED9FCD73046C78A812CFB81A35CDF",
            "meta": {
                "created": "2017-09-07 03:11:58.738",
                "lastModified": "2018-10-19 12:45:17.716",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1A0ED9FCD73046C78A812CFB81A35CDF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POZ_SUPPLIER_MANAGER_ABSTRACT",
            "displayName": "Supplier Manager",
            "description": "Manages supplier information and authorizes promotion of prospective suppliers to spend authorized.",
            "category": "ABSTRACT"
        },
        {
            "id": "53FE9219151946DD8B3653BD1FAA8D14",
            "meta": {
                "created": "2017-09-07 03:11:58.748",
                "lastModified": "2018-10-19 12:45:17.724",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/53FE9219151946DD8B3653BD1FAA8D14"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ASM_FUNCTIONAL_SETUPS_USER_ABSTRACT",
            "displayName": "Functional Setups User",
            "description": "Uses the functional user overview, and assigned tasks, and task lists. This role inherits the Functional Setups Duty job role and maintains a one to one relationship with this role. This role addresses dependency issues and should not be directly inherited by any product job or duty role.",
            "category": "ABSTRACT"
        },
        {
            "id": "63D46276E225488FB78F0003354CA829",
            "meta": {
                "created": "2017-09-07 03:11:58.757",
                "lastModified": "2018-10-19 12:45:16.216",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/63D46276E225488FB78F0003354CA829"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CST_COST_ACCOUNTANT_JOB",
            "displayName": "Cost Accountant",
            "description": "Performs cost and management accounting functions.",
            "category": "JOB"
        },
        {
            "id": "1D5C65EE9DDE4A479B10EC48B2B39631",
            "meta": {
                "created": "2017-09-07 03:11:58.767",
                "lastModified": "2018-10-19 12:45:17.732",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1D5C65EE9DDE4A479B10EC48B2B39631"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_INV_INVENTORY_MANAGER_JOB",
            "displayName": "Inventory Manager",
            "description": "Manages activities in the warehouse such as managing inventory transactions, planning inventory replenishment and managing cycle and physical inventory counts.",
            "category": "JOB"
        },
        {
            "id": "D94328B8297A463898AE603B5220E831",
            "meta": {
                "created": "2017-06-03 03:03:23.000",
                "lastModified": "2018-10-19 12:45:17.441",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D94328B8297A463898AE603B5220E831"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CRM_EXTN_ROLE",
            "displayName": "Custom Objects Administration",
            "description": "This role is granted privileges to custom objects.",
            "category": "JOB",
            "members": [
                {
                    "value": "47DBFDC4228B5A76E050F40A76AB16F8"
                }
            ]
        },
        {
            "id": "49569339C3AB4003859B663853FC6523",
            "meta": {
                "created": "2017-09-07 03:11:58.777",
                "lastModified": "2018-10-19 12:45:17.749",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/49569339C3AB4003859B663853FC6523"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ACD_PRODUCT_DESIGN_ENGINEER_JOB",
            "displayName": "Product Design Engineer",
            "description": "Individual responsible for creating the definition of mechanical and electronic products including their shape, physical characteristics, electronic characteristics, and manufacturing parameters such as tolerance.",
            "category": "JOB"
        },
        {
            "id": "88EA6C6006BB4F07828382964C7EBA6F",
            "meta": {
                "created": "2017-09-07 03:11:58.788",
                "lastModified": "2018-10-19 12:45:17.741",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/88EA6C6006BB4F07828382964C7EBA6F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_TRAVEL_MANAGER_JOB",
            "displayName": "Travel Manager",
            "description": "Oversees the operations of corporate travel programs. Manages integration with other travel partners to improve employee travel experience from planning to reimbursement.",
            "category": "JOB"
        },
        {
            "id": "912D93E2C4754F2C9E22E017DFFCFE36",
            "meta": {
                "created": "2017-09-07 03:11:58.798",
                "lastModified": "2018-10-19 12:45:16.226",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/912D93E2C4754F2C9E22E017DFFCFE36"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GTG_APPLICATION_CONTROL_MANAGER_JOB",
            "displayName": "Application Control Manager",
            "description": "Individual responsible for managing and auditing enterprise advanced financial transaction controls.",
            "category": "JOB"
        },
        {
            "id": "4B1557AB566C4B2F87D3C5B21AAEC9F9",
            "meta": {
                "created": "2017-09-07 03:11:58.808",
                "lastModified": "2018-10-19 12:45:16.235",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4B1557AB566C4B2F87D3C5B21AAEC9F9"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZBS_SALES_VP_JOB",
            "displayName": "Sales VP",
            "description": "Manages sales managers within the organization. Responsible for account planning, territory and quota management, and managing sales forecasts for the territory.",
            "category": "JOB"
        },
        {
            "id": "8E6F44F5C44E49A787441525CB6593AC",
            "meta": {
                "created": "2017-09-07 03:11:58.819",
                "lastModified": "2018-10-19 12:45:17.759",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8E6F44F5C44E49A787441525CB6593AC"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CN_INCENTIVE_COMPENSATION_PARTICIPANT_MANAGER_ABSTRACT",
            "displayName": "Incentive Compensation Participant Manager",
            "description": "Manage participants who receive incentive compensation and review reports",
            "category": "ABSTRACT"
        },
        {
            "id": "EFFDA6A65A034DACB99F336D08C5CD3D",
            "meta": {
                "created": "2017-09-07 03:11:58.831",
                "lastModified": "2018-10-19 12:45:16.261",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/EFFDA6A65A034DACB99F336D08C5CD3D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMP_COMPENSATION_APPROVER_ABSTRACT",
            "displayName": "Compensation Approver",
            "description": "Individual who can approve a workforce compensation worksheet but is not necessarily a line manager who has access to the workforce compensation work area.",
            "category": "ABSTRACT"
        },
        {
            "id": "0678DAA2FA674A358AAF52CADC973586",
            "meta": {
                "created": "2017-09-07 03:11:58.841",
                "lastModified": "2018-10-19 12:45:16.268",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0678DAA2FA674A358AAF52CADC973586"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PRINCIPAL_INVESTIGATOR_JOB",
            "displayName": "Principal Investigator",
            "description": "Controls and monitors the technical direction and academic quality of research projects such as laboratory studies or clinical trials. Ensures that projects comply with the terms, conditions, and policies defined by the sponsor and the institution. Owns ultimate responsibility for the management of the sponsored research award, especially in cases where funding is obtained from federal agencies such as the NIH or NSF.",
            "category": "JOB"
        },
        {
            "id": "28D2F94F4EEA4BA486EAEB5E9964868C",
            "meta": {
                "created": "2017-09-07 03:11:58.850",
                "lastModified": "2018-10-19 12:45:17.768",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/28D2F94F4EEA4BA486EAEB5E9964868C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POS_SUPPLIER_SALES_REPRESENTATIVE_JOB",
            "displayName": "Supplier Sales Representative",
            "description": "Manages agreements and deliverables for the supplier company. Primary tasks include acknowledging or requesting changes to agreements in addition to adding catalog line items with customer specific pricing and terms. Updates contract deliverables that are assigned to the supplier party and updates progress on contract deliverables for which the supplier is responsible.",
            "category": "JOB"
        },
        {
            "id": "0AA20593C1AC4F62883119F939B4FBCB",
            "meta": {
                "created": "2017-09-07 03:11:58.860",
                "lastModified": "2018-10-19 12:45:16.286",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0AA20593C1AC4F62883119F939B4FBCB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AP_ACCOUNTS_PAYABLE_MANAGER_JOB",
            "displayName": "Accounts Payable Manager",
            "description": "Manages Accounts Payable department and personnel. Overrides exceptions, analyzes Oracle Fusion Payables balances, and submits income tax and withholding reports to meet regulatory requirements.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "4B8420E7168E46EFB5EBB78AF5FF0F62",
            "meta": {
                "created": "2017-09-07 03:11:58.870",
                "lastModified": "2018-10-19 12:45:16.294",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4B8420E7168E46EFB5EBB78AF5FF0F62"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EXM_EXPENSE_MANAGER_JOB",
            "displayName": "Expense Manager",
            "description": "Manages company's expense policies and processes. Reviews and proposes changes to expense policies.",
            "category": "JOB"
        },
        {
            "id": "E8631196919C4B8CA2BA8A9ED64EAC87",
            "meta": {
                "created": "2017-09-07 03:11:58.880",
                "lastModified": "2018-10-19 12:45:16.302",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E8631196919C4B8CA2BA8A9ED64EAC87"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CSO_KNOWLEDGE_ANALYST_JOB",
            "displayName": "Knowledge Analyst",
            "description": "Individual responsible for creation of knowledge articles.",
            "category": "JOB"
        },
        {
            "id": "2183983A49B948F49638DA75CA207124",
            "meta": {
                "created": "2017-09-07 03:11:58.890",
                "lastModified": "2018-10-19 12:45:17.775",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2183983A49B948F49638DA75CA207124"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HER_REGISTRAR_JOB",
            "displayName": "Registrar",
            "description": "Provides leadership to plan, organize, and manage all of the activities related to the Records and Registration Department, including serving as the official authorized keeper of the university's student records in a higher education setting.",
            "category": "JOB"
        },
        {
            "id": "157E7350A92E4BF5ABA28BFF5D0CEED3",
            "meta": {
                "created": "2017-09-07 03:11:58.900",
                "lastModified": "2018-10-19 12:45:16.310",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/157E7350A92E4BF5ABA28BFF5D0CEED3"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CSO_KNOWLEDGE_MANAGER_JOB",
            "displayName": "Knowledge Manager",
            "description": "Individual responsible for managing Knowledge Base activities.",
            "category": "JOB"
        },
        {
            "id": "B33FA68689754FFA88DB74EB1009E486",
            "meta": {
                "created": "2017-09-07 03:11:58.910",
                "lastModified": "2018-10-19 12:45:16.318",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B33FA68689754FFA88DB74EB1009E486"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MSC_MATERIALS_PLANNER_JOB",
            "displayName": "Materials Planner",
            "description": "Manages and balances all demand and supply in the supply chain.",
            "category": "JOB"
        },
        {
            "id": "BEDFD1970BC84AB0BFE6CD4DF1443890",
            "meta": {
                "created": "2017-09-07 03:11:58.921",
                "lastModified": "2018-10-19 12:45:17.782",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BEDFD1970BC84AB0BFE6CD4DF1443890"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POR_ADVANCED_PROCUREMENT_REQUESTER_ABSTRACT",
            "displayName": "Advanced Procurement Requester",
            "description": "Prepares requisitions on behalf of others and has access to advanced requisition creation permissions.",
            "category": "ABSTRACT"
        },
        {
            "id": "D53B462D7C8B4046845753188AE3DA58",
            "meta": {
                "created": "2017-09-07 03:11:58.931",
                "lastModified": "2018-10-19 12:45:17.793",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D53B462D7C8B4046845753188AE3DA58"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_IT_SECURITY_MANAGER_JOB",
            "displayName": "IT Security Manager",
            "description": "Protects assets such as information technology systems, data, and networks.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "47DAAF938F2F7B5BE050F40A76AB350F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "BC9A72389A50439483B55FE8DFC0FFC0",
            "meta": {
                "created": "2017-09-07 03:11:58.940",
                "lastModified": "2018-10-19 12:45:17.804",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BC9A72389A50439483B55FE8DFC0FFC0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MKT_MARKETING_OPERATIONS_MANAGER_JOB",
            "displayName": "Marketing Operations Manager",
            "description": "Manages the operations for marketing and leads. Develops tactical campaigns to carry out marketing strategies and communicate offers to customer segments using multiple marketing channels. Monitors campaign interactions, captures campaign responses, and manages sales leads to fill the sales pipeline. Creates and maintains the setup for marketing campaigns, responses, segments, lists, and treatments.",
            "category": "JOB"
        },
        {
            "id": "3AAA4C5ABC7043FB8DD4F8A87697539A",
            "meta": {
                "created": "2017-09-07 03:11:58.948",
                "lastModified": "2018-10-19 12:45:16.327",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3AAA4C5ABC7043FB8DD4F8A87697539A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PON_SOURCING_PROJECT_COLLABORATOR_ABSTRACT",
            "displayName": "Sourcing Project Collaborator",
            "description": "Key organization stakeholder helping to determine negotiation strategies, award decision criteria, and objective scoring on behalf of their organization.",
            "category": "ABSTRACT"
        },
        {
            "id": "384F263280724A43BD3721F9998DCFF0",
            "meta": {
                "created": "2017-09-07 03:11:58.957",
                "lastModified": "2018-10-19 12:45:17.812",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/384F263280724A43BD3721F9998DCFF0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_HUMAN_RESOURCE_ANALYST_JOB",
            "displayName": "Human Resource Analyst",
            "description": "Performs duties of a human resources analyst.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "6F0E7D39C6604BCDB216FCFBAF216441",
            "meta": {
                "created": "2017-09-07 03:11:58.968",
                "lastModified": "2018-10-19 12:45:17.824",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6F0E7D39C6604BCDB216FCFBAF216441"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_ANONYMOUS_USER_ABSTRACT",
            "displayName": "Anonymous User",
            "description": "Maps to OPSS system Anonymous Role",
            "category": "ABSTRACT"
        },
        {
            "id": "24F06E3CE10747AB987BD22F2C9D1238",
            "meta": {
                "created": "2017-09-07 03:11:58.980",
                "lastModified": "2018-10-19 12:45:16.334",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/24F06E3CE10747AB987BD22F2C9D1238"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CN_INCENTIVE_COMPENSATION_ANALYST_JOB",
            "displayName": "Incentive Compensation Analyst",
            "description": "Manage participant data, exceptions, and reports",
            "category": "JOB"
        },
        {
            "id": "CF62CD8DB007485E81CD1E32C81A4D29",
            "meta": {
                "created": "2017-09-07 03:11:58.990",
                "lastModified": "2018-10-19 12:45:17.836",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/CF62CD8DB007485E81CD1E32C81A4D29"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_MANAGER_JOB",
            "displayName": "Project Manager",
            "description": "Manages the execution and completion of a single project. Creates budgets, plans, and schedules. Sources and allocates resources such as labor, subcontractors, materials, and equipment. Tracks physical and financial project performance, changes, and issues. Ensures proper billing and cost transfers. Communicates status and project performance to program managers and project executives.",
            "category": "JOB"
        },
        {
            "id": "199A0BA362FF4B9D8244BB7B78A8A8D2",
            "meta": {
                "created": "2017-09-07 03:11:58.999",
                "lastModified": "2018-10-19 12:45:17.844",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/199A0BA362FF4B9D8244BB7B78A8A8D2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_CHANNEL_SALES_MANAGER_JOB",
            "displayName": "Channel Sales Manager",
            "description": "Manages the indirect sales pipeline by routing leads to partners, reviewing lead registrations, approving or rejecting registrations, and forecasting sales.",
            "category": "JOB"
        },
        {
            "id": "E6273E9F26BA44589A7F2D6E926A93CF",
            "meta": {
                "created": "2017-09-07 03:11:59.008",
                "lastModified": "2018-10-19 12:45:16.344",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E6273E9F26BA44589A7F2D6E926A93CF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_EXECUTIVE_JOB",
            "displayName": "Project Executive",
            "description": "Establishes key performance indicators and other project performance criteria for a business area or organization. Manages business area performance. Owns profit and loss results for an organization, service line, or region.",
            "category": "JOB"
        },
        {
            "id": "9A0C50453A5D4574872F896050D399DF",
            "meta": {
                "created": "2017-09-07 03:11:59.017",
                "lastModified": "2018-10-19 12:45:17.862",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/9A0C50453A5D4574872F896050D399DF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_CHANNEL_ADMINISTRATOR_JOB",
            "displayName": "Channel Administrator",
            "description": "Executes Oracle Partnership Management setup tasks.",
            "category": "JOB"
        },
        {
            "id": "1D2E5EADB4FD47F89CD089D2D88D60C0",
            "meta": {
                "created": "2017-09-07 03:11:57.628",
                "lastModified": "2018-10-19 12:45:17.048",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1D2E5EADB4FD47F89CD089D2D88D60C0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_RECRUITING_ADMINISTRATOR_JOB",
            "displayName": "Recruiting Administrator",
            "description": "Supports integration with Oracle Taleo Recruiting Cloud Service and configuration of Oracle Recruiting Cloud. In Oracle Taleo Recruiting Cloud Service, a Recruiting Administrator has the permissions to configure almost all recommended features  in the Recruiting and Configuration centers. In Oracle Recruiting Cloud, a Recruiting Administrator can perform recruiting specific configuration, including candidate experience.",
            "category": "JOB",
            "members": [
                {
                    "value": "655792DFE1B4D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "549831F445D943779E5FD5D150B50847",
            "meta": {
                "created": "2017-09-07 03:11:57.701",
                "lastModified": "2018-10-19 12:45:15.612",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/549831F445D943779E5FD5D150B50847"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_QP_PRICING_MANAGER_JOB",
            "displayName": "Pricing Manager",
            "description": "Manages and approves pricing entities. Also manages price execution setup, customer pricing profile, pricing segments, pricing strategies and pricing rules.",
            "category": "JOB"
        },
        {
            "id": "B6816AB078DE43A3A025C0EAA8965B9F",
            "meta": {
                "created": "2017-09-07 03:11:57.711",
                "lastModified": "2018-10-19 12:45:15.628",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B6816AB078DE43A3A025C0EAA8965B9F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EGP_PRODUCT_MANAGER_JOB",
            "displayName": "Product Manager",
            "description": "Ensures that a product gets created, tested, and shipped on schedule and meets specifications. A member of either the marketing organization or the development organization.",
            "category": "JOB"
        },
        {
            "id": "2126FA70F6FE493EAF091D5920EDDD99",
            "meta": {
                "created": "2017-09-07 03:11:57.719",
                "lastModified": "2018-10-19 12:45:17.056",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2126FA70F6FE493EAF091D5920EDDD99"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_GRANTS_ACCOUNTANT_JOB",
            "displayName": "Grants Accountant",
            "description": "Oversees the collection, recording, allocation, and analysis of award and project costs and revenue. Analyses budget and actual costs and prepares project profit and loss statements. Reports financial performance to project managers and executives. Prepares draft invoices, obtains approval from project managers, and transfers invoices to the Receivables application. Compiles billing support and backup documentation. Manages period or year-end closing procedures.",
            "category": "JOB"
        },
        {
            "id": "094A5022E4C049C4B26A6C52FE2B32D2",
            "meta": {
                "created": "2017-09-07 03:11:57.726",
                "lastModified": "2018-10-19 12:45:17.063",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/094A5022E4C049C4B26A6C52FE2B32D2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POR_PROCUREMENT_REQUESTER_ABSTRACT",
            "displayName": "Procurement Requester",
            "description": "Prepares requisitions for themselves.",
            "category": "ABSTRACT"
        },
        {
            "id": "D81654ADADE847DFB469EE3B1C2C4D1C",
            "meta": {
                "created": "2017-09-07 03:11:57.734",
                "lastModified": "2018-10-19 12:45:17.070",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D81654ADADE847DFB469EE3B1C2C4D1C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POR_PROCUREMENT_PREPARER_ABSTRACT",
            "displayName": "Procurement Preparer",
            "description": "Prepares requisitions on behalf of others.",
            "category": "ABSTRACT"
        },
        {
            "id": "E66C461D4971474792D83A6CA2F30CC2",
            "meta": {
                "created": "2017-09-07 03:11:57.743",
                "lastModified": "2018-10-19 12:45:17.079",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E66C461D4971474792D83A6CA2F30CC2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_TEAM_COLLABORATOR_ABSTRACT",
            "displayName": "Team Collaborator",
            "description": "Identifies the person in a project organization as a member who can perform, track, and report progress on project and non-project work.",
            "category": "ABSTRACT"
        },
        {
            "id": "FECCD08A1B0843ABB3A9C0646B339C78",
            "meta": {
                "created": "2017-09-07 03:11:57.751",
                "lastModified": "2018-10-19 12:45:15.659",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FECCD08A1B0843ABB3A9C0646B339C78"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_CHANNEL_PARTNER_PORTAL_ADMINISTRATOR_JOB",
            "displayName": "Channel Partner Portal Administrator",
            "description": "Maintains customer-specific changes of all partner portal pages, external, internal, and anonymous pages.",
            "category": "JOB"
        },
        {
            "id": "5F13536B4064481C9CE81C75F30449FC",
            "meta": {
                "created": "2017-09-07 03:11:57.762",
                "lastModified": "2018-10-19 12:45:15.667",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5F13536B4064481C9CE81C75F30449FC"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CN_INCENTIVE_COMPENSATION_MANAGER_JOB",
            "displayName": "Incentive Compensation Manager",
            "description": "Manage processes and workloads, assignments, and payments",
            "category": "JOB"
        },
        {
            "id": "63486315177849D3BEA7CC067C5EC5F7",
            "meta": {
                "created": "2017-09-07 03:11:57.772",
                "lastModified": "2018-10-19 12:45:17.087",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/63486315177849D3BEA7CC067C5EC5F7"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PO_PURCHASE_ANALYSIS_ABSTRACT",
            "displayName": "Purchase Analysis",
            "description": "Allows a user to preform line of business analysis on requisitions, purchase orders, and suppliers.",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE742E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE684E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CAE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157FDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "FFBFED8252884646B16CAC2408C89D92",
            "meta": {
                "created": "2017-09-07 03:11:57.782",
                "lastModified": "2018-10-19 12:45:15.689",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FFBFED8252884646B16CAC2408C89D92"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GTG_APPLICATION_ACCESS_AUDITOR_JOB",
            "displayName": "Application Access Auditor",
            "description": "Individual responsible for managing and auditing enterprise advanced access controls.",
            "category": "JOB"
        },
        {
            "id": "6935228A92464361A2DD0C1AE5304FEB",
            "meta": {
                "created": "2017-09-07 03:11:57.792",
                "lastModified": "2018-10-19 12:45:17.095",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6935228A92464361A2DD0C1AE5304FEB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZBS_SALES_MANAGER_JOB",
            "displayName": "Sales Manager",
            "description": "Manages salespersons within the organization. Generates revenue within a territory, builds pipeline, manages territory forecasts, and assists salespersons in closing deals.",
            "category": "JOB"
        },
        {
            "id": "0115CA8B1A2C477987EA8715D67FCF65",
            "meta": {
                "created": "2017-09-07 03:11:57.803",
                "lastModified": "2018-10-19 12:45:15.698",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0115CA8B1A2C477987EA8715D67FCF65"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_WLF_LEARNING_SPECIALIST_JOB",
            "displayName": "Learning Specialist",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "E5E615391CD2438F8C2CC5A9730B9694",
            "meta": {
                "created": "2017-09-07 03:11:57.814",
                "lastModified": "2018-10-19 12:45:17.104",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E5E615391CD2438F8C2CC5A9730B9694"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POS_SUPPLIER_SELF_SERVICE_CLERK_ABSTRACT",
            "displayName": "Supplier Self Service Clerk",
            "description": "Manages the profile information for the supplier company. Primary tasks include updating supplier profile information and requesting user accounts to grant employees access to the supplier application.",
            "category": "ABSTRACT"
        },
        {
            "id": "286A66D6E2544AD4B13D7565FFC6CD9E",
            "meta": {
                "created": "2017-09-07 03:11:57.825",
                "lastModified": "2018-10-19 12:45:17.112",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/286A66D6E2544AD4B13D7565FFC6CD9E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMK_B2B_ADMINISTRATOR_ABSTRACT",
            "displayName": "B2B Administrator",
            "description": "This user is a member of an organization who has delegated administration responsibilities in addition to the typical B2B user.",
            "category": "ABSTRACT"
        },
        {
            "id": "F24EB98698594428A148EFFD191D25A1",
            "meta": {
                "created": "2017-09-07 03:11:57.836",
                "lastModified": "2018-10-19 12:45:17.125",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F24EB98698594428A148EFFD191D25A1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_SUPPLIER_CONTRACT_MANAGER_JOB",
            "displayName": "Supplier Contract Manager",
            "description": "Manages a team of supplier contract administrators.",
            "category": "JOB"
        },
        {
            "id": "FC00F6EBB66F4798B39BF59E33ED7EDB",
            "meta": {
                "created": "2017-09-07 03:11:57.845",
                "lastModified": "2018-10-19 12:45:15.737",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FC00F6EBB66F4798B39BF59E33ED7EDB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FUN_INTERCOMPANY_ACCOUNTANT_JOB",
            "displayName": "Intercompany Accountant",
            "description": "Manages intercompany transaction processing, reconciliation and reporting.",
            "category": "JOB"
        },
        {
            "id": "BB3A3D4F5F284B12A4BFE7E90FE4DB03",
            "meta": {
                "created": "2017-09-07 03:11:57.856",
                "lastModified": "2018-10-19 12:45:15.746",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BB3A3D4F5F284B12A4BFE7E90FE4DB03"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Project Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of project management information systems.",
            "category": "JOB"
        },
        {
            "id": "F9C02CF187044413B05BFEAD779CCA99",
            "meta": {
                "created": "2017-09-07 03:11:57.866",
                "lastModified": "2018-10-19 12:45:15.754",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F9C02CF187044413B05BFEAD779CCA99"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HEY_STUDENT_JOB",
            "displayName": "Student",
            "description": "Enrolls in a program of study and pays the fees.",
            "category": "JOB"
        },
        {
            "id": "AB160AA753E64301ABF74157A78ECCC0",
            "meta": {
                "created": "2017-09-07 03:11:57.878",
                "lastModified": "2018-10-19 12:45:15.762",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/AB160AA753E64301ABF74157A78ECCC0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AR_ACCOUNTS_RECEIVABLE_MANAGER_JOB",
            "displayName": "Accounts Receivable Manager",
            "description": "Manages all accounts receivable activities, including defining policy and controls, establishing processes and procedures, resolving issues, monitoring and analyzing accounts receivable balances, and creating reports and business intelligence.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "F3121D9BDE48422FB40E2C1D0AC94902",
            "meta": {
                "created": "2017-09-07 03:11:57.889",
                "lastModified": "2018-10-19 12:45:17.182",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F3121D9BDE48422FB40E2C1D0AC94902"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMP_COMPENSATION_ADMINISTRATOR_JOB",
            "displayName": "Compensation Administrator",
            "description": "Manages implementation and administration of compensation business objects and batch processes.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE97E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "D2E5668755F547E08A9C0A7067B3A69B",
            "meta": {
                "created": "2017-09-07 03:11:57.898",
                "lastModified": "2018-10-19 12:45:17.191",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D2E5668755F547E08A9C0A7067B3A69B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HRY_PAYROLL_COORDINATOR_JOB",
            "displayName": "Payroll Interface Coordinator",
            "description": "Manages tasks that generate the personal payroll information required by third-party payroll providers.",
            "category": "JOB"
        },
        {
            "id": "73C9357528E744708B79F468D6365FC5",
            "meta": {
                "created": "2017-09-07 03:11:57.908",
                "lastModified": "2018-10-19 12:45:15.779",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/73C9357528E744708B79F468D6365FC5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_CUSTOMER_SERVICE_REPRESENTATIVE_JOB",
            "displayName": "Customer Service Representative",
            "description": "Most often in a call center answering customer calls of varying types. Could get requests for price and availability, request for quotes, order entry, and most often, order status. This individual either has a group of customers they service, or a group of Account Managers they work with.",
            "category": "JOB"
        },
        {
            "id": "F0A23C18F8B54C5C9CC73F70A3F20CE1",
            "meta": {
                "created": "2017-09-07 03:11:57.918",
                "lastModified": "2018-10-19 12:45:15.788",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F0A23C18F8B54C5C9CC73F70A3F20CE1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ARB_CUSTOMER_ACCOUNTS_PAYABLE_SPECIALIST_JOB",
            "displayName": "Customer Accounts Payable Specialist",
            "description": "Responsible for performing customer self-service bill management tasks.",
            "category": "JOB"
        },
        {
            "id": "FBA8DE399D4B4377981D53270CE94EA0",
            "meta": {
                "created": "2017-09-07 03:11:57.928",
                "lastModified": "2018-10-19 12:45:15.797",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FBA8DE399D4B4377981D53270CE94EA0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ENQ_QUALITY_ANALYST_JOB",
            "displayName": "Quality Analyst",
            "description": "Individual responsible for ensuring the quality of products throughout a project. Supports the Process Manager in defining processes and procedures and is responsible for conducting process reviews and audits throughout the project lifecycle to ensure standard processes and procedures are being followed.",
            "category": "JOB"
        },
        {
            "id": "509EEED6EB2E484CAD59E7426556A2A2",
            "meta": {
                "created": "2017-09-07 03:11:57.939",
                "lastModified": "2018-10-19 12:45:17.216",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/509EEED6EB2E484CAD59E7426556A2A2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ASM_APPLICATION_IMPLEMENTATION_ADMIN_ABSTRACT",
            "displayName": "Application Implementation Administrator",
            "description": "Performs all Oracle Fusion Functional Setup Manager duties.",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "E2B027D5193141309D4D1A8FCF6B0109",
            "meta": {
                "created": "2017-09-07 03:11:57.949",
                "lastModified": "2018-10-19 12:45:15.806",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E2B027D5193141309D4D1A8FCF6B0109"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ACE_PRODUCT_MANAGEMENT_VP_JOB",
            "displayName": "Product Management VP",
            "description": "The Product Management VP is the center point of accountability for the performance and alignment of one or more organization product portfolios.",
            "category": "JOB"
        },
        {
            "id": "5816E55E906344B4877D58F37D461FC1",
            "meta": {
                "created": "2017-09-07 03:11:57.959",
                "lastModified": "2018-10-19 12:45:15.817",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5816E55E906344B4877D58F37D461FC1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EXM_CORPORATE_CARD_ADMINISTRATOR_JOB",
            "displayName": "Corporate Card Administrator",
            "description": "Oversees the functioning of corporate card travel programs and procurement card programs. Provides support to cardholders and assures payments are made timely and no delinquencies are incurred.",
            "category": "JOB"
        },
        {
            "id": "E0A18A84AA4B43F986B03820E7577CAD",
            "meta": {
                "created": "2017-09-07 03:11:57.972",
                "lastModified": "2018-10-19 12:45:17.227",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E0A18A84AA4B43F986B03820E7577CAD"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HZ_RESOURCE_ABSTRACT",
            "displayName": "Resource",
            "description": "Identifies the person as front office personnel.",
            "category": "JOB"
        },
        {
            "id": "A28EAF40050E42E588491FE940A165E4",
            "meta": {
                "created": "2017-09-07 03:11:57.981",
                "lastModified": "2018-10-19 12:45:17.244",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A28EAF40050E42E588491FE940A165E4"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMF_FISCAL_DOCUMENT_SPECIALIST_JOB",
            "displayName": "Fiscal Document Specialist",
            "description": "Individual responsible for the validation of receipt fiscal document information, particularly financial and tax amounts applicable to purchase order receipts of goods and services.",
            "category": "JOB"
        },
        {
            "id": "2FD6F3B27C9F4CD8A0FB0D8F5FBEF98F",
            "meta": {
                "created": "2017-09-07 03:11:57.990",
                "lastModified": "2018-10-19 12:45:17.252",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2FD6F3B27C9F4CD8A0FB0D8F5FBEF98F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Application Administrator",
            "description": "Provides enterprise-wide application administration. Collaborates with specific application administrators to maintain consistent enterprise application setup, architecture, information, rules, and access.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "2A35043B6BCB45C39B280F2D1E547202",
            "meta": {
                "created": "2017-09-07 03:11:58.001",
                "lastModified": "2018-10-19 12:45:17.260",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2A35043B6BCB45C39B280F2D1E547202"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_CHANNEL_OPERATIONS_MANAGER_JOB",
            "displayName": "Channel Operations Manager",
            "description": "Maintains and manages partner transactional data.",
            "category": "JOB"
        },
        {
            "id": "2A3CEEBFEC694375A7405A412D012BC6",
            "meta": {
                "created": "2017-09-07 03:11:58.011",
                "lastModified": "2018-10-19 12:45:17.268",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2A3CEEBFEC694375A7405A412D012BC6"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_XCC_BUDGET_ANALYST_JOB",
            "displayName": "Budget Analyst",
            "description": "Analyzes funds available",
            "category": "JOB"
        },
        {
            "id": "542D33E8DD2441639EE410787D1C7189",
            "meta": {
                "created": "2017-09-07 03:11:58.020",
                "lastModified": "2018-10-19 12:45:15.852",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/542D33E8DD2441639EE410787D1C7189"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HER_ACADEMIC_COORDINATOR_JOB",
            "displayName": "Academic Coordinator",
            "description": "Individual responsible for managing the academic offerings of a school or department within a university, including: marketing and promoting the program, recruiting students, and creating, approving, and maintaining programs and course offerings, instructor assignments and hiring, and so on.",
            "category": "JOB"
        },
        {
            "id": "A55A176FA77C423F9422CFEC9B2C2C3A",
            "meta": {
                "created": "2017-09-07 03:11:58.028",
                "lastModified": "2017-09-07 03:11:58.033",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A55A176FA77C423F9422CFEC9B2C2C3A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_CASB_AUDIT_ACCESS_DISCRETIONARY_DISCRETIONARY",
            "displayName": "Audit Access for Cloud Access Security Broker",
            "description": "This discretionary role allows to view the audit history of all the business object attributes enabled for auditing at the attribute level without the value changes.",
            "category": "NONE",
            "members": [
                {
                    "value": "655792DFE142D7D8E050790A704077ED"
                },
                {
                    "value": "73A1976DCE81E135E050790A70400B1B"
                }
            ]
        },
        {
            "id": "8A320D9729554065A38F4617E7DE5BE0",
            "meta": {
                "created": "2017-09-07 03:11:58.040",
                "lastModified": "2018-10-19 12:45:17.285",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8A320D9729554065A38F4617E7DE5BE0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MSC_SUPPLY_CHAIN_PLANNING_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Supply Chain Planning Application Administrator",
            "description": "Individual responsible for supply chain planning application administration. Collaborates with supply chain planning application users to maintain consistent application setup, rules, and access.",
            "category": "JOB"
        },
        {
            "id": "D9C62C276BDD4437A8846DE71B4289E6",
            "meta": {
                "created": "2017-09-07 03:11:58.048",
                "lastModified": "2018-10-19 12:45:17.294",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D9C62C276BDD4437A8846DE71B4289E6"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_HUMAN_RESOURCE_MANAGER_JOB",
            "displayName": "Human Resource Manager",
            "description": "Performs duties of a human resources manager.",
            "category": "JOB"
        },
        {
            "id": "FCC57FA069534C3EBF0F2CA6C92BA771",
            "meta": {
                "created": "2017-09-07 03:11:58.056",
                "lastModified": "2018-10-19 12:45:17.303",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FCC57FA069534C3EBF0F2CA6C92BA771"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_CHANNEL_ACCOUNT_MANAGER_JOB",
            "displayName": "Channel Account Manager",
            "description": "Sets the objectives and goals for partners. Works with a partner organization to identify what programs best fit the partner organization and the training that the partner should take to increase skill sets or qualify for programs.",
            "category": "JOB"
        },
        {
            "id": "4395CD8953E843A9ACB828FA49F4F645",
            "meta": {
                "created": "2017-09-07 03:11:58.064",
                "lastModified": "2018-10-19 12:45:15.868",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4395CD8953E843A9ACB828FA49F4F645"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_POWER_RECRUITER_ABSTRACT",
            "displayName": "Power Recruiter",
            "description": "Supports integration with Oracle Taleo Recruiting Cloud Service, identifies workers with responsibilities in Oracle Taleo Recruiting Cloud Service, but without privileges in HCM. In Oracle Taleo Recruiting Cloud Service, a Power Recruiter has permissions on most features and functions within the Recruiting Center, but has limited ability to manage libraries and templates. Depending on specific needs of each organization, you may duplicate this user type, add, or remove permissions. This default user type provides a good starting point for other recruiting management roles.",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5E305E87F0C163FDE050790A70402713"
                },
                {
                    "value": "6EAD9D73191A19E2E050790A704031FC"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF8463FDE050790A70402713"
                },
                {
                    "value": "5E305E87F07D63FDE050790A70402713"
                },
                {
                    "value": "655792DFE1B4D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE886E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE93E135E050790A70400B1B"
                }
            ]
        },
        {
            "id": "66D3104F0F464E869F7A7D1D5523DB27",
            "meta": {
                "created": "2017-09-07 03:11:58.074",
                "lastModified": "2018-10-19 12:45:17.312",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/66D3104F0F464E869F7A7D1D5523DB27"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POR_PROCUREMENT_CATALOG_ADMINISTRATOR_ABSTRACT",
            "displayName": "Procurement Catalog Administrator",
            "description": "Manages agreements and catalog content including catalogs, category hierarchy, content zones, information templates, map sets, public shopping lists, and smart forms.",
            "category": "ABSTRACT"
        },
        {
            "id": "884E3121714F49EAA82E2E09B0D5974D",
            "meta": {
                "created": "2017-09-07 03:11:58.082",
                "lastModified": "2018-10-19 12:45:15.876",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/884E3121714F49EAA82E2E09B0D5974D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FUN_FINANCIAL_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Financial Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of financial information systems.",
            "category": "JOB"
        },
        {
            "id": "121FD6E861DB496C9E34B12963DE8FC8",
            "meta": {
                "created": "2017-09-07 03:11:58.089",
                "lastModified": "2018-10-19 12:45:15.886",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/121FD6E861DB496C9E34B12963DE8FC8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ACE_PRODUCT_PORTFOLIO_MANAGER_JOB",
            "displayName": "Product Portfolio Manager",
            "description": "Ensures good alignment of the product portfolio with the organizational strategy. Responsible for proposing investment or de-investment in products and concept projects based on the defined strategy, market data, cost and schedule.",
            "category": "JOB"
        },
        {
            "id": "44AB2661543D462D884350B8043B5D73",
            "meta": {
                "created": "2017-09-07 03:11:58.097",
                "lastModified": "2018-10-19 12:45:17.345",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/44AB2661543D462D884350B8043B5D73"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_WSH_SHIPPING_MANAGER_JOB",
            "displayName": "Shipping Manager",
            "description": "Monitors and analyzes outstanding and completed work for the warehouse. Manages the outbound shipment process including reviewing and resolving shipping exceptions. Implements shipping standards and process improvements.",
            "category": "JOB"
        },
        {
            "id": "20E36B4386184B9EBCFCBA7CC9FDEFB0",
            "meta": {
                "created": "2017-09-07 03:11:58.106",
                "lastModified": "2018-10-19 12:45:17.354",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/20E36B4386184B9EBCFCBA7CC9FDEFB0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of enterprise information systems.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "4936812F9B094D0E8F756EF9070123B5",
            "meta": {
                "created": "2017-09-07 03:11:58.116",
                "lastModified": "2018-10-19 12:45:15.897",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4936812F9B094D0E8F756EF9070123B5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_ENTERPRISE_CONTRACT_ADMINISTRATOR_JOB",
            "displayName": "Enterprise Contract Administrator",
            "description": "Performs the duties of both customer contract administrator and supplier contract administrator.",
            "category": "JOB"
        },
        {
            "id": "EFEE2753B4A94768BF0F6729AD2AD262",
            "meta": {
                "created": "2017-09-07 03:11:58.125",
                "lastModified": "2018-10-19 12:45:15.922",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/EFEE2753B4A94768BF0F6729AD2AD262"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MKT_CORPORATE_MARKETING_MANAGER_JOB",
            "displayName": "Corporate Marketing Manager",
            "description": "Develops and executes marketing strategies, translating customer needs from varied industries and markets into clear value propositions and actionable marketing programs. Communicates the corporate marketing message, manages the corporate marketing budget for allocation to marketing activities, and follows through the complete marketing life cycle to measure results.",
            "category": "JOB"
        },
        {
            "id": "8632489AA8A14444A629413B4EFCDF6E",
            "meta": {
                "created": "2017-09-07 03:11:58.133",
                "lastModified": "2018-10-19 12:45:17.370",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8632489AA8A14444A629413B4EFCDF6E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_MANAGEMENT_DUTY_ABSTRACT",
            "displayName": "Project Management Duty",
            "description": "Manages individual projects and is not assigned the project manager job role. Performs web service operations to create and update projects, tasks, resources, and associated attributes. Manages the integration between Oracle Fusion Project Foundation and Oracle Fusion Project Management.",
            "category": "ABSTRACT"
        },
        {
            "id": "E41F3B2A2AA141C0AE70F485F83A9934",
            "meta": {
                "created": "2017-09-07 03:11:58.141",
                "lastModified": "2018-10-19 12:45:17.378",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E41F3B2A2AA141C0AE70F485F83A9934"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_SUPPLIER_CONTRACT_ADMINISTRATOR_JOB",
            "displayName": "Supplier Contract Administrator",
            "description": "Works with internal buyers and legal to negotiate and author supplier contracts and agreements. Tracks critical contract milestones, monitors supplier performance, and assists buyers during contract renewals, closeout, and amendments.",
            "category": "JOB"
        },
        {
            "id": "DB3BC73803D94F0BB976C75C4536944C",
            "meta": {
                "created": "2017-09-07 03:11:58.149",
                "lastModified": "2018-10-19 12:45:15.935",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/DB3BC73803D94F0BB976C75C4536944C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FA_ASSET_ACCOUNTANT_JOB",
            "displayName": "Asset Accountant",
            "description": "Performs asset transactions including additions, adjustments, transfers, and retirements, ensuring accuracy and completeness. Verifies asset information, transaction details, and accounting entries through inquiry and reports.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF9463FDE050790A70402713"
                },
                {
                    "value": "5822400BEA39E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "BD340C3E9FCF48CA8A40AA7067B3F73F",
            "meta": {
                "created": "2017-09-07 03:11:58.157",
                "lastModified": "2018-10-19 12:45:15.944",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BD340C3E9FCF48CA8A40AA7067B3F73F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HER_INSTRUCTOR_JOB",
            "displayName": "Higher Education Instructor",
            "description": "Prepares, delivers, and assesses student performance on instructional material for a group of learners in a higher education setting.",
            "category": "JOB"
        },
        {
            "id": "77A64B1CE4494F8FA230B0B929D5F7C9",
            "meta": {
                "created": "2017-09-07 03:11:58.165",
                "lastModified": "2018-10-19 12:45:17.394",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/77A64B1CE4494F8FA230B0B929D5F7C9"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZBS_SALES_RESTRICTED_USER_JOB",
            "displayName": "Sales Restricted User",
            "description": "Has the same scope of visibility as that of a Sales Manager, but has a more restricted view of Sales Cloud. Can only view or read Sales Cloud data. The exception to this is the ability to create, edit or delete notes, activities, attachments and reports.",
            "category": "JOB"
        },
        {
            "id": "F6D6CE3B74D448B9BC80587486A2C92A",
            "meta": {
                "created": "2017-09-07 03:11:58.174",
                "lastModified": "2017-09-07 03:11:58.178",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F6D6CE3B74D448B9BC80587486A2C92A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ARB_CUSTOMER_ACCOUNT_BILLING_INQUIRY_DISCRETIONARY",
            "displayName": "Customer Account Billing Inquiry",
            "description": "Privilege granted on a discretionary basis for a user to review customer account and related billing transactions on behalf of a customer.",
            "category": "NONE"
        },
        {
            "id": "8EEFE1A93A01410B98B755BE75976D58",
            "meta": {
                "created": "2017-09-07 03:36:26.701",
                "lastModified": "2018-10-19 12:45:17.153",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8EEFE1A93A01410B98B755BE75976D58"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "HRSPECIALIST_VIEWALL_DATA",
            "displayName": "HRSpecialist_ViewAll",
            "description": "HRSpecialist_ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD152CDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD151CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE42DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA2EE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "180EDD237C654ABF990C53BFFBE8E490",
            "meta": {
                "created": "2017-09-07 03:47:13.734",
                "lastModified": "2018-10-19 12:45:17.888",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/180EDD237C654ABF990C53BFFBE8E490"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "COMPENSATIONMGR_VIEWALL_DATA",
            "displayName": "CompensationMgr_ViewAll",
            "description": "CompensationMgr_ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE97E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                }
            ]
        },
        {
            "id": "440A4315B2664735B65FB235619F65FD",
            "meta": {
                "created": "2017-09-07 03:50:10.433",
                "lastModified": "2018-10-19 12:45:15.639",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/440A4315B2664735B65FB235619F65FD"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "PAYROLLADMIN_VIEWALL_DATA",
            "displayName": "PayrollAdmin_ViewAll",
            "description": "PayrollAdmin_ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "0842E1BFBD83497FB16D7F03037ED6CA",
            "meta": {
                "created": "2017-09-07 03:52:02.938",
                "lastModified": "2018-10-19 12:45:17.208",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0842E1BFBD83497FB16D7F03037ED6CA"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "PAYROLLMGR_VIEWALL_DATA",
            "displayName": "PayrollMgr_ViewAll",
            "description": "PayrollMgr_ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "5DD771405008402E936000A9436FFC8B",
            "meta": {
                "created": "2017-09-07 07:17:14.000",
                "lastModified": "2018-10-19 12:45:16.253",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5DD771405008402E936000A9436FFC8B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_ESS_Monitor_Processes",
            "displayName": "MLC ESS Monitor Processes",
            "description": "This will allow users to see all the ESS Processes\n\nAdded Data Security Policy to access Output files for ESS Jobs run  by other users",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E7EAEBBE050790A7040267D"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "99477EC0B387434B94DE653459B2AC9D",
            "meta": {
                "created": "2017-09-07 13:20:05.559",
                "lastModified": "2018-10-19 12:45:15.911",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/99477EC0B387434B94DE653459B2AC9D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_PEOPLE_PARTNER_VIEWALL_DATA",
            "displayName": "MLC People Partner ViewAll",
            "description": "MLC_HR_SPCLST_PEOPLE_PARTNER_CUSTOM_VIEWALL_DATA",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BE6AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF8463FDE050790A70402713"
                },
                {
                    "value": "5822400BE886E9DEE050790A70403D5F"
                },
                {
                    "value": "766B01096A12A70EE050790A6740E718"
                },
                {
                    "value": "5822400BE7B0E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "3F36518490AB4E83B0DFA88C60B9D253",
            "meta": {
                "created": "2017-09-08 00:54:05.000",
                "lastModified": "2018-10-19 12:45:16.914",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3F36518490AB4E83B0DFA88C60B9D253"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_LM_CUSTOM",
            "displayName": "MLC Line Manager",
            "description": "Identifies the person as a line manager.",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE96BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE738E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE904E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88B530C9E050790A704076FF"
                },
                {
                    "value": "5822400BE675E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE711E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE723E9DEE050790A70403D5F"
                },
                {
                    "value": "5CA22278FA8EAE1FE050790A70407008"
                },
                {
                    "value": "5822400BE64DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE676E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6B3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE760E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA4BE9DEE050790A70403D5F"
                },
                {
                    "value": "5CA22278FA8BAE1FE050790A70407008"
                },
                {
                    "value": "5E305E244FD2AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE685E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE69AE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15ACDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE6AAE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE06CD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE6D2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE700E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9BEE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191B19E2E050790A704031FC"
                },
                {
                    "value": "5822400BE765E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C86B730C9E050790A704076FF"
                },
                {
                    "value": "5822400BE7A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE67CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8ACE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD156FDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE614E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE72DE9DEE050790A70403D5F"
                },
                {
                    "value": "5CA22278FA86AE1FE050790A70407008"
                },
                {
                    "value": "5822400BE4C7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5ABE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C87D530C9E050790A704076FF"
                },
                {
                    "value": "5822400BE68DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59FE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1582DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5A6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE81AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE481E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88BE30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE5DBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE94DE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ECFF634CE050790A70401414"
                },
                {
                    "value": "655792DFE13BD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE82CE9DEE050790A70403D5F"
                },
                {
                    "value": "5CA222DA0BBE1F39E050790A70407085"
                },
                {
                    "value": "5822400BE59CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE51CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5CBE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE18FD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE621E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6EAE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD153ADEECE050790A70403CA4"
                },
                {
                    "value": "6EAD9D73191919E2E050790A704031FC"
                },
                {
                    "value": "6557927C87CF30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE526E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE630E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE645E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE64CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE658E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD158CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE42DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE45DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE600E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE61CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4EAE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191519E2E050790A704031FC"
                },
                {
                    "value": "5822400BE81BE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1535DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE7F9E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9DD3DC5BC113E050790A7040327A"
                },
                {
                    "value": "5822400BE5A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE778E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE620E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73194519E2E050790A704031FC"
                },
                {
                    "value": "5822400BE737E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4E9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE583E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7ECE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE593E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191E19E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC5FC113E050790A7040327A"
                },
                {
                    "value": "6557927C88DA30C9E050790A704076FF"
                },
                {
                    "value": "6557927C88CB30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE54FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE575E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE90AE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C86F930C9E050790A704076FF"
                },
                {
                    "value": "5822400BE96EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE879E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4CDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE647E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE845E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4EBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE519E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE851E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE822E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE47EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE83FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE499E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE847E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE80EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE865E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE86EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89CE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1586DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE7EEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE927E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE92EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE707E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE93BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7F1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7F6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE810E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5EAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE588E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE834E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE55EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE840E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE844E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7C6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE86DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE941E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE98FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE625E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD152DDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1594DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9DBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE60BE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54AAA4B7E050790A70401387"
                },
                {
                    "value": "6557927C88CE30C9E050790A704076FF"
                },
                {
                    "value": "6557927C88D430C9E050790A704076FF"
                },
                {
                    "value": "5E305E244E87AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE821E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE961E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE573E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE580E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE96AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE95DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE529E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE90CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE52BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE532E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8C2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE662E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE617E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE78EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE44AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE447E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9C5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE728E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE72CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE727E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F6E9DEE050790A70403D5F"
                },
                {
                    "value": "4C07D24054DA4181E050790A704014DC"
                },
                {
                    "value": "5822400BE435E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE703E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE1A8D7D8E050790A704077ED"
                },
                {
                    "value": "5E305E87EF8863FDE050790A70402713"
                },
                {
                    "value": "5822400BE6E0E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E18AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE6BBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE432E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E80AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE487E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9D0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE631E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE49CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE533E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE566E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EFF063FDE050790A70402713"
                },
                {
                    "value": "6557927C88D630C9E050790A704076FF"
                },
                {
                    "value": "655792DFE19FD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE0F5D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE78DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5AEE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1540DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE978E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE48DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FDE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ED0D634CE050790A70401414"
                },
                {
                    "value": "6EAD9DD3DC61C113E050790A7040327A"
                },
                {
                    "value": "5822400BE7D3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE64EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE603E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87F14563FDE050790A70402713"
                },
                {
                    "value": "5822400BEA47E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6FBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CFE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C878E30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE6E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE46CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D8E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD159BDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15AFDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE7AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5CA222DA0BB31F39E050790A70407085"
                },
                {
                    "value": "5822400BE5D6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE734E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6DFE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE18DD7D8E050790A704077ED"
                },
                {
                    "value": "6EAD9D73191819E2E050790A704031FC"
                },
                {
                    "value": "5E305E244E20AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE7FEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE449E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE855E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE471E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE13FD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE594E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8E8E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE1B4D7D8E050790A704077ED"
                },
                {
                    "value": "58223FAD157CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE56DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE536E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EFF863FDE050790A70402713"
                },
                {
                    "value": "5822400BE5DEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE43FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE462E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4B2E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C86B530C9E050790A704076FF"
                },
                {
                    "value": "5822400BE48EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE87BE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE066D7D8E050790A704077ED"
                },
                {
                    "value": "6EAD9D73195219E2E050790A704031FC"
                },
                {
                    "value": "5822400BE9ACE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15A1DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1545DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1598DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE97CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE665E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9D1E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD158ADEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15A4DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9EEE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD159CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9D2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE983E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1576DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A0E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE1AFD7D8E050790A704077ED"
                },
                {
                    "value": "58223FAD155BDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9BFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15B6DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA17E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87F14963FDE050790A70402713"
                },
                {
                    "value": "5822400BE8B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE743E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15BBDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD154ADEECE050790A70403CA4"
                },
                {
                    "value": "6C7D3930ED00634CE050790A70401414"
                },
                {
                    "value": "655792DFE06BD7D8E050790A704077ED"
                },
                {
                    "value": "73A1970D2F3592B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE5AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B1E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4092B0E050790A70400AE8"
                }
            ]
        },
        {
            "id": "8613CCECCBA34B348BAA8DA5C423BE59",
            "meta": {
                "created": "2017-09-08 04:37:47.000",
                "lastModified": "2018-10-19 12:45:16.836",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8613CCECCBA34B348BAA8DA5C423BE59"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_STANDARD_OTBI_TASKS",
            "displayName": "MLC Standard OTBI Tasks",
            "description": "Provides access to OTBI for Talent Management and Global HR",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE7B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE886E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF96D7D8E050790A704077ED"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                }
            ]
        },
        {
            "id": "D6D75910B1A64CC58C4AD6D6BA2A2D4E",
            "meta": {
                "created": "2018-09-21 19:57:12.366",
                "lastModified": "2018-10-19 12:45:15.771",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D6D75910B1A64CC58C4AD6D6BA2A2D4E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MSC_DEMAND_AND_SUPPLY_PLANNER_JOB",
            "displayName": "Demand and Supply Planner",
            "description": "Manages, balances, and analyzes all demand and supply in the supply chain, using advanced analytical, statistical, and optimization techniques.",
            "category": "JOB"
        },
        {
            "id": "36679C50BDA446BEB632C4F45644CC36",
            "meta": {
                "created": "2018-09-21 19:57:12.544",
                "lastModified": "2018-10-19 12:45:15.826",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/36679C50BDA446BEB632C4F45644CC36"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HEY_STUDENT_RECRUITER_JOB",
            "displayName": "Student Recruiter",
            "description": "Individual responsible for recruiting prospective students.",
            "category": "JOB"
        },
        {
            "id": "2BB292CD60BD4CB38534FABAE3721718",
            "meta": {
                "created": "2018-09-21 19:57:12.626",
                "lastModified": "2018-10-19 12:45:15.860",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2BB292CD60BD4CB38534FABAE3721718"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GTR_RISK_MANAGEMENT_ADMINISTRATOR_JOB",
            "displayName": "Risk Management Administrator",
            "description": "The Risk Management Administrator is responsible for initial configuration of the application, and for continued maintenance and support for security, job management, and perspective management.",
            "category": "JOB"
        },
        {
            "id": "BEC194E3F61F4643B298F88C0EB2DCC1",
            "meta": {
                "created": "2018-09-21 19:57:13.079",
                "lastModified": "2018-10-19 12:45:16.119",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BEC194E3F61F4643B298F88C0EB2DCC1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GTR_USER_ACCESS_CERTIFICATION_MANAGER_JOB",
            "displayName": "User Access Certification Manager",
            "description": "Individual responsible for all aspects of configuration and managing access certifications.",
            "category": "JOB"
        },
        {
            "id": "D03F3C7F499A4EEFBF4B239B3E9846E0",
            "meta": {
                "created": "2018-09-21 19:57:13.109",
                "lastModified": "2018-10-19 12:45:16.127",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D03F3C7F499A4EEFBF4B239B3E9846E0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_LOY_LOYALTY_PROGRAM_ADMINISTRATOR_JOB",
            "displayName": "Loyalty Program Administrator",
            "description": "Technical User specialized in Administering the Loyalty Program from a Technical perspective.",
            "category": "JOB"
        },
        {
            "id": "B3F21C3943AF422094A130D9CDEF7D51",
            "meta": {
                "created": "2018-09-21 19:57:13.236",
                "lastModified": "2018-10-19 12:45:16.183",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B3F21C3943AF422094A130D9CDEF7D51"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_HUMAN_RESOURCE_HELP_DESK_AGENT_JOB",
            "displayName": "Human Resource Help Desk Agent",
            "category": "JOB"
        },
        {
            "id": "8FFF3776D9A0405B99F672C64DDA6BD8",
            "meta": {
                "created": "2018-09-21 19:57:13.294",
                "lastModified": "2018-10-19 12:45:16.208",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8FFF3776D9A0405B99F672C64DDA6BD8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MSC_DEMAND_PLANNER_JOB",
            "displayName": "Demand Planner",
            "description": "Manages demand plans",
            "category": "JOB"
        },
        {
            "id": "B2E0F8AF818D4E46A4AB299C210B133D",
            "meta": {
                "created": "2018-09-21 19:57:13.382",
                "lastModified": "2018-10-19 12:45:16.244",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B2E0F8AF818D4E46A4AB299C210B133D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HNS_ENVIRONMENT_HEALTH_AND_SAFETY_MANAGER_JOB",
            "displayName": "Environment, Health and Safety Manager",
            "description": "Manages the performance of operational tasks related to the support of an health and safety infrastructure.",
            "category": "JOB"
        },
        {
            "id": "2C71C5AA26A741D0ADC343180E452367",
            "meta": {
                "created": "2018-09-21 19:57:13.456",
                "lastModified": "2018-10-19 12:45:16.276",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2C71C5AA26A741D0ADC343180E452367"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HEQ_ADMISSIONS_MANAGER_JOB",
            "displayName": "Admissions Manager",
            "description": "Individual responsible for managing the operations of the student admissions office.",
            "category": "JOB"
        },
        {
            "id": "77D9FB3B395641E299AA7628803184E2",
            "meta": {
                "created": "2018-09-21 19:57:13.596",
                "lastModified": "2018-10-19 12:45:16.362",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/77D9FB3B395641E299AA7628803184E2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CSO_KNOWLEDGE_SEARCH_SERVICE_JOB",
            "displayName": "Knowledge Search Service",
            "description": "Provides the ability to search Service department articles",
            "category": "JOB"
        },
        {
            "id": "4F729984A448477088100E01D7E03491",
            "meta": {
                "created": "2018-09-21 19:57:13.848",
                "lastModified": "2018-10-19 12:45:16.479",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4F729984A448477088100E01D7E03491"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GTG_APPLICATION_ACCESS_AUDITOR",
            "displayName": "Application Access Auditor",
            "description": "Individual responsible for managing and auditing enterprise advanced access controls.",
            "category": "JOB"
        },
        {
            "id": "ACB62560288F48EABB6F09A37DC710A3",
            "meta": {
                "created": "2018-09-21 19:57:13.906",
                "lastModified": "2018-10-19 12:45:16.520",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/ACB62560288F48EABB6F09A37DC710A3"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_HUMAN_RESOURCE_HELP_DESK_MANAGER_JOB",
            "displayName": "Human Resource Help Desk Manager",
            "category": "JOB"
        },
        {
            "id": "678B7D8920C64525862330CBFB54319A",
            "meta": {
                "created": "2018-09-21 19:57:13.961",
                "lastModified": "2018-10-19 12:45:16.529",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/678B7D8920C64525862330CBFB54319A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MSC_SALES_AND_OPERATIONS_PLANNER_JOB",
            "displayName": "Sales and Operations Planner",
            "description": "Manages sales and operations plans",
            "category": "JOB"
        },
        {
            "id": "9F38C16FAB2C4C92A659608EEA896818",
            "meta": {
                "created": "2018-09-21 19:57:14.100",
                "lastModified": "2018-10-19 12:45:16.584",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/9F38C16FAB2C4C92A659608EEA896818"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZBS_SALES_READ_ONLY_JOB",
            "displayName": "Sales Read Only",
            "description": "Read only role that provides read only functionalities for Sales.",
            "category": "JOB"
        },
        {
            "id": "279BEBA76B4146DB9266C47F65004B71",
            "meta": {
                "created": "2018-09-21 19:57:14.328",
                "lastModified": "2018-10-19 12:45:16.699",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/279BEBA76B4146DB9266C47F65004B71"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FV_FEDERAL_BUDGET_MANAGER_JOB",
            "displayName": "Federal Budget Manager",
            "category": "JOB"
        },
        {
            "id": "960E484719A5487791AE9DC5EE0335CF",
            "meta": {
                "created": "2018-09-21 19:57:14.641",
                "lastModified": "2018-10-19 12:45:16.821",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/960E484719A5487791AE9DC5EE0335CF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CSO_KNOWLEDGE_SEARCH_HCM_JOB",
            "displayName": "Knowledge Search HCM",
            "description": "Provides for the ability to search HR Knowledge articles",
            "category": "JOB"
        },
        {
            "id": "2E576973B43B4CCDBBCBFA87EF6F7C2F",
            "meta": {
                "created": "2018-09-21 19:57:14.887",
                "lastModified": "2018-10-19 12:45:16.994",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2E576973B43B4CCDBBCBFA87EF6F7C2F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CSO_KNOWLEDGE_AUTHOR_HCM_JOB",
            "displayName": "Knowledge Author HCM",
            "description": "Provides for the ability to author HR articles",
            "category": "JOB"
        },
        {
            "id": "FA0FE5DD9B3641C9AA550F24A3B7FE56",
            "meta": {
                "created": "2017-09-07 14:13:21.846",
                "lastModified": "2018-10-19 12:45:15.679",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FA0FE5DD9B3641C9AA550F24A3B7FE56"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_ORGANISATIONAL_DEVELOPMENT_&_LEARNING_VIEWALL_DATA",
            "displayName": "MLC Organisational Development & Learning ViewAll",
            "description": "MLC_HR_SPCLST_OD_CUSTOM_VIEWALL_DATA",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BE839E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE808E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE728E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "DF54815210B942EE81C135CCD4907E0A",
            "meta": {
                "created": "2017-09-18 02:50:18.000",
                "lastModified": "2018-10-19 12:45:17.133",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/DF54815210B942EE81C135CCD4907E0A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "POZ_SUPPLIER_PROFILE_INQUIRY_JOB_CUSTOM",
            "displayName": "MLC Supplier Inquiry Only",
            "description": "MLC Supplier Profile Inquiry Only",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E7EAEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "81EC7BF7C1BD45A18C283C4B74A38078",
            "meta": {
                "created": "2018-09-21 19:57:16.106",
                "lastModified": "2018-10-19 12:45:17.328",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/81EC7BF7C1BD45A18C283C4B74A38078"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HEQ_ADMISSIONS_COORDINATOR_JOB",
            "displayName": "Admissions Coordinator",
            "description": "Individual responsible for coordinating student admissions.",
            "category": "JOB"
        },
        {
            "id": "C73C260F1BC84C4BA0EAA99C45EA2B18",
            "meta": {
                "created": "2017-09-07 03:11:59.026",
                "lastModified": "2018-10-19 12:45:17.871",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/C73C260F1BC84C4BA0EAA99C45EA2B18"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HEY_HIGHER_EDUCATION_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Higher Education Application Administrator",
            "description": "Manages administration of Higher Education applications.",
            "category": "JOB"
        },
        {
            "id": "12E9FFF4CDDC46BF961D435A50ABD0D3",
            "meta": {
                "created": "2017-09-07 03:11:59.038",
                "lastModified": "2018-10-19 12:45:16.387",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/12E9FFF4CDDC46BF961D435A50ABD0D3"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_BUSINESS_FLOW_TROUBLESHOOTING_ABSTRACT",
            "displayName": "Business Flow Troubleshooting",
            "description": "This role provides capabilities for enabling trace options and running diagnostic tests to troubleshoot business flows.",
            "category": "ABSTRACT"
        },
        {
            "id": "31D20E01F29546DDB5336D6E1008E2F5",
            "meta": {
                "created": "2017-09-07 03:11:59.047",
                "lastModified": "2018-10-19 12:45:16.379",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/31D20E01F29546DDB5336D6E1008E2F5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POS_SUPPLIER_DEMAND_PLANNER_JOB",
            "displayName": "Supplier Demand Planner",
            "description": "Manages supplier scheduling, supplier managed inventory and consigned inventory for the supplier company.",
            "category": "JOB"
        },
        {
            "id": "4A291953747C4004B90CAD1EFD975866",
            "meta": {
                "created": "2017-09-07 03:11:59.058",
                "lastModified": "2018-10-19 12:45:16.395",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4A291953747C4004B90CAD1EFD975866"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AP_ACCOUNTS_PAYABLE_SUPERVISOR_JOB",
            "displayName": "Accounts Payable Supervisor",
            "description": "Oversees the activities of Accounts Payables Specialists. Initiates and manages pay runs. Resolves nondata entry holds.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "3D7E1E45F6FF4B9292401810D5A8B89C",
            "meta": {
                "created": "2017-09-07 03:11:59.067",
                "lastModified": "2018-10-19 12:45:16.403",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3D7E1E45F6FF4B9292401810D5A8B89C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_APPLICATION_DEVELOPER_JOB",
            "displayName": "Application Developer",
            "description": "Provides enterprise-wide application administration needed for configuring and extending applications.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "FDBB729EFCCE4F41B30978F39C62B907",
            "meta": {
                "created": "2017-09-07 03:11:59.077",
                "lastModified": "2018-10-19 12:45:17.905",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FDBB729EFCCE4F41B30978F39C62B907"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_ENTERPRISE_CONTRACT_MANAGER_JOB",
            "displayName": "Enterprise Contract Manager",
            "description": "Manages a team of enterprise contract administrators.",
            "category": "JOB"
        },
        {
            "id": "F0F22B2E542340028E569024C11B7CF8",
            "meta": {
                "created": "2017-09-07 03:11:59.086",
                "lastModified": "2018-10-19 12:45:16.410",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F0F22B2E542340028E569024C11B7CF8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MNT_MAINTENANCE_TECHNICIAN_JOB",
            "displayName": "Maintenance Technician",
            "description": "Individual responsible for the execution and completion of any maintenance tasks, and reporting materials and resources used during the maintenance activity.",
            "category": "JOB"
        },
        {
            "id": "08A08724C6BF49F4A15A7C7D4F7E8A07",
            "meta": {
                "created": "2017-09-07 03:11:59.098",
                "lastModified": "2017-09-07 03:11:59.102",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/08A08724C6BF49F4A15A7C7D4F7E8A07"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POQ_SUPPLIER_QUALIFICATION_DISCRETIONARY",
            "displayName": "Supplier Qualification",
            "description": "This is a discretionary role provisioned to end-users on an as required basis for the purpose of performing supplier qualification duties. Supplier qualification is the process of qualifying suppliers according to a set of predefined criteria to meaningfully support the procurement function within an organization. Supplier qualification includes defining the requirements that a supplier should meet, qualifying the supplier by performing the required verification and audits, and assessing and maintaining supplier qualifications.",
            "category": "NONE"
        },
        {
            "id": "0C03C3F22BD34F3AA7999EBE05777263",
            "meta": {
                "created": "2017-09-07 03:11:59.108",
                "lastModified": "2018-10-19 12:45:17.929",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0C03C3F22BD34F3AA7999EBE05777263"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_EXECUTION_ABSTRACT",
            "displayName": "Project Execution",
            "description": "Identifies the person who manages projects in project management applications and is not assigned the project manager job role.",
            "category": "ABSTRACT"
        },
        {
            "id": "7DC3011C78684D9BBEDCA35BCB225D77",
            "meta": {
                "created": "2017-09-07 03:11:59.117",
                "lastModified": "2018-10-19 12:45:17.938",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/7DC3011C78684D9BBEDCA35BCB225D77"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_QP_PRICING_ANALYST_JOB",
            "displayName": "Pricing Analyst",
            "description": "Analyzes historical prices, trends and margins and then helps in determining future prices of products and services.",
            "category": "JOB"
        },
        {
            "id": "B5483CE269C74DACBDB4FBC0F84781FC",
            "meta": {
                "created": "2017-09-07 03:11:59.126",
                "lastModified": "2018-10-19 12:45:17.947",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B5483CE269C74DACBDB4FBC0F84781FC"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GL_GENERAL_ACCOUNTING_MANAGER_JOB",
            "displayName": "General Accounting Manager",
            "description": "Manages the general accounting functions of an enterprise including general ledger, subsidiary ledgers, and cost accounting.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA39E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "8F61B1735ECE453EA9DB57F5CFFC652E",
            "meta": {
                "created": "2017-09-07 03:11:59.134",
                "lastModified": "2018-10-19 12:45:17.957",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8F61B1735ECE453EA9DB57F5CFFC652E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZCH_TRADING_COMMUNITY_DATA_STEWARD_JOB",
            "displayName": "Customer Data Steward",
            "description": "Performs customer data management activities including data import, cleansing, duplicate identification, and duplicate resolution.",
            "category": "JOB"
        },
        {
            "id": "3BE3CCDB4DF1444FA85AB18010C1DB78",
            "meta": {
                "created": "2017-09-07 03:11:59.143",
                "lastModified": "2018-10-19 12:45:16.418",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3BE3CCDB4DF1444FA85AB18010C1DB78"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HXT_TIME_AND_LABOR_ADMINISTRATOR_JOB",
            "displayName": "Time and Labor Administrator",
            "description": "Manages time and labor system and data, resolves system errors during import of time, validation, approval and transfer processes. Maintains rules, groups, layout sets, and other maintenance tasks.",
            "category": "JOB"
        },
        {
            "id": "F4F50308000D4DE989E5566C2CF1E522",
            "meta": {
                "created": "2017-09-07 03:11:59.154",
                "lastModified": "2018-10-19 12:45:16.426",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F4F50308000D4DE989E5566C2CF1E522"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_PARTNER_ADMINISTRATOR_LIMITED_ABSTRACT",
            "displayName": "Prospective Partner Administrator",
            "description": "Views limited information about partner organization is in a status of registered or expired. This is for the partner administrator.",
            "category": "JOB"
        },
        {
            "id": "814F97CF8FF14C6DA5E363E03CA9362A",
            "meta": {
                "created": "2017-09-07 03:11:59.163",
                "lastModified": "2018-10-19 12:45:16.434",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/814F97CF8FF14C6DA5E363E03CA9362A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_PARTNER_ADMINISTRATOR_JOB",
            "displayName": "Partner Administrator",
            "description": "Registers the partner organization and program enrollment for the partner company. Manages the creation and removal of partner users and the users' privileges.",
            "category": "JOB"
        },
        {
            "id": "3CD37198BE5F467C8647CB9481702899",
            "meta": {
                "created": "2017-09-07 03:11:59.172",
                "lastModified": "2018-10-19 12:45:17.969",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3CD37198BE5F467C8647CB9481702899"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_EMPLOYEE_ABSTRACT",
            "displayName": "Employee",
            "description": "Identifies the person as an employee.",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "EB2F79EE7F0D4A399AC3B4157C07EA5F",
            "meta": {
                "created": "2017-09-07 03:11:59.181",
                "lastModified": "2018-10-19 12:45:16.442",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/EB2F79EE7F0D4A399AC3B4157C07EA5F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POS_SUPPLIER_CUSTOMER_SERVICE_REPRESENTATIVE_JOB",
            "displayName": "Supplier Customer Service Representative",
            "description": "Manages inbound purchase orders and communicates shipment activities for the supplier company . Primary tasks include tracking, acknowledging or requesting changes to new orders. Communicates order schedules that are ready to be shipped by submitting advance shipment notices, and monitors the receipt activities performed by the buying organization.",
            "category": "JOB"
        },
        {
            "id": "72F4188AB1714FB88C017640859F270E",
            "meta": {
                "created": "2017-09-07 03:11:59.190",
                "lastModified": "2018-10-19 12:45:16.450",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/72F4188AB1714FB88C017640859F270E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HRC_HUMAN_CAPITAL_MANAGEMENT_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Human Capital Management Application Administrator",
            "description": "Configures the Oracle Fusion Global Human Resources application and has access to all duty roles necessary to implement the Compensation, Workforce Deployment, and Workforce Development offerings.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE42DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "E5B96A01D8CE42C785B458D5422E1579",
            "meta": {
                "created": "2017-09-07 03:11:59.199",
                "lastModified": "2018-10-19 12:45:16.459",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E5B96A01D8CE42C785B458D5422E1579"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AP_ACCOUNTS_PAYABLE_SPECIALIST_JOB",
            "displayName": "Accounts Payable Specialist",
            "description": "Enters invoices ensuring accuracy, uniqueness, and completeness. Matches invoices to correct purchase orders or receipts ensuring that invoices comply with company policy.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "C20A4E7A20BC46E3B9F8206855EDBF8B",
            "meta": {
                "created": "2017-09-07 03:11:59.207",
                "lastModified": "2018-10-19 12:45:16.470",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/C20A4E7A20BC46E3B9F8206855EDBF8B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_WIE_PRODUCTION_SUPERVISOR_JOB",
            "displayName": "Production Supervisor",
            "description": "Individual responsible for planning, directing and coordinating production operations and activities in a manufacturing organization. This person ensures product output and quality meet established goals while remaining on budget.",
            "category": "JOB"
        },
        {
            "id": "DC84CCF25BC84A498F93FF4D20A7220D",
            "meta": {
                "created": "2017-09-07 03:11:59.218",
                "lastModified": "2018-10-19 12:45:16.488",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/DC84CCF25BC84A498F93FF4D20A7220D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POZ_SUPPLIER_ADMINISTRATOR_ABSTRACT",
            "displayName": "Supplier Administrator",
            "description": "Manages supplier profile and user provisioning.",
            "category": "ABSTRACT"
        },
        {
            "id": "6CA27DC81ED742AD9D83F2AF8C201C4E",
            "meta": {
                "created": "2017-09-07 03:11:59.228",
                "lastModified": "2018-10-19 12:45:16.496",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6CA27DC81ED742AD9D83F2AF8C201C4E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CE_TREASURY_ANALYST_JOB",
            "displayName": "Obsolete: Treasury Analyst",
            "description": "Individual responsible for performing daily treasury and cash management activities.",
            "category": "JOB"
        },
        {
            "id": "E2504211DDD94AD39797AC1E654EAF7C",
            "meta": {
                "created": "2017-09-07 03:11:59.238",
                "lastModified": "2018-10-19 12:45:17.978",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E2504211DDD94AD39797AC1E654EAF7C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_VRM_REVENUE_MANAGER_JOB",
            "displayName": "Revenue Manager",
            "description": "Manages revenue adjustments, revenue recognition, revenue accounting, approval of revenue carve-outs, creation and processing of revenue documents, and the inquiry of revenue documents and adjustments. Also manages the defining of open and closed periods and transferring entries to the general ledger.",
            "category": "JOB"
        },
        {
            "id": "A0BBEAA1C8FA42889EE936B8EAFC770A",
            "meta": {
                "created": "2017-09-07 03:11:59.248",
                "lastModified": "2018-10-19 12:45:16.537",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A0BBEAA1C8FA42889EE936B8EAFC770A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_RCV_RECEIVING_AGENT_JOB",
            "displayName": "Receiving Agent",
            "description": "Performs receiving activities such as receiving expected shipment lines, inspecting received lines, correcting received lines, and managing returns.",
            "category": "JOB"
        },
        {
            "id": "4CEC85436B3241939796072B084E4385",
            "meta": {
                "created": "2017-09-07 03:11:59.259",
                "lastModified": "2018-10-19 12:45:16.547",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4CEC85436B3241939796072B084E4385"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CSE_ASSET_ADMINISTRATOR_JOB",
            "displayName": "Asset Administrator",
            "description": "An experienced functional super user who performs asset-related tasks (setup request, transactions, updates, data audit) as directed. In addition, the Asset Administrator is responsible for general asset application maintenance (for both customer-owned and enterprise-owned assets), such as process monitoring and processing error resolution.",
            "category": "JOB"
        },
        {
            "id": "0752AB3971F84DC9A95F951400A5D707",
            "meta": {
                "created": "2017-09-07 03:11:59.269",
                "lastModified": "2018-10-19 12:45:17.988",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0752AB3971F84DC9A95F951400A5D707"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_BASIC_RECRUITER_ABSTRACT",
            "displayName": "Basic Recruiter",
            "description": "Supports integration with Oracle Taleo Recruiting Cloud Service, identifies workers with responsibilities in Oracle Taleo Recruiting Cloud Service, but without privileges in HCM. In Oracle Taleo Recruiting Cloud Service, a Basic Recruiter has limited access to the Recruiting Center and to requisitions, depending on the group membership. Depending on specific needs of each organization, you may duplicate this user type, add, or remove permissions. This default user type provides a good starting point for other recruiting support roles such as assistants and collaborators.",
            "category": "ABSTRACT"
        },
        {
            "id": "6AC41C84E0B64DFBA4161122019230A8",
            "meta": {
                "created": "2017-09-07 03:11:59.280",
                "lastModified": "2018-10-19 12:45:18.002",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6AC41C84E0B64DFBA4161122019230A8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMP_COMPENSATION_SPECIALIST_JOB",
            "displayName": "Compensation Specialist",
            "description": "Assists in the development, implementation and administration of compensation programs, policies and procedures.",
            "category": "JOB"
        },
        {
            "id": "0297B0F2ACA244C98DF2A3198CE636D1",
            "meta": {
                "created": "2017-09-07 03:11:59.289",
                "lastModified": "2018-10-19 12:45:16.559",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0297B0F2ACA244C98DF2A3198CE636D1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FOS_SUPPLY_CHAIN_CONTROLLER_JOB",
            "displayName": "Supply Chain Controller",
            "description": "Individual responsible for providing operational controller leadership and guidance to both Finance and Supply Chain Operations leaders in complex, global supply chain organizations. Responsibilities include implementation of effective global supply chain procedures and controls to ensure compliance with the legal inter-company policies the company has put in place, while ensuring goods are flowing to the customer in the most efficient manner possible.",
            "category": "JOB"
        },
        {
            "id": "178E399F96CD47B69FADA92BA5803C03",
            "meta": {
                "created": "2017-09-07 03:11:59.301",
                "lastModified": "2018-10-19 12:45:16.568",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/178E399F96CD47B69FADA92BA5803C03"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HEY_STUDENT_SERVICES_MANAGER_JOB",
            "displayName": "Student Services Manager",
            "description": "Manages student services and personal information.",
            "category": "JOB"
        },
        {
            "id": "F2081F4986084347B2A020665F2EE316",
            "meta": {
                "created": "2017-09-07 03:11:59.310",
                "lastModified": "2018-10-19 12:45:18.011",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F2081F4986084347B2A020665F2EE316"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_IRC_HIRING_MANAGER_ABSTRACT",
            "displayName": "Hiring Manager",
            "description": "Individual who can hire candidates to complete their team.",
            "category": "ABSTRACT"
        },
        {
            "id": "9B58AB0016134C5AA6A4E399331A50D0",
            "meta": {
                "created": "2017-09-07 03:11:59.321",
                "lastModified": "2018-10-19 12:45:18.020",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/9B58AB0016134C5AA6A4E399331A50D0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_PARTNER_PORTAL_USER_ABSTRACT",
            "displayName": "Partner Portal User",
            "description": "Views limited information when a partner organization is in a status of registered or expired. This role is for the partner sales representative or partner sales manager.",
            "category": "JOB"
        },
        {
            "id": "1B35D947562149038109FFC372D7DF37",
            "meta": {
                "created": "2017-09-07 03:11:59.333",
                "lastModified": "2018-10-19 12:45:18.030",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1B35D947562149038109FFC372D7DF37"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ASE_IT_AUDITOR_JOB",
            "displayName": "IT Auditor",
            "category": "JOB"
        },
        {
            "id": "62621EA051254FDD867FCE260585C815",
            "meta": {
                "created": "2017-09-07 03:11:59.346",
                "lastModified": "2018-10-19 12:45:18.040",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/62621EA051254FDD867FCE260585C815"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_CONTINGENT_WORKER_ABSTRACT",
            "displayName": "Contingent Worker",
            "description": "Identifies the person as a contingent worker.",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "D0DB0B35EEA648E8B517312E7196F430",
            "meta": {
                "created": "2017-09-07 03:11:59.358",
                "lastModified": "2018-10-19 12:45:18.051",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D0DB0B35EEA648E8B517312E7196F430"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_ENTERPRISE_CONTRACT_TEAM_MEMBER_ABSTRACT",
            "displayName": "Enterprise Contract Team Member",
            "category": "JOB"
        },
        {
            "id": "51CC50BAA998464280FEBD989882EB26",
            "meta": {
                "created": "2017-09-07 03:11:59.374",
                "lastModified": "2018-10-19 12:45:18.070",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/51CC50BAA998464280FEBD989882EB26"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_CUSTOMER_SERVICE_MANAGER_JOB",
            "displayName": "Customer Service Manager",
            "description": "Manages a group of Customer Service Reps, and would monitor the incoming call volume into the customer service department, perhaps balancing loads and reassigning work when call volume is high. This individual would monitor incoming business, and manage the demand flow to the fulfillment area. May also need to respond to escalations.",
            "category": "JOB"
        },
        {
            "id": "ABD0578B8A624EFE98315B84CDCBFDE5",
            "meta": {
                "created": "2017-09-07 03:11:59.386",
                "lastModified": "2018-10-19 12:45:18.089",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/ABD0578B8A624EFE98315B84CDCBFDE5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PAY_PAYROLL_ADMINISTRATOR_JOB",
            "displayName": "Payroll Administrator",
            "description": "Assists with running a company's payroll and responds to employees' questions concerning payroll. They run various payroll processes, print out statement of earnings, reconcile charges, reconcile time sheets, verify payroll items, and verify payroll results.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "7145C39D679C4FD5B07D1A7813120679",
            "meta": {
                "created": "2017-09-07 03:11:59.396",
                "lastModified": "2018-10-19 12:45:18.098",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/7145C39D679C4FD5B07D1A7813120679"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MKT_MARKETING_VP_JOB",
            "displayName": "Marketing VP",
            "description": "Determines high-level marketing objectives, strategies and budgets. Analyzes marketing activities to measure the effectiveness of marketing programs, reviews real-time marketing intelligence to optimize decisions throughout the marketing and sales cycle, take timely actions to influence business outcomes, and gain competitive advantage.",
            "category": "JOB"
        },
        {
            "id": "A8E8454A9C8D4872813ACB355D862A7D",
            "meta": {
                "created": "2017-09-07 03:11:59.407",
                "lastModified": "2018-10-19 12:45:18.108",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A8E8454A9C8D4872813ACB355D862A7D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZX_TAX_ADMINISTRATOR_JOB",
            "displayName": "Tax Administrator",
            "description": "Sets up technical areas and the integration with tax service providers.",
            "category": "JOB"
        },
        {
            "id": "E3FBDA29EB8B4E1095DC4E34888A7DEE",
            "meta": {
                "created": "2017-09-07 03:11:59.418",
                "lastModified": "2018-10-19 12:45:18.118",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E3FBDA29EB8B4E1095DC4E34888A7DEE"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ENQ_QUALITY_ENGINEER_JOB",
            "displayName": "Quality Engineer",
            "description": "Individual responsible for investigating and correcting product quality issues.",
            "category": "JOB"
        },
        {
            "id": "EB0BA8E2F313429997C0AA1734F558D3",
            "meta": {
                "created": "2017-09-07 03:11:59.427",
                "lastModified": "2018-10-19 12:45:18.138",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/EB0BA8E2F313429997C0AA1734F558D3"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CN_INCENTIVE_COMPENSATION_ADMINISTRATOR_JOB",
            "displayName": "Incentive Compensation Application Administrator",
            "description": "Set up incentive compensation application",
            "category": "JOB"
        },
        {
            "id": "297B7389A0AC470EBB77111B1C4E3CB0",
            "meta": {
                "created": "2017-09-07 03:11:59.443",
                "lastModified": "2018-10-19 12:45:16.613",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/297B7389A0AC470EBB77111B1C4E3CB0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FA_ASSET_ACCOUNTING_MANAGER_JOB",
            "displayName": "Asset Accounting Manager",
            "description": "Manages fixed assets department and personnel. Monitors and performs asset transactions, maintains asset books and set ups in Oracle Fusion Assets, and views asset information and accounting entries.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "43AA40883125497283AACE9C2643ECE6",
            "meta": {
                "created": "2017-09-07 03:11:59.456",
                "lastModified": "2018-10-19 12:45:18.147",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/43AA40883125497283AACE9C2643ECE6"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HEY_STUDENT_SUPPORT_ADVISOR_JOB",
            "displayName": "Student Adviser",
            "description": "Individual responsible for guiding students and prospects to assist them in meeting their educational and career goals.",
            "category": "JOB"
        },
        {
            "id": "DF8B2AAC7B864BB08610051EBDB19659",
            "meta": {
                "created": "2017-09-07 03:11:59.467",
                "lastModified": "2018-10-19 12:45:18.166",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/DF8B2AAC7B864BB08610051EBDB19659"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EGS_SUPPLIER_PRODUCT_ADMINISTRATOR_JOB",
            "displayName": "Supplier Product Administrator",
            "description": "Individual in supplier organization responsible for accessing retailer external portal, and uploading and maintaining supplier product and catalog data with the retailer. This catalog data is for both sell-side as well as buy-side transactions.",
            "category": "JOB"
        },
        {
            "id": "B2C0D8612CE54391B729A8958C4D50A2",
            "meta": {
                "created": "2017-09-07 03:11:59.480",
                "lastModified": "2018-10-19 12:45:16.622",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B2C0D8612CE54391B729A8958C4D50A2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ASM_APPLICATION_IMPLEMENTATION_MANAGER_JOB",
            "displayName": "Application Implementation Manager",
            "description": "Manages and monitors an implementation project. Configures offerings, options and features and assigns resources to tasks.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "045A9BE082054EE6B693F7D05C9C7D9B",
            "meta": {
                "created": "2017-09-07 03:11:59.491",
                "lastModified": "2018-10-19 12:45:16.629",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/045A9BE082054EE6B693F7D05C9C7D9B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZCH_DATA_STEWARD_MANAGER_JOB",
            "displayName": "Data Steward Manager",
            "description": "Manages customer data stewards and has additional privileges including assigning requests.",
            "category": "JOB"
        },
        {
            "id": "5CFC6F1AE28F4B62A10289D677440BD5",
            "meta": {
                "created": "2017-09-07 03:11:59.501",
                "lastModified": "2018-10-19 12:45:16.638",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5CFC6F1AE28F4B62A10289D677440BD5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PO_PROCUREMENT_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Procurement Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of procurement information systems.",
            "category": "JOB"
        },
        {
            "id": "98707617BF5E470689847E79F2EA7753",
            "meta": {
                "created": "2017-09-07 03:11:59.511",
                "lastModified": "2018-10-19 12:45:16.658",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/98707617BF5E470689847E79F2EA7753"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MKT_MARKETING_ANALYST_JOB",
            "displayName": "Marketing Analyst",
            "description": "Researches and analyzes marketing data and demand to influence product development and market strategies. Collaborates with corporate marketing managers to define segmentation strategies and develops criteria for identifying and grouping target audience segments for use in marketing campaigns.",
            "category": "JOB"
        },
        {
            "id": "21E98DDD39F1454D8A3E2D47B6BD0329",
            "meta": {
                "created": "2017-09-07 03:11:59.522",
                "lastModified": "2018-10-19 12:45:18.184",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/21E98DDD39F1454D8A3E2D47B6BD0329"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PO_PROCUREMENT_APPLICATION_ADMIN_JOB",
            "displayName": "Procurement Application Administrator",
            "description": "Responsible for technical aspects of keeping procurement applications systems available as well as configuring the applications to meet the needs of the business.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "36A3D60C78114CC0BB841CE702478B00",
            "meta": {
                "created": "2017-09-07 03:11:59.532",
                "lastModified": "2018-10-19 12:45:16.666",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/36A3D60C78114CC0BB841CE702478B00"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_IEX_COLLECTIONS_MANAGER_JOB",
            "displayName": "Collections Manager",
            "description": "This role is the management user in Collections.",
            "category": "JOB"
        },
        {
            "id": "D8BF2EB8090745378052DC9BFC410E4F",
            "meta": {
                "created": "2017-09-07 03:11:59.543",
                "lastModified": "2018-10-19 12:45:16.673",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D8BF2EB8090745378052DC9BFC410E4F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ACD_PRODUCT_DESIGN_MANAGER_JOB",
            "displayName": "Product Design Manager",
            "description": "Individual responsible for the business side of design, encompassing the ongoing processes, business decisions, and strategies that enable innovation and create effectively designed products.",
            "category": "JOB"
        },
        {
            "id": "974DEC47C2E041E5B57DC11199003C87",
            "meta": {
                "created": "2017-09-07 03:11:59.556",
                "lastModified": "2018-10-19 12:45:16.682",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/974DEC47C2E041E5B57DC11199003C87"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZCA_CUSTOMER_RELATIONSHIP_MANAGEMENT_INTEGRATION_SPECIALIST_JOB",
            "displayName": "Customer Relationship Management Integration Specialist",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of customer relationship management information systems.",
            "category": "JOB"
        },
        {
            "id": "55F65A79177F4B10A5260FFC4AAAA7D8",
            "meta": {
                "created": "2017-09-07 03:11:59.723",
                "lastModified": "2018-10-19 12:45:18.205",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/55F65A79177F4B10A5260FFC4AAAA7D8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_CUSTOMER_CONTRACT_MANAGER_JOB",
            "displayName": "Customer Contract Manager",
            "description": "Manages a team of customer contract administrators.",
            "category": "JOB"
        },
        {
            "id": "239B32A7FC03415BAC5FCD2AFFB54BB4",
            "meta": {
                "created": "2017-09-07 03:11:59.735",
                "lastModified": "2018-10-19 12:45:16.691",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/239B32A7FC03415BAC5FCD2AFFB54BB4"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EGI_PRODUCT_DATA_STEWARD_JOB",
            "displayName": "Product Data Steward",
            "description": "Executes change requests upon approval and maintains the quality of the product master. Responsible for data loads. Develops consistent data in accordance with the business rules of the corporation. Responsibilities also include data scrubbing, monitoring data entry exception, data de-duplication, ensuring overall data quality.",
            "category": "JOB"
        },
        {
            "id": "D7FC55919BAD4CCB893361F670D04C15",
            "meta": {
                "created": "2017-09-07 03:11:59.745",
                "lastModified": "2018-10-19 12:45:16.709",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D7FC55919BAD4CCB893361F670D04C15"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_DIAG_REGULAR_USER_JOB",
            "displayName": "Application Diagnostics Regular User",
            "description": "Runs diagnostic tests. Reviews diagnostic test results. Does not schedule diagnostic tests or add test results to application incidents..",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "2D4FA3A7C5834FD1B00C37BDDAFC3C20",
            "meta": {
                "created": "2017-09-07 03:11:59.757",
                "lastModified": "2018-10-19 12:45:16.716",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2D4FA3A7C5834FD1B00C37BDDAFC3C20"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_CUSTOMER_CONTRACT_ADMINISTRATOR_JOB",
            "displayName": "Customer Contract Administrator",
            "description": "Works with sales account teams and legal to negotiate and author customer contracts. Tracks critical contract milestones, service level agreements, and assists account teams during contract renewals and amendments.",
            "category": "JOB"
        },
        {
            "id": "F007DDB190604CBEA38136AF68D05190",
            "meta": {
                "created": "2017-09-07 03:11:59.766",
                "lastModified": "2018-10-19 12:45:16.724",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F007DDB190604CBEA38136AF68D05190"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZCA_CUSTOMER_RELATIONSHIP_MANAGEMENT_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Customer Relationship Management Application Administrator",
            "description": "Individual responsible for customer relationship management application administration. Collaborates with customer relationship management application users to maintain consistent financial application setup, rules, and access.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "5FC456EF4F9941238AC17FE0E9F56F07",
            "meta": {
                "created": "2017-09-07 03:11:59.776",
                "lastModified": "2018-10-19 12:45:18.214",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5FC456EF4F9941238AC17FE0E9F56F07"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZX_TAX_MANAGER_JOB",
            "displayName": "Tax Manager",
            "description": "Defines the tax policies and most efficient tax configuration. Sets up relatively stable entities that seldom require updates, such as tax regimes and taxes.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "14D63280266F4185BB9410EF79BEAE67",
            "meta": {
                "created": "2017-09-07 03:11:59.788",
                "lastModified": "2018-10-19 12:45:18.223",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/14D63280266F4185BB9410EF79BEAE67"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZBS_SALES_REPRESENTATIVE_JOB",
            "displayName": "Sales Representative",
            "description": "Represents the business to sell its products. Maintains relationships with customers and contacts, builds pipeline, manages leads and opportunities and performs sales forecasting.",
            "category": "JOB"
        },
        {
            "id": "6DE2DFB5284F4783A77691455DE6F281",
            "meta": {
                "created": "2017-09-07 03:11:59.799",
                "lastModified": "2018-10-19 12:45:16.731",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6DE2DFB5284F4783A77691455DE6F281"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CE_TREASURY_ACCOUNTANT_JOB",
            "displayName": "Obsolete: Treasury Accountant",
            "description": "Individual responsible for timely and accurate accounting for treasury transactions, subsequent reconciliation and reporting.",
            "category": "JOB"
        },
        {
            "id": "0EB40A0319A74C43A330C2DF42A1C307",
            "meta": {
                "created": "2017-09-07 03:11:59.810",
                "lastModified": "2018-10-19 12:45:16.738",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0EB40A0319A74C43A330C2DF42A1C307"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECTS_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Project Application Administrator",
            "description": "Collaborates with project application users to maintain consistent project application configuration, rules, and access.",
            "category": "JOB"
        },
        {
            "id": "64A3592C11DA4DE397160F24B47EC2B0",
            "meta": {
                "created": "2017-09-07 03:11:59.822",
                "lastModified": "2018-10-19 12:45:18.242",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/64A3592C11DA4DE397160F24B47EC2B0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_INV_SUPPLIER_INVENTORY_MANAGER_JOB",
            "displayName": "Supplier Inventory Manager",
            "description": "Individual in a supplier organization responsible for managing inventory process control from beginning to end. Monitors available supplies, materials and products in order to ensure that customers, employees and production have access to the materials they need.",
            "category": "JOB"
        },
        {
            "id": "E6482B7EBE194358958DE46DFEF32604",
            "meta": {
                "created": "2017-09-07 03:11:59.834",
                "lastModified": "2018-10-19 12:45:16.754",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/E6482B7EBE194358958DE46DFEF32604"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_INV_WAREHOUSE_OPERATOR_JOB",
            "displayName": "Warehouse Operator",
            "description": "Performs warehouse activities such as creating inventory transactions, processing movement requests, recording cycle and physical inventory counts, performing material put away, and confirming pick slips.",
            "category": "JOB"
        },
        {
            "id": "23EE125414F643E5AE6608F5ED07C94C",
            "meta": {
                "created": "2017-09-07 03:11:59.846",
                "lastModified": "2018-10-19 12:45:16.778",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/23EE125414F643E5AE6608F5ED07C94C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMP_COMPENSATION_ANALYST_JOB",
            "displayName": "Compensation Analyst",
            "description": "Analyzes compensation for a group of workers.",
            "category": "JOB"
        },
        {
            "id": "ADC89AD496A547449717D894DD65F66D",
            "meta": {
                "created": "2017-09-07 03:11:59.858",
                "lastModified": "2018-10-19 12:45:16.786",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/ADC89AD496A547449717D894DD65F66D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_QP_PRICING_ADMINISTRATOR_JOB",
            "displayName": "Pricing Administrator",
            "description": "Manages price execution setup, customer pricing profile, pricing segments, pricing strategies and pricing rules.",
            "category": "JOB"
        },
        {
            "id": "7E2EB75641264FCAA76D6186A2CC9289",
            "meta": {
                "created": "2017-09-07 03:11:59.867",
                "lastModified": "2018-10-19 12:45:18.279",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/7E2EB75641264FCAA76D6186A2CC9289"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_WSH_SHIPPING_AGENT_JOB",
            "displayName": "Shipping Agent",
            "description": "Records and processes outbound shipments including packing and labeling. Ensures that orders are correctly filled and captures freight, handling, and value service charges. Records weight, volume, and attributes associated with the shipment.",
            "category": "JOB"
        },
        {
            "id": "03DFEF71D73448B2B9D179123DBA694F",
            "meta": {
                "created": "2017-09-07 03:11:59.878",
                "lastModified": "2018-10-19 12:45:16.794",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/03DFEF71D73448B2B9D179123DBA694F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_ADMINISTRATOR_JOB",
            "displayName": "Project Administrator",
            "description": "Assists the project manager with the administrative functions of a project, particularly the functions related to collecting and entering information into the project application.",
            "category": "JOB"
        },
        {
            "id": "848D8C9D73E64777AA9AA92F24B83C99",
            "meta": {
                "created": "2017-09-07 03:11:59.888",
                "lastModified": "2018-10-19 12:45:18.288",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/848D8C9D73E64777AA9AA92F24B83C99"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMF_RECEIVING_SPECIALIST_JOB",
            "displayName": "Receiving Specialist",
            "description": "Normally works in the Receiving Department but in countries where duties include the capture of fiscal document financial and tax information, may report either to the Receiving Department Manager or to the Controllers Office responsible for all receiving department administrative task.",
            "category": "JOB"
        },
        {
            "id": "642D03DFDB0D4B7A95E9869F8884B80C",
            "meta": {
                "created": "2017-09-07 03:11:59.897",
                "lastModified": "2018-10-19 12:45:16.802",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/642D03DFDB0D4B7A95E9869F8884B80C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_DIAG_ADMINISTRATOR_JOB",
            "displayName": "Application Diagnostics Administrator",
            "description": "Manages diagnostic tests and data.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "47DAAF938F2F7B5BE050F40A76AB350F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "ED4054C79D77445F862B01412ECBEDFE",
            "meta": {
                "created": "2017-09-07 03:11:59.906",
                "lastModified": "2018-10-19 12:45:18.297",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/ED4054C79D77445F862B01412ECBEDFE"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_CREATOR_ABSTRACT",
            "displayName": "Project Creator",
            "description": "Identifies the person who creates projects.",
            "category": "ABSTRACT"
        },
        {
            "id": "B8A7B04E40A14BA8A06F0B35DBC71967",
            "meta": {
                "created": "2017-09-07 03:11:59.914",
                "lastModified": "2018-10-19 12:45:18.306",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B8A7B04E40A14BA8A06F0B35DBC71967"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GTG_ENTERPRISE_RISK_AND_CONTROL_MANAGER_JOB",
            "displayName": "Enterprise Risk and Control Manager",
            "description": "Individual responsible for managing enterprise risks and controls.",
            "category": "JOB"
        },
        {
            "id": "CD534CF162B847AA8F55D7D171C1625F",
            "meta": {
                "created": "2017-09-07 03:11:59.923",
                "lastModified": "2018-10-19 12:45:16.810",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/CD534CF162B847AA8F55D7D171C1625F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_BUSINESS_PRACTICES_DIRECTOR_JOB",
            "displayName": "Business Practices Director",
            "description": "Defines and manages sales or procurement contract policies and standards. Ensures all corporate contracts conform to established guidelines and best practices.",
            "category": "JOB"
        },
        {
            "id": "504BC4638F994CB684402EC9B4A7966F",
            "meta": {
                "created": "2017-09-07 03:11:59.931",
                "lastModified": "2018-10-19 12:45:18.326",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/504BC4638F994CB684402EC9B4A7966F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FUN_FIN_SCM_MFG_APPLICATION_ADMINISTRATOR_JOB",
            "displayName": "Financial Supply Chain Manufacturing Application Administrator",
            "description": "Individual responsible for administration of the financials supply chain and manufacturing pillar.",
            "category": "JOB"
        },
        {
            "id": "A67E685E67684ABE841D27AF1F3B4353",
            "meta": {
                "created": "2017-09-07 03:11:59.940",
                "lastModified": "2018-10-19 12:45:18.334",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A67E685E67684ABE841D27AF1F3B4353"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_INTERNAL_AUDITOR_JOB",
            "displayName": "Internal Auditor",
            "description": "Independent auditor responsible for internal audit and oversight activities for an enterprise including financial, operational and internal control reviews, corporate compliance reviews, and independent investigations. This individual should report to executive management, but does not replace the need for external independent auditors.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE742E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "1C928C224A9146A487B860BD326E13F0",
            "meta": {
                "created": "2017-09-07 03:11:59.948",
                "lastModified": "2018-10-19 12:45:16.829",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1C928C224A9146A487B860BD326E13F0"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CN_INCENTIVE_COMPENSATION_PARTICIPANT_ABSTRACT",
            "displayName": "Incentive Compensation Participant",
            "description": "Receive incentive compensation computed by the application and review reports",
            "category": "ABSTRACT"
        },
        {
            "id": "CE1196C363E4498B907E036C041558E5",
            "meta": {
                "created": "2017-09-07 03:11:59.959",
                "lastModified": "2018-10-19 12:45:16.852",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/CE1196C363E4498B907E036C041558E5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MKT_MARKETING_APPROVER_ABSTRACT",
            "displayName": "Marketing Approver",
            "description": "Approves partner sales lead registrations submitted by external partners.",
            "category": "JOB"
        },
        {
            "id": "0BA6864845C24E3A9054C7D8CAB8BF8B",
            "meta": {
                "created": "2017-09-07 03:11:59.967",
                "lastModified": "2018-10-19 12:45:18.342",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0BA6864845C24E3A9054C7D8CAB8BF8B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PO_PROCUREMENT_MANAGER_JOB",
            "displayName": "Procurement Manager",
            "description": "Procurement professional responsible managing a group of buyers in an organization.",
            "category": "JOB"
        },
        {
            "id": "6220F776469F463C846FCFEE19E021D3",
            "meta": {
                "created": "2017-09-07 03:11:59.976",
                "lastModified": "2018-10-19 12:45:16.874",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6220F776469F463C846FCFEE19E021D3"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MKL_SALES_LEAD_QUALIFIER_JOB",
            "displayName": "Sales Lead Qualifier",
            "description": "Identifies, generates and qualifies sales leads and ensures that they are successfully closed within established time objectives. Includes the ability to deliver reports, ensure a healthy sales pipeline volume, help shorten sales cycles, shape lead generation strategies, and provide effective guidance to the rest of the lead qualification team. Other supporting roles include territory development, event and webinar strategies.",
            "category": "JOB"
        },
        {
            "id": "375A02C651A146E1AA31B75B111B3658",
            "meta": {
                "created": "2017-09-07 03:11:59.986",
                "lastModified": "2018-10-19 12:45:18.351",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/375A02C651A146E1AA31B75B111B3658"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_XCC_BUDGET_PREPARER_JOB",
            "displayName": "Budget Preparer",
            "description": "Individual responsible for performing budget entry for one or more organizational units",
            "category": "JOB"
        },
        {
            "id": "46B415E79EC245329D72D2F63938257E",
            "meta": {
                "created": "2017-09-07 03:11:59.996",
                "lastModified": "2018-10-19 12:45:18.362",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/46B415E79EC245329D72D2F63938257E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AR_BILLING_MANAGER_JOB",
            "displayName": "Obsolete: Billing Manager",
            "description": "Manages the planning, organizing, and implementation of all billing activities.",
            "category": "JOB"
        },
        {
            "id": "D8B714B0DD3044D19F2DBB47F3D23406",
            "meta": {
                "created": "2017-09-07 03:12:00.005",
                "lastModified": "2018-10-19 12:45:18.370",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D8B714B0DD3044D19F2DBB47F3D23406"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PER_HUMAN_RESOURCE_SPECIALIST_JOB",
            "displayName": "Human Resource Specialist",
            "description": "Performs duties of a human resources specialist.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "8C2389BE75D040F9ACBB61702D2495D4",
            "meta": {
                "created": "2017-09-07 03:12:00.013",
                "lastModified": "2018-10-19 12:45:18.378",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8C2389BE75D040F9ACBB61702D2495D4"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POS_SUPPLIER_ACCOUNTS_RECEIVABLE_SPECIALIST_JOB",
            "displayName": "Supplier Accounts Receivable Specialist",
            "description": "Manages invoices and payments for the supplier company. Primary tasks include submitting invoices as well as tracking invoice and payment status.",
            "category": "JOB"
        },
        {
            "id": "1D4A2D4C6BF141DE90DB7C2722187DD2",
            "meta": {
                "created": "2017-09-07 03:12:00.020",
                "lastModified": "2018-10-19 12:45:16.885",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1D4A2D4C6BF141DE90DB7C2722187DD2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_AR_ACCOUNTS_RECEIVABLE_SPECIALIST_JOB",
            "displayName": "Accounts Receivable Specialist",
            "description": "Manages and implements all customer payment activities, including receiving customer payments and electronic remittance advice, performing cash handling activities, processing customer payments, and applying payments to customer accounts.",
            "category": "JOB",
            "members": [
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "5822400BE484E9DEE050790A70403D5F"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "5822400BE684E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE62EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA3AE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CAE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157FDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE742E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "F4082FE661634616BE87F8E79104BBB1",
            "meta": {
                "created": "2017-09-07 03:12:00.029",
                "lastModified": "2018-10-19 12:45:18.395",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F4082FE661634616BE87F8E79104BBB1"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_TEAM_MEMBER_ABSTRACT",
            "displayName": "Project Team Member",
            "description": "Identifies the person assigned to a project as a team member to perform specific roles and functions for that project.",
            "category": "ABSTRACT"
        },
        {
            "id": "B5CB4E9D090E4E3D96D223D8EC49CC04",
            "meta": {
                "created": "2017-09-07 03:12:00.038",
                "lastModified": "2018-10-19 12:45:18.403",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B5CB4E9D090E4E3D96D223D8EC49CC04"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PO_BUYER_JOB",
            "displayName": "Buyer",
            "description": "Procurement professional responsible for transactional aspects of the procurement processes.",
            "category": "JOB"
        },
        {
            "id": "B5FEBD1661504A9CB1605C0C8595EDB5",
            "meta": {
                "created": "2017-09-07 03:12:00.046",
                "lastModified": "2018-10-19 12:45:16.922",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B5FEBD1661504A9CB1605C0C8595EDB5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_DOS_SUPPLY_CHAIN_OPERATIONS_MANAGER_JOB",
            "displayName": "Supply Chain Operations Manager",
            "description": "Individual responsible for coordinating and monitoring the activities associated with executing and managing supply orders.",
            "category": "JOB"
        },
        {
            "id": "10C50CFCE320438A84444847FAA022C8",
            "meta": {
                "created": "2017-09-07 03:12:00.056",
                "lastModified": "2018-10-19 12:45:16.932",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/10C50CFCE320438A84444847FAA022C8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_DOO_ORDER_ORCHESTRATION_ERROR_RECOVERY_MANAGER_ABSTRACT",
            "displayName": "Order Orchestration Error Recovery Manager",
            "description": "Manages the recovery of data and errors that occur during order orchestration.",
            "category": "ABSTRACT"
        },
        {
            "id": "C36F965D6B19469D97B709F587880F54",
            "meta": {
                "created": "2017-09-07 03:12:00.064",
                "lastModified": "2018-10-19 12:45:16.940",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/C36F965D6B19469D97B709F587880F54"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_DIAG_ADVANCED_USER_JOB",
            "displayName": "Application Diagnostics Advanced User",
            "description": "Runs diagnostic test, reviews diagnostic test results. Schedules diagnostic tests or adds test results to application incidents.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "931E61AE5EAB45608CF79DDE882E7E24",
            "meta": {
                "created": "2017-09-07 03:12:00.072",
                "lastModified": "2018-10-19 12:45:18.419",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/931E61AE5EAB45608CF79DDE882E7E24"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_PROJECT_ACCOUNTANT_JOB",
            "displayName": "Project Accountant",
            "description": "Manages and analyzes the collection, recording, and allocation of project costs and revenue. Ensures accurate project profit and loss calculations. Analyzes budgets and actual costs. Communicates financial performance to program managers and project executives.",
            "category": "JOB"
        },
        {
            "id": "BDEA15E84F7A444F835DB3819E2BDF74",
            "meta": {
                "created": "2017-09-07 03:12:00.083",
                "lastModified": "2018-10-19 12:45:16.958",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BDEA15E84F7A444F835DB3819E2BDF74"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_GL_GENERAL_ACCOUNTANT_JOB",
            "displayName": "General Accountant",
            "description": "Records and reports financial transactions and manages revenue, expense, asset, liability and equity accounts. Responsible for recording accounting adjustments, accruals, allocations, currency revaluations and translations.",
            "category": "JOB",
            "members": [
                {
                    "value": "6C7D38CD54AAA4B7E050790A70401387"
                },
                {
                    "value": "5822400BEA4FE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73192019E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73195319E2E050790A704031FC"
                },
                {
                    "value": "5822400BEA3DE9DEE050790A70403D5F"
                },
                {
                    "value": "5CA222DA0BB21F39E050790A70407085"
                },
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE590E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE98CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE684E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE62EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3AE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF9363FDE050790A70402713"
                },
                {
                    "value": "5E305E87EF9463FDE050790A70402713"
                },
                {
                    "value": "6557927C87D330C9E050790A704076FF"
                },
                {
                    "value": "5822400BE4EDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE484E9DEE050790A70403D5F"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE591E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE83FE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157FDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE836E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE742E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE603E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE688E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "10B924C65EFF4EC7B51B52A6B6C9A0BA",
            "meta": {
                "created": "2017-09-07 03:12:00.091",
                "lastModified": "2018-10-19 12:45:16.967",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/10B924C65EFF4EC7B51B52A6B6C9A0BA"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZX_TAX_SPECIALIST_JOB",
            "displayName": "Tax Specialist",
            "description": "Maintains tax configuration, especially the variable entities that require periodic updates, such as tax rates and tax jurisdictions.",
            "category": "JOB"
        },
        {
            "id": "3F972B6F30E6430DA7B8360C922B029F",
            "meta": {
                "created": "2017-09-07 03:12:00.099",
                "lastModified": "2018-10-19 12:45:16.976",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3F972B6F30E6430DA7B8360C922B029F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HES_CASHIER_JOB",
            "displayName": "Cashier",
            "description": "Manages and implements all student payment activities, including receiving student payments and electronic remittance advice, performing cash handling activities, processing student payments, and applying payments to student accounts.",
            "category": "JOB"
        },
        {
            "id": "F4AC22FB75624ADC9D1216DD814F0CF6",
            "meta": {
                "created": "2017-09-07 03:12:00.106",
                "lastModified": "2018-10-19 12:45:16.985",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F4AC22FB75624ADC9D1216DD814F0CF6"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ZPM_PARTNER_SALES_MANAGER_JOB",
            "displayName": "Partner Sales Manager",
            "description": "Manages a set of partner sales representatives and has visibility into all of their teams' transactions and the ability to work with leads and opportunities. This role is for a partner sales manager.",
            "category": "JOB"
        },
        {
            "id": "AEE98FA8141E401ABDA30CFA0E71D647",
            "meta": {
                "created": "2017-09-07 03:12:00.114",
                "lastModified": "2017-09-07 03:12:00.118",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/AEE98FA8141E401ABDA30CFA0E71D647"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CMR_RECEIPT_ACCOUNTING_DISCRETIONARY",
            "displayName": "Receipt Accounting",
            "description": "Individual responsible for ensuring the proper costing and supply chain accounting of receipts performed in a company's inventory organizations. Tasks include scheduling and exception handling for several cost processes, specifically, invoice price variance transactions received from Payables, purchase order data sent to receipt accounting, receipt transactions received from Receiving, and receipt accounting sub-ledger accounting. Tasks also include viewing and troubleshooting receipt accounting exceptions and errors, managing and analyzing receipt cost distributions and service level agreement accounting, and managing supplier accrual accounting and reconciliation.",
            "category": "NONE"
        },
        {
            "id": "21707BAC068D4F5AA341B60800D78D55",
            "meta": {
                "created": "2017-09-07 03:12:00.121",
                "lastModified": "2018-10-19 12:45:17.004",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/21707BAC068D4F5AA341B60800D78D55"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_DIAG_VIEWER_JOB",
            "displayName": "Application Diagnostics Viewer",
            "description": "Reviews diagnostic test run status and test results for analysis.",
            "category": "JOB",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "BF3109636F9E43518976B6982AD57A4D",
            "meta": {
                "created": "2017-09-07 03:12:00.129",
                "lastModified": "2018-10-19 12:45:18.446",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BF3109636F9E43518976B6982AD57A4D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_POS_SUPPLIER_SELF_SERVICE_ADMINISTRATOR_ABSTRACT",
            "displayName": "Supplier Self Service Administrator",
            "description": "Manages the profile information for the supplier company. Primary tasks include updating supplier profile information and requesting user accounts to grant employees access to the supplier application.",
            "category": "ABSTRACT"
        },
        {
            "id": "B778F2CC7CF24344A712FAFAD7E51859",
            "meta": {
                "created": "2017-09-07 03:12:00.137",
                "lastModified": "2018-10-19 12:45:17.014",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B778F2CC7CF24344A712FAFAD7E51859"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_HXT_TIME_AND_LABOR_MANAGER_JOB",
            "displayName": "Time and Labor Manager",
            "description": "Manages setup, maintenance, and support of Time and Labor. Supervises other roles that support the Time and Labor infrastructure.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE6FEE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "57FD82CB0A88439693050E14BF959902",
            "meta": {
                "created": "2017-09-07 03:12:00.144",
                "lastModified": "2018-10-19 12:45:18.454",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/57FD82CB0A88439693050E14BF959902"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_BEN_BENEFITS_ADMINISTRATOR_JOB",
            "displayName": "Benefits Administrator",
            "description": "Manages administration of benefits business objects and batch processes.",
            "category": "JOB"
        },
        {
            "id": "B6FFA60EA7A6498DA0E5B30715A8B6D2",
            "meta": {
                "created": "2017-09-07 03:12:00.153",
                "lastModified": "2018-10-19 12:45:17.024",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B6FFA60EA7A6498DA0E5B30715A8B6D2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_DOO_ORDER_ADMINISTRATOR_JOB",
            "displayName": "Order Administrator",
            "description": "Configures all setup-related activities for order orchestration or order promising.",
            "category": "JOB"
        },
        {
            "id": "FBBE1253F7034F4EBE5630F312BBCCA8",
            "meta": {
                "created": "2017-09-07 03:12:00.161",
                "lastModified": "2018-10-19 12:45:17.033",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FBBE1253F7034F4EBE5630F312BBCCA8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_IRC_RECRUITER_JOB",
            "displayName": "Recruiter",
            "description": "Individual who supports the recruitment process by pursuing and evaluating potential candidates. Also manages recruiting sites and job postings.",
            "category": "JOB"
        },
        {
            "id": "18CBF3DC10D54834AB537CC2EE196FD8",
            "meta": {
                "created": "2017-09-07 03:12:00.170",
                "lastModified": "2018-10-19 12:45:17.041",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/18CBF3DC10D54834AB537CC2EE196FD8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_OKC_SUPPLIER_CONTRACT_TEAM_MEMBER_ABSTRACT",
            "displayName": "Supplier Contract Team Member",
            "category": "JOB"
        },
        {
            "id": "DA0A24DD25204F0BB91095EED6B7E274",
            "meta": {
                "created": "2017-09-07 03:12:00.178",
                "lastModified": "2018-10-19 12:45:18.463",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/DA0A24DD25204F0BB91095EED6B7E274"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_PJF_RESOURCE_MANAGER_JOB",
            "displayName": "Resource Manager",
            "description": "Manages a group of resources who are employees or contingent workers. Monitors the utilization of resources and manages the assignment of resources to work on projects. Collaborates with project managers to find suitable resources to fulfill project resources requests.",
            "category": "JOB"
        },
        {
            "id": "BA72BFB0E0E54E9AA76AB4C3318FB49C",
            "meta": {
                "created": "2017-09-07 06:02:17.000",
                "lastModified": "2018-10-19 12:45:18.195",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BA72BFB0E0E54E9AA76AB4C3318FB49C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_EMP_CUSTOM",
            "displayName": "MLC Employee",
            "description": "Identifies the person as an custom employee role for MLC",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "655792DFDFD6D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE7EBE9DEE050790A70403D5F"
                },
                {
                    "value": "766B01096A14A70EE050790A6740E718"
                },
                {
                    "value": "5822400BE804E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE80CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE814E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE819E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE820E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE822E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE828E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE649E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE837E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE83BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE83EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE845E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE846E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE84CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE856E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE064D7D8E050790A704077ED"
                },
                {
                    "value": "766B015D142FF611E050790A6740E7B7"
                },
                {
                    "value": "766B0164F6187F36E050790A6740E7C6"
                },
                {
                    "value": "5822400BE862E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C878730C9E050790A704076FF"
                },
                {
                    "value": "655792DFE067D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE869E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE86FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE873E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE874E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE875E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE879E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE87DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE886E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE88AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE88EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE892E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE895E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE898E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8ABE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8ADE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8C2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8C9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8C7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8CDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8DAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8DCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8E2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8E4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8E8E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE1A3D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE8EAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8FAE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88DD30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE900E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE904E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE907E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE908E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE90FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE910E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE915E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE916E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88E930C9E050790A704076FF"
                },
                {
                    "value": "5822400BE64EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE65DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE665E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54A1A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE675E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE68AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE690E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE698E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE69FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6B4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C5E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ECFC634CE050790A70401414"
                },
                {
                    "value": "5822400BE6D7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6E3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6EDE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ECFF634CE050790A70401414"
                },
                {
                    "value": "5822400BE701E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE708E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE711E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE723E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ED0D634CE050790A70401414"
                },
                {
                    "value": "5822400BE738E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE73EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE74EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE764E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE773E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE780E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE790E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A8E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54A5A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE7B5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7BDE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E61AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE7CDE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73190919E2E050790A704031FC"
                },
                {
                    "value": "5822400BE76DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7ECE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E63AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE80AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE812E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE817E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE825E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE835E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE842E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE849E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE64DE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9DD3DC67C113E050790A7040327A"
                },
                {
                    "value": "5822400BE659E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE666E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE668E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE66EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE670E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE676E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE67AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE67FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE682E9DEE050790A70403D5F"
                },
                {
                    "value": "5CA22278FA8DAE1FE050790A70407008"
                },
                {
                    "value": "5822400BE68FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE694E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE696E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE69DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6ACE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6B3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6D0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6D1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6D9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6DFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6E9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6FDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6FEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE705E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE70DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE715E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE716E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE71EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE727E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE72CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE734E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE73BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE73FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE743E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE74CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE75AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE760E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE762E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE76AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE770E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD152BDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE781E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE784E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE78EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE796E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE799E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7ABE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7ADE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7BEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7C8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7D1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7D9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7DCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E2E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EFFB63FDE050790A70402713"
                },
                {
                    "value": "5E305E244E7AAEBBE050790A7040267D"
                },
                {
                    "value": "58223FAD152ADEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE68EE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE0B1D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE6A0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6DAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CBE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE0B2D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C87D630C9E050790A704076FF"
                },
                {
                    "value": "5822400BE718E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE720E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE729E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE739E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE742E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE74AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE759E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE776E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE674E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE67CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE67EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE685E9DEE050790A70403D5F"
                },
                {
                    "value": "766B0164F6117F36E050790A6740E7C6"
                },
                {
                    "value": "5822400BE69AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6B8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6BFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6D6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6DDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6E6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6EEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6FCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE703E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE70AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE71DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE725E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE736E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE73AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE741E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE749E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE74FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE75BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE763E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE679E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE67BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE681E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE684E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE68BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE68DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE691E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE697E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE699E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE69BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE69EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6A9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6AAE9DEE050790A70403D5F"
                },
                {
                    "value": "766B015D1431F611E050790A6740E7B7"
                },
                {
                    "value": "655792DFE139D7D8E050790A704077ED"
                },
                {
                    "value": "766B015F030C91D3E050790A6740E7BC"
                },
                {
                    "value": "5822400BE6B6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6B7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6BDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6BEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C3E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C886930C9E050790A704076FF"
                },
                {
                    "value": "5822400BE6C6E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4792B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE6D2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6D4E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88D030C9E050790A704076FF"
                },
                {
                    "value": "5822400BE6DCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6E0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6E2E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE19AD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE6E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6EFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6FBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE700E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE707E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE70BE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88D430C9E050790A704076FF"
                },
                {
                    "value": "5822400BE70FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE713E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE714E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE719E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE71AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE721E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE722E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE728E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE72AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE735E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE737E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE0B0D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE73DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE740E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE745E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE74BE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE13AD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE74DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE75EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE765E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE76BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE76EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE772E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE771E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE775E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE777E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE77AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE778E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE77EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE77FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE782E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE783E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE785E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF47D7D8E050790A704077ED"
                },
                {
                    "value": "5E305E244E7FAEBBE050790A7040267D"
                },
                {
                    "value": "5E305E87EFF663FDE050790A70402713"
                },
                {
                    "value": "5822400BE78CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE78DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE791E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE793E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE794E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE795E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE79AE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE063D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE79CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7AAE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88B830C9E050790A704076FF"
                },
                {
                    "value": "5822400BE7AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7BAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7C0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7C2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7C1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7C5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7C6E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F3592B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE7C9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7CEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7CFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7D0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7D3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7D7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7D8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7DFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA47E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87F14463FDE050790A70402713"
                },
                {
                    "value": "6557927C86F930C9E050790A704076FF"
                },
                {
                    "value": "6557927C886E30C9E050790A704076FF"
                },
                {
                    "value": "655792DFE182D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88E030C9E050790A704076FF"
                },
                {
                    "value": "655792DFE1B4D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88DA30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE87FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE633E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8C1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8BFE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C886C30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE8FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE91CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE686E9DEE050790A70403D5F"
                },
                {
                    "value": "5CA222DA0BC01F39E050790A70407085"
                },
                {
                    "value": "5CA222DA0BC11F39E050790A70407085"
                },
                {
                    "value": "5E305E244E85AEBBE050790A7040267D"
                },
                {
                    "value": "5E305E87F14363FDE050790A70402713"
                },
                {
                    "value": "5822400BEA4CE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C873A30C9E050790A704076FF"
                },
                {
                    "value": "5CA222DA0BB71F39E050790A70407085"
                },
                {
                    "value": "5CA222DA0BB81F39E050790A70407085"
                },
                {
                    "value": "5CA222DA0BB91F39E050790A70407085"
                },
                {
                    "value": "5CA222DA0BBA1F39E050790A70407085"
                },
                {
                    "value": "5CA222DA0BBC1F39E050790A70407085"
                },
                {
                    "value": "6557927C88E130C9E050790A704076FF"
                },
                {
                    "value": "6EAD9D73191B19E2E050790A704031FC"
                },
                {
                    "value": "5822400BEA4AE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15D8DEECE050790A70403CA4"
                },
                {
                    "value": "5CA22278FA84AE1FE050790A70407008"
                },
                {
                    "value": "5E305E244E19AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE789E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244FD3AEBBE050790A7040267D"
                },
                {
                    "value": "5E305E87F14A63FDE050790A70402713"
                },
                {
                    "value": "6557927C87CF30C9E050790A704076FF"
                },
                {
                    "value": "6557927C88C330C9E050790A704076FF"
                },
                {
                    "value": "6557927C88D930C9E050790A704076FF"
                },
                {
                    "value": "6EAD9D73191719E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73192019E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC68C113E050790A7040327A"
                },
                {
                    "value": "5CA222DA0BBE1F39E050790A70407085"
                },
                {
                    "value": "5E305E87F14263FDE050790A70402713"
                },
                {
                    "value": "655792DFDF4FD7D8E050790A704077ED"
                },
                {
                    "value": "6557927C87D330C9E050790A704076FF"
                },
                {
                    "value": "655792DFE192D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE6C8E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54A6A4B7E050790A70401387"
                },
                {
                    "value": "5E305E87F07D63FDE050790A70402713"
                },
                {
                    "value": "5E305E87F0BF63FDE050790A70402713"
                },
                {
                    "value": "655792DFE0AED7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE761E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE18BD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE18CD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE191D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1B6D7D8E050790A704077ED"
                },
                {
                    "value": "6EAD9D73190E19E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73194F19E2E050790A704031FC"
                },
                {
                    "value": "5E305E87EF9563FDE050790A70402713"
                },
                {
                    "value": "5E305E244E7EAEBBE050790A7040267D"
                },
                {
                    "value": "6557927C887130C9E050790A704076FF"
                },
                {
                    "value": "655792DFE186D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFDF95D7D8E050790A704077ED"
                },
                {
                    "value": "6EAD9D73195319E2E050790A704031FC"
                },
                {
                    "value": "5822400BE4B6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4BAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4CEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4E4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4EBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4F1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4F8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE505E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE512E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE51DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE526E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE533E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE53BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE604E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE635E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE636E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE8FE135E050790A70400B1B"
                },
                {
                    "value": "5822400BE63BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE63FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE642E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE9CE135E050790A70400B1B"
                },
                {
                    "value": "5822400BE643E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE645E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE648E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE64BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE64CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE64FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE651E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE653E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE655E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE658E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE65AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE65BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE65CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE65FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE662E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE663E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD549AA4B7E050790A70401387"
                },
                {
                    "value": "5822400BE669E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE66BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE66CE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "5822400BE672E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE673E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1526DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE436E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE446E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE44DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE455E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE45DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE468E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE46EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE474E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE47CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE484E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE48BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE49DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE57CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE584E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5AEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5C0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E8E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191619E2E050790A704031FC"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE582E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE58AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE592E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE599E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5B5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5C4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5CEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5DCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F8E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244FD1AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE600E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE60CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE614E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE61CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE631E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C866E30C9E050790A704076FF"
                },
                {
                    "value": "655792DFDF4AD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE4BEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4DDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4EAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE502E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE550E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ED0A634CE050790A70401414"
                },
                {
                    "value": "5822400BE55EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE562E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE56BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE571E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE573E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE609E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE91E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE60BE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4C92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE611E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE618E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE61AE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE93E135E050790A70400B1B"
                },
                {
                    "value": "58223FAD1524DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE439E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE440E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE447E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE458E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE46CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE477E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE96E135E050790A70400B1B"
                },
                {
                    "value": "73A1976DCE97E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE49FE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE99E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE61BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE620E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE621E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE9BE135E050790A70400B1B"
                },
                {
                    "value": "5822400BE623E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE627E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE628E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F5592B0E050790A70400AE8"
                },
                {
                    "value": "5E305E244E80AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE62FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE630E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE632E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4CDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4BCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4E9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4FBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE519E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE553E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE55AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE560E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE567E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE56FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE578E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE580E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE593E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5B1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5C1E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EFFC63FDE050790A70402713"
                },
                {
                    "value": "766B01096A10A70EE050790A6740E718"
                },
                {
                    "value": "5822400BE459E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8BAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE47AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE492E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE499E9DEE050790A70403D5F"
                },
                {
                    "value": "766B0161AAE4363FE050790A6740E7C1"
                },
                {
                    "value": "766B01553A62A826E050790A6740E7AD"
                },
                {
                    "value": "5822400BE51EE9DEE050790A70403D5F"
                },
                {
                    "value": "766B0161AAE5363FE050790A6740E7C1"
                },
                {
                    "value": "766B0167BE3D7672E050790A6740E7CB"
                },
                {
                    "value": "5822400BE536E9DEE050790A70403D5F"
                },
                {
                    "value": "766B0161AAE6363FE050790A6740E7C1"
                },
                {
                    "value": "5822400BE57EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE587E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE58FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5ABE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5B2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5C2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8EFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54AAA4B7E050790A70401387"
                },
                {
                    "value": "5822400BE8F9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8FCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8FDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE902E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE905E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE90AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE90BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE90CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE917E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE919E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE91AE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191219E2E050790A704031FC"
                },
                {
                    "value": "5822400BE923E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE927E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE92AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE947E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE95FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE962E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE963E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE969E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE96BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE96CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE96EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE96FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE970E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7EEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7F4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7F8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE808E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE80EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE81AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE821E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE82AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE839E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE841E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE847E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE84EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE865E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE86EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE87CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE884E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE88DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE894E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8E5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8EDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE906E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE90DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE91BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE929E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE92EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE930E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE932E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE934E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE93AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE93BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE941E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE945E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE948E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE94AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE94BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE955E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE957E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE95AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE95CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7EAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7EFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7F1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7F6E9DEE050790A70403D5F"
                },
                {
                    "value": "766B0161AAE2363FE050790A6740E7C1"
                },
                {
                    "value": "5822400BE7FEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE801E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE806E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE809E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE810E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE811E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE815E9DEE050790A70403D5F"
                },
                {
                    "value": "766B01096A12A70EE050790A6740E718"
                },
                {
                    "value": "766B0164F6147F36E050790A6740E7C6"
                },
                {
                    "value": "5822400BE81BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE81CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE81FE9DEE050790A70403D5F"
                },
                {
                    "value": "766B015D142EF611E050790A6740E7B7"
                },
                {
                    "value": "5822400BE829E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE82BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE82CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE831E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EFFA63FDE050790A70402713"
                },
                {
                    "value": "5822400BE834E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE836E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE83FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE840E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE844E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE848E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE84AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE84BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE851E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE852E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE853E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE859E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE85BE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE065D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE863E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE864E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF8463FDE050790A70402713"
                },
                {
                    "value": "5822400BE86DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE871E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E16AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE876E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE877E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE878E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE87BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE87EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE880E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE883E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE885E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF8863FDE050790A70402713"
                },
                {
                    "value": "5822400BE888E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE88FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE893E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE89EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8ACE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8BEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8C6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8CBE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE066D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE8D1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8D9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8DDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8E3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8E6E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C8DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD153ADEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE97DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE98FE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1551DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1555DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1556DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1561DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9BFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1582DEECE050790A70403CA4"
                },
                {
                    "value": "6557927C867430C9E050790A704076FF"
                },
                {
                    "value": "5822400BE9FBE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF92D7D8E050790A704077ED"
                },
                {
                    "value": "58223FAD152DDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1594DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9DCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9DBE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD158DDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD158CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9D7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9D3E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1585DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9CEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8ECE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8CEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE91DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE925E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE933E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE93CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE942E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE950E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE956E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE95BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE95EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE961E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE964E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE967E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE96AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9E3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE93FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA45E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE928E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE92FE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD5497A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE93DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE943E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE94CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE953E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE958E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE95DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE98BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE972E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1591DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE986E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9C0E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD152FDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9F3E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157FDEECE050790A70403CA4"
                },
                {
                    "value": "766B015871E04917E050790A6740E7B2"
                },
                {
                    "value": "766B01553A68A826E050790A6740E7AD"
                },
                {
                    "value": "5822400BE827E9DEE050790A70403D5F"
                },
                {
                    "value": "766B0167BE3C7672E050790A6740E7CB"
                },
                {
                    "value": "5822400BE91EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE926E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE93EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE944E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE94DE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                },
                {
                    "value": "73A1970D2F4A92B0E050790A70400AE8"
                },
                {
                    "value": "73A1970D2F4B92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BEA1FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA21E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA22E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA23E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA24E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA25E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA27E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA28E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA29E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ED02634CE050790A70401414"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BEA2CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA2DE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EFF763FDE050790A70402713"
                },
                {
                    "value": "5E305E244E1BAEBBE050790A7040267D"
                },
                {
                    "value": "5E305E244E1FAEBBE050790A7040267D"
                },
                {
                    "value": "766B015871E34917E050790A6740E7B2"
                },
                {
                    "value": "766B015871E24917E050790A6740E7B2"
                },
                {
                    "value": "766B015D142BF611E050790A6740E7B7"
                },
                {
                    "value": "6557927C88CF30C9E050790A704076FF"
                },
                {
                    "value": "58223FAD15CCDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA3CE9DEE050790A70403D5F"
                },
                {
                    "value": "5CA22278FA85AE1FE050790A70407008"
                },
                {
                    "value": "5822400BE5F9E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E65AEBBE050790A7040267D"
                },
                {
                    "value": "655792DFE1A2D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFDFD8D7D8E050790A704077ED"
                },
                {
                    "value": "766B015871EA4917E050790A6740E7B2"
                },
                {
                    "value": "655792DFE1ADD7D8E050790A704077ED"
                },
                {
                    "value": "6C7D38CD54A0A4B7E050790A70401387"
                },
                {
                    "value": "6EAD9DD3DC57C113E050790A7040327A"
                },
                {
                    "value": "5E305E87EF9463FDE050790A70402713"
                },
                {
                    "value": "58223FAD15C9DEECE050790A70403CA4"
                },
                {
                    "value": "5E305E244FD2AEBBE050790A7040267D"
                },
                {
                    "value": "6C7D3930ED00634CE050790A70401414"
                },
                {
                    "value": "6557927C878E30C9E050790A704076FF"
                },
                {
                    "value": "5822400BEA43E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE938E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15D7DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE914E9DEE050790A70403D5F"
                },
                {
                    "value": "5CA222DA0BB51F39E050790A70407085"
                },
                {
                    "value": "6557927C88CD30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE70EE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87F0C063FDE050790A70402713"
                },
                {
                    "value": "5E305E87F10163FDE050790A70402713"
                },
                {
                    "value": "5E305E244FD4AEBBE050790A7040267D"
                },
                {
                    "value": "5E305E87F14B63FDE050790A70402713"
                },
                {
                    "value": "5822400BEA39E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA38E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA37E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA36E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3AE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE0F9D7D8E050790A704077ED"
                },
                {
                    "value": "6C7D38CD5498A4B7E050790A70401387"
                },
                {
                    "value": "6EAD9D73195219E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC56C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73190A19E2E050790A704031FC"
                },
                {
                    "value": "5822400BEA3EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F4E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15D5DEECE050790A70403CA4"
                },
                {
                    "value": "5E305E244F8AAEBBE050790A7040267D"
                },
                {
                    "value": "5CA22278FA86AE1FE050790A70407008"
                },
                {
                    "value": "5822400BE9CFE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191419E2E050790A704031FC"
                },
                {
                    "value": "5822400BEA4FE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54A8A4B7E050790A70401387"
                },
                {
                    "value": "655792DFE13BD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE13CD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE140D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1BAD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE0F3D7D8E050790A704077ED"
                },
                {
                    "value": "6EAD9D73191519E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73191919E2E050790A704031FC"
                },
                {
                    "value": "655792DFDF4DD7D8E050790A704077ED"
                },
                {
                    "value": "5E305E87EFF163FDE050790A70402713"
                },
                {
                    "value": "5CA222DA0BB21F39E050790A70407085"
                },
                {
                    "value": "5CA22278FA91AE1FE050790A70407008"
                },
                {
                    "value": "5CA22278FA92AE1FE050790A70407008"
                },
                {
                    "value": "5CA22278FA93AE1FE050790A70407008"
                },
                {
                    "value": "6EAD9DD3DC58C113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC93C113E050790A7040327A"
                },
                {
                    "value": "7336E6C2C53A362EE050790A704017B2"
                },
                {
                    "value": "7336E66670BA9A93E050790A70401780"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "73A1976DCEA5E135E050790A70400B1B"
                },
                {
                    "value": "766B015F030691D3E050790A6740E7BC"
                },
                {
                    "value": "766B0161AADE363FE050790A6740E7C1"
                },
                {
                    "value": "766B0161AAE7363FE050790A6740E7C1"
                },
                {
                    "value": "766B0161AAE9363FE050790A6740E7C1"
                },
                {
                    "value": "766B015871DF4917E050790A6740E7B2"
                },
                {
                    "value": "73A1976DCEA7E135E050790A70400B1B"
                },
                {
                    "value": "766B0167BE3E7672E050790A6740E7CB"
                },
                {
                    "value": "766B015F030891D3E050790A6740E7BC"
                },
                {
                    "value": "766B0164F6177F36E050790A6740E7C6"
                },
                {
                    "value": "58223FAD1525DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE432E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE43AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE443E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE449E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE456E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE466E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE46DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE476E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE47FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE488E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE490E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE498E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A7E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF96D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE4BFE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF90D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE4C9E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C86B530C9E050790A704076FF"
                },
                {
                    "value": "73A1976DCE85E135E050790A70400B1B"
                },
                {
                    "value": "655792DFDF93D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE4EFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4F6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE506E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE515E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1522DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE435E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE43DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE44AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE44FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE457E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE45EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE464E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE46AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE471E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE478E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE47EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE486E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE48DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE494E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE49AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE51CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE523E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE525E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE52BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE52CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE532E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE534E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE53AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE53EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE544E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE546E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54CE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F3E92B0E050790A70400AE8"
                },
                {
                    "value": "73A1976DCE87E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE574E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE594E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5BFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5C7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5C8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5DBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5EBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5EDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE603E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD5491A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE535E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF91D7D8E050790A704077ED"
                },
                {
                    "value": "73A1970D2F5292B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE565E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE56DE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88B730C9E050790A704076FF"
                },
                {
                    "value": "5822400BE588E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE590E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE591E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE596E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE59EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5B3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5BBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5BDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5BEE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCEA0E135E050790A70400B1B"
                },
                {
                    "value": "766B0161AADD363FE050790A6740E7C1"
                },
                {
                    "value": "5822400BE42DE9DEE050790A70403D5F"
                },
                {
                    "value": "766B0161AAEA363FE050790A6740E7C1"
                },
                {
                    "value": "766B015871E84917E050790A6740E7B2"
                },
                {
                    "value": "5822400BE5CFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D5E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE068D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE5DDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5DFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5EEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FDE9DEE050790A70403D5F"
                },
                {
                    "value": "766B015F030B91D3E050790A6740E7BC"
                },
                {
                    "value": "5822400BE60DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE60FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE615E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE617E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE625E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C878C30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE5D4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5DEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5ECE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE605E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE60EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE616E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE61FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE626E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE62CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE62EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE634E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE63CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE640E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE646E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE647E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE437E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE43FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE453E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE45BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE462E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE481E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE487E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE48FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE496E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE49EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4ADE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4B4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4BDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4DCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4E3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4ECE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4F2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE507E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE517E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1521DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE434E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE445E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE44CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE454E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE463E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE46BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE473E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE47BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE483E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4ABE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4B2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4CFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4DFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4E6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4EEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4F9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE510E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE518E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE520E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE521E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE528E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE529E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE52EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE52FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE537E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE539E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE541E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE542E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE549E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE551E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE552E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE559E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE55BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE561E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE563E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE568E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE56AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE572E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE577E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE57BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE583E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE460E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE475E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE48EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE49CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D6E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E18AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE4EDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE501E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE509E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE527E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF9363FDE050790A70402713"
                },
                {
                    "value": "73A1976DCE9FE135E050790A70400B1B"
                },
                {
                    "value": "5822400BE971E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE990E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9B8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE989E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1570DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9BDE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157ADEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD157DDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9B7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE982E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9ACE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1588DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA18E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1537DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9EAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9DFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1553DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15B3DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD156CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA02E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1539DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA0CE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1565DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA15E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE98DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9FAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9B5E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1584DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A2E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD154DDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE99DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA0FE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1543DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A0E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD155FDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9ABE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD156ADEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9B2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1583DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1586DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15A1DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9FEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9E6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE997E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157BDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE97AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE980E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1545DEECE050790A70403CA4"
                },
                {
                    "value": "766B01553A67A826E050790A6740E7AD"
                },
                {
                    "value": "5822400BE98EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9B0E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88B530C9E050790A704076FF"
                },
                {
                    "value": "6557927C88B630C9E050790A704076FF"
                },
                {
                    "value": "58223FAD1574DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9C8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9DAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9DDE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1598DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD159ADEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9ECE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA0AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE97CE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1546DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE978E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1554DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD155CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9B6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9D1E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD158ADEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD158FDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD159DDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15A2DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA05E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA13E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15AFDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE987E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA07E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE985E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15B2DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15A7DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1547DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1535DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15ACDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA06E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE977E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15BEDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15AEDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1531DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9F9E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1532DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1534DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9FFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15BDDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15A4DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9F1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE984E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9F5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE97BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA1AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE97FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA1CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9EEE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1542DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD159CDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15A5DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15A0DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9F0E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD152EDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9E9E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1599DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE973E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1597DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE98CE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1563DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9A7E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191A19E2E050790A704031FC"
                },
                {
                    "value": "5822400BE9BCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9BEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9C6E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9EDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9F2E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA09E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA0BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA0EE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15BBDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1589DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9D6E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD158BDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9D9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9C7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9D0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9D2E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD153EDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1540DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE97EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE983E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1548DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE991E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1573DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1576DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9BAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9C5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9C4E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD156FDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1572DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD156EDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1568DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD156BDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9B4E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1564DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1557DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD155BDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9AFE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1578DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1592DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE7D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244FCBAEBBE050790A7040267D"
                },
                {
                    "value": "58223FAD159EDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15B6DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1566DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD155EDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE998E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE996E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE993E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE99CE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD154FDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1552DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE995E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA17E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C886730C9E050790A704076FF"
                },
                {
                    "value": "5822400BEA19E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15ADDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1575DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE975E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE976E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD153DDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9A8E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1581DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1587DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9D8E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD158EDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9E4E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15BFDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA1BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE979E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15BCDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD153BDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA00E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15ABDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA14E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9F6E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15B9DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE98AE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C886F30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE9FCE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15B5DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD154ADEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD153CDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD154EDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9ADE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE183D7D8E050790A704077ED"
                },
                {
                    "value": "766B0161AAED363FE050790A6740E7C1"
                },
                {
                    "value": "6557927C886830C9E050790A704076FF"
                },
                {
                    "value": "766B0164F6127F36E050790A6740E7C6"
                },
                {
                    "value": "766B01553A65A826E050790A6740E7AD"
                },
                {
                    "value": "5822400BE7A2E9DEE050790A70403D5F"
                },
                {
                    "value": "766B01553A61A826E050790A6740E7AD"
                },
                {
                    "value": "73A1976DCEA1E135E050790A70400B1B"
                },
                {
                    "value": "766B0161AAE3363FE050790A6740E7C1"
                },
                {
                    "value": "766B01096A0EA70EE050790A6740E718"
                },
                {
                    "value": "766B015F030791D3E050790A6740E7BC"
                },
                {
                    "value": "766B0164F6137F36E050790A6740E7C6"
                }
            ]
        },
        {
            "id": "1552FE36C7DB4369A342C6E38177305C",
            "meta": {
                "created": "2017-09-07 06:02:19.000",
                "lastModified": "2018-10-19 12:45:17.235",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1552FE36C7DB4369A342C6E38177305C"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "POR_PROCUREMENT_REQUESTER_ABSTRACT_CUSTOM",
            "displayName": "Procurement Requester Custom",
            "description": "Prepares requisitions for themselves.",
            "category": "ABSTRACT"
        },
        {
            "id": "62943B007EDF421B8C1CEEDE37FD46CE",
            "meta": {
                "created": "2017-09-07 06:55:11.000",
                "lastModified": "2018-10-19 12:45:16.576",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/62943B007EDF421B8C1CEEDE37FD46CE"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_HR_SPCLST_PEOPLE_PARTNER_CUSTOM",
            "displayName": "MLC People Partner",
            "description": "Custom role to perform duties of a human resources analyst.",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EF8463FDE050790A70402713"
                },
                {
                    "value": "5822400BE7B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6AAE9DEE050790A70403D5F"
                },
                {
                    "value": "766B01096A12A70EE050790A6740E718"
                },
                {
                    "value": "5822400BE886E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "7EAA7BB98D7940138C584F87E2575C40",
            "meta": {
                "created": "2017-09-07 06:28:33.000",
                "lastModified": "2018-10-19 12:45:17.896",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/7EAA7BB98D7940138C584F87E2575C40"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_People_Solution_Approvers",
            "displayName": "MLC People Solution Approvers",
            "description": "Workflow approver role for People Solution Team",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "835D1625CC794439BC51103656FF077A",
            "meta": {
                "created": "2017-09-07 06:34:07.000",
                "lastModified": "2018-10-19 12:45:17.558",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/835D1625CC794439BC51103656FF077A"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_HR_MODELAPPROVER_CUSTOM",
            "displayName": "MLC Workforce Model Approver",
            "description": "Workflow approver role for workforce model",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "3498C7D725274B648B492E744F9E1C68",
            "meta": {
                "created": "2017-09-07 06:37:35.000",
                "lastModified": "2018-10-19 12:45:18.411",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3498C7D725274B648B492E744F9E1C68"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_STANDARD_NAVIGATION_CUSTOM",
            "displayName": "MLC Standard Navigation",
            "description": "Custom role having access to tasks : Manage Reports and Analytics,Manage File Import and Export, Manage Scheduled Processes, Download Desktop Integrator ",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C87D330C9E050790A704076FF"
                },
                {
                    "value": "6EAD9D73195319E2E050790A704031FC"
                },
                {
                    "value": "5822400BEA3DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE484E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E7EAEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE919E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "5E305E87EF9463FDE050790A70402713"
                },
                {
                    "value": "5822400BE5A4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE848E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE906E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE859E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE590E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE98CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE684E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA39E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE62EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4F9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE713E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9F0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA4FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4EDE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73192019E2E050790A704031FC"
                },
                {
                    "value": "5CA222DA0BB21F39E050790A70407085"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1556DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE812E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E8E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6C1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4C4E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7BDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE591E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE83FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CCE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE460E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE87BE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157FDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1574DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE836E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE742E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE603E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE688E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6AAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE886E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "BC8C7BAA06504BC2B9C17AB61645DBB8",
            "meta": {
                "created": "2017-09-07 07:12:22.000",
                "lastModified": "2018-10-19 12:45:17.143",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/BC8C7BAA06504BC2B9C17AB61645DBB8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_BI_Administrator_Role",
            "displayName": "MLC BI Administrator Role",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE42EE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE414E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE919E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1520DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "0871626EC6A14F81A4A3E880B29CFB3F",
            "meta": {
                "created": "2017-09-07 11:32:15.606",
                "lastModified": "2018-10-19 12:45:15.843",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0871626EC6A14F81A4A3E880B29CFB3F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_PEOPLE_SOLUTION_VIEWALL_DATA",
            "displayName": "MLC People Solution ViewAll",
            "description": "MLC_HR_SPCLST_CUSTOM_VIEWALL_DATA",
            "category": "DATA",
            "members": [
                {
                    "value": "73A1976DCE97E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD5491A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "766B01553A61A826E050790A6740E7AD"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                }
            ]
        },
        {
            "id": "AC6DAC540E71460897ADB6823E7905EB",
            "meta": {
                "created": "2017-09-07 13:29:22.000",
                "lastModified": "2018-10-19 12:45:16.370",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/AC6DAC540E71460897ADB6823E7905EB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_HR_SPCLST_OD_CUSTOM",
            "displayName": "MLC Organisational Development & Learning",
            "description": "Performs duties of MLC Organizational Development",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE728E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE839E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE808E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "B0EFE99B8CC249BC98703E4AA367B7E3",
            "meta": {
                "created": "2017-09-07 23:25:20.000",
                "lastModified": "2018-10-19 12:45:17.627",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/B0EFE99B8CC249BC98703E4AA367B7E3"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_CWK_CUSTOM",
            "displayName": "MLC Contingent Worker",
            "description": "Identifies the person as a CUSTOM contingent worker for MLC",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE7FCE9DEE050790A70403D5F"
                },
                {
                    "value": "766B0167BE407672E050790A6740E7CB"
                },
                {
                    "value": "766B01096A15A70EE050790A6740E718"
                },
                {
                    "value": "766B015D142DF611E050790A6740E7B7"
                },
                {
                    "value": "73A1970D2F5392B0E050790A70400AE8"
                },
                {
                    "value": "73A1970D2F5492B0E050790A70400AE8"
                },
                {
                    "value": "5E305E244E15AEBBE050790A7040267D"
                },
                {
                    "value": "766B015871E94917E050790A6740E7B2"
                },
                {
                    "value": "5822400BE86CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A1E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE0F5D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C881C30C9E050790A704076FF"
                },
                {
                    "value": "6557927C881D30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE8BDE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C881E30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE8CFE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ED0B634CE050790A70401414"
                },
                {
                    "value": "6C7D38CD5499A4B7E050790A70401387"
                },
                {
                    "value": "6C7D3930ED01634CE050790A70401414"
                },
                {
                    "value": "5822400BE798E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D3930ED03634CE050790A70401414"
                },
                {
                    "value": "5822400BE7DDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE81EE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E64AEBBE050790A7040267D"
                },
                {
                    "value": "6EAD9D73192219E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73194319E2E050790A704031FC"
                },
                {
                    "value": "5E305E87EF9263FDE050790A70402713"
                },
                {
                    "value": "6EAD9DD3DC83C113E050790A7040327A"
                },
                {
                    "value": "5822400BE6F0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE71CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE724E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54A2A4B7E050790A70401387"
                },
                {
                    "value": "6C7D3930ED05634CE050790A70401414"
                },
                {
                    "value": "6C7D3930ED06634CE050790A70401414"
                },
                {
                    "value": "73A1976DCE95E135E050790A70400B1B"
                },
                {
                    "value": "73A1970D2F4E92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE76CE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4F92B0E050790A70400AE8"
                },
                {
                    "value": "73A1976DCE98E135E050790A70400B1B"
                },
                {
                    "value": "73A1976DCE9AE135E050790A70400B1B"
                },
                {
                    "value": "73A1970D2F5092B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE6A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E7CAEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE6B2E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE0F7D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE6FAE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C87D530C9E050790A704076FF"
                },
                {
                    "value": "5822400BE752E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C87D730C9E050790A704076FF"
                },
                {
                    "value": "6557927C886630C9E050790A704076FF"
                },
                {
                    "value": "5822400BE786E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6F5E9DEE050790A70403D5F"
                },
                {
                    "value": "766B0164F6157F36E050790A6740E7C6"
                },
                {
                    "value": "766B015F030A91D3E050790A6740E7BC"
                },
                {
                    "value": "766B0161AAEE363FE050790A6740E7C1"
                },
                {
                    "value": "6557927C881F30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE688E9DEE050790A70403D5F"
                },
                {
                    "value": "766B015871E74917E050790A6740E7B2"
                },
                {
                    "value": "5822400BE6A1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6BBE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE89E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE6D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6EAE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4892B0E050790A70400AE8"
                },
                {
                    "value": "73A1976DCE8BE135E050790A70400B1B"
                },
                {
                    "value": "73A1976DCE8CE135E050790A70400B1B"
                },
                {
                    "value": "73A1976DCE8DE135E050790A70400B1B"
                },
                {
                    "value": "5822400BE717E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE19ED7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1A0D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE726E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE72DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE730E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9DD3DC64C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73191D19E2E050790A704031FC"
                },
                {
                    "value": "655792DFE13FD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE766E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73191E19E2E050790A704031FC"
                },
                {
                    "value": "5822400BE774E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E88AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE79FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7ACE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7B8E9DEE050790A70403D5F"
                },
                {
                    "value": "7336E66670B79A93E050790A70401780"
                },
                {
                    "value": "73A1976DCE83E135E050790A70400B1B"
                },
                {
                    "value": "73A1970D2F3A92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE7DAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7DBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7DEE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F3F92B0E050790A70400AE8"
                },
                {
                    "value": "5CA22278FA8CAE1FE050790A70407008"
                },
                {
                    "value": "5CA22278FA8EAE1FE050790A70407008"
                },
                {
                    "value": "5CA222DA0BBF1F39E050790A70407085"
                },
                {
                    "value": "655792DFDF48D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88BE30C9E050790A704076FF"
                },
                {
                    "value": "655792DFE195D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE198D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE199D7D8E050790A704077ED"
                },
                {
                    "value": "6EAD9DD3DC90C113E050790A7040327A"
                },
                {
                    "value": "655792DFE1A6D7D8E050790A704077ED"
                },
                {
                    "value": "6C7D38CD5496A4B7E050790A70401387"
                },
                {
                    "value": "6EAD9DD3DC86C113E050790A7040327A"
                },
                {
                    "value": "7336E66670B89A93E050790A70401780"
                },
                {
                    "value": "5CA222DA0BB61F39E050790A70407085"
                },
                {
                    "value": "5E305E87EF8E63FDE050790A70402713"
                },
                {
                    "value": "5E305E87EFF363FDE050790A70402713"
                },
                {
                    "value": "5E305E87EFF463FDE050790A70402713"
                },
                {
                    "value": "5E305E87EFF863FDE050790A70402713"
                },
                {
                    "value": "655792DFDF4CD7D8E050790A704077ED"
                },
                {
                    "value": "5CA22278FA88AE1FE050790A70407008"
                },
                {
                    "value": "5CA22278FA8BAE1FE050790A70407008"
                },
                {
                    "value": "6557927C88BC30C9E050790A704076FF"
                },
                {
                    "value": "6557927C88BD30C9E050790A704076FF"
                },
                {
                    "value": "6557927C88BF30C9E050790A704076FF"
                },
                {
                    "value": "655792DFE190D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1A7D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1AFD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1B3D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88E630C9E050790A704076FF"
                },
                {
                    "value": "6557927C88E830C9E050790A704076FF"
                },
                {
                    "value": "6C7D38CD549EA4B7E050790A70401387"
                },
                {
                    "value": "6C7D38CD54A4A4B7E050790A70401387"
                },
                {
                    "value": "6EAD9DD3DC5DC113E050790A7040327A"
                },
                {
                    "value": "6557927C873B30C9E050790A704076FF"
                },
                {
                    "value": "6EAD9DD3DC81C113E050790A7040327A"
                },
                {
                    "value": "655792DFE18DD7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88E330C9E050790A704076FF"
                },
                {
                    "value": "655792DFE1B1D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1B8D7D8E050790A704077ED"
                },
                {
                    "value": "6C7D3930ECFE634CE050790A70401414"
                },
                {
                    "value": "6EAD9DD3DC60C113E050790A7040327A"
                },
                {
                    "value": "655792DFE194D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BEA4BE9DEE050790A70403D5F"
                },
                {
                    "value": "5CA22278FA8FAE1FE050790A70407008"
                },
                {
                    "value": "5E305E87EF8B63FDE050790A70402713"
                },
                {
                    "value": "5E305E244E87AEBBE050790A7040267D"
                },
                {
                    "value": "655792DFE1AAD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1AED7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88E430C9E050790A704076FF"
                },
                {
                    "value": "6EAD9DD3DC61C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73194219E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC85C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73194A19E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73194C19E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC87C113E050790A7040327A"
                },
                {
                    "value": "58223FAD15D4DEECE050790A70403CA4"
                },
                {
                    "value": "5CA222DA0BB31F39E050790A70407085"
                },
                {
                    "value": "5CA22278FA8AAE1FE050790A70407008"
                },
                {
                    "value": "6EAD9DD3DC80C113E050790A7040327A"
                },
                {
                    "value": "5E305E87EF8C63FDE050790A70402713"
                },
                {
                    "value": "5E305E244F08AEBBE050790A7040267D"
                },
                {
                    "value": "6557927C881930C9E050790A704076FF"
                },
                {
                    "value": "655792DFE187D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE1B5D7D8E050790A704077ED"
                },
                {
                    "value": "6EAD9DD3DC63C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73192119E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC8CC113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC8BC113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC8AC113E050790A7040327A"
                },
                {
                    "value": "6557927C88D230C9E050790A704076FF"
                },
                {
                    "value": "6EAD9DD3DC5FC113E050790A7040327A"
                },
                {
                    "value": "6557927C87D430C9E050790A704076FF"
                },
                {
                    "value": "6557927C881A30C9E050790A704076FF"
                },
                {
                    "value": "655792DFE189D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88CB30C9E050790A704076FF"
                },
                {
                    "value": "655792DFE19FD7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88D730C9E050790A704076FF"
                },
                {
                    "value": "6557927C88D830C9E050790A704076FF"
                },
                {
                    "value": "6C7D3930ECF9634CE050790A70401414"
                },
                {
                    "value": "6C7D3930ECFB634CE050790A70401414"
                },
                {
                    "value": "6EAD9D73194019E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC8DC113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC89C113E050790A7040327A"
                },
                {
                    "value": "5822400BE7E5E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE8AE135E050790A70400B1B"
                },
                {
                    "value": "73A1976DCE92E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE652E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9DD3DC51C113E050790A7040327A"
                },
                {
                    "value": "5822400BE59AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5D8E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9DD3DC54C113E050790A7040327A"
                },
                {
                    "value": "5822400BE52AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE531E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE538E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87F0C163FDE050790A70402713"
                },
                {
                    "value": "5E305E87F10263FDE050790A70402713"
                },
                {
                    "value": "5E305E244F8BAEBBE050790A7040267D"
                },
                {
                    "value": "5E305E87F14963FDE050790A70402713"
                },
                {
                    "value": "6C7D3930ED04634CE050790A70401414"
                },
                {
                    "value": "5822400BE60AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE613E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54A3A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE433E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE465E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE491E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE497E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1527DEECE050790A70403CA4"
                },
                {
                    "value": "5E305E244F4AAEBBE050790A7040267D"
                },
                {
                    "value": "6EAD9D73194E19E2E050790A704031FC"
                },
                {
                    "value": "6C7D3930ED09634CE050790A70401414"
                },
                {
                    "value": "5822400BE8EBE9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD54AEA4B7E050790A70401387"
                },
                {
                    "value": "6EAD9D73190C19E2E050790A704031FC"
                },
                {
                    "value": "73A1970D2F3692B0E050790A70400AE8"
                },
                {
                    "value": "655792DFE184D7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE185D7D8E050790A704077ED"
                },
                {
                    "value": "73A1970D2F4092B0E050790A70400AE8"
                },
                {
                    "value": "6557927C88BA30C9E050790A704076FF"
                },
                {
                    "value": "73A1970D2F4192B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE8DEE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E82AEBBE050790A7040267D"
                },
                {
                    "value": "5E305E87F14763FDE050790A70402713"
                },
                {
                    "value": "5822400BE946E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244FCFAEBBE050790A7040267D"
                },
                {
                    "value": "766B0161AADF363FE050790A6740E7C1"
                },
                {
                    "value": "5822400BE7F0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7F9E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7FDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE800E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE805E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE80DE9DEE050790A70403D5F"
                },
                {
                    "value": "766B01553A64A826E050790A6740E7AD"
                },
                {
                    "value": "5822400BE823E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4692B0E050790A70400AE8"
                },
                {
                    "value": "73A1970D2F4592B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE83CE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4292B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE84FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE855E9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C878530C9E050790A704076FF"
                },
                {
                    "value": "73A1970D2F4392B0E050790A70400AE8"
                },
                {
                    "value": "73A1970D2F4492B0E050790A70400AE8"
                },
                {
                    "value": "6EAD9D73190719E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC5BC113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC4DC113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73190B19E2E050790A704031FC"
                },
                {
                    "value": "5822400BE896E9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9DD3DC53C113E050790A7040327A"
                },
                {
                    "value": "5822400BE89DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8A0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8AEE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8B6E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87EFF563FDE050790A70402713"
                },
                {
                    "value": "5E305E244FD0AEBBE050790A7040267D"
                },
                {
                    "value": "5822400BE8C5E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE061D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE8CCE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE06BD7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE8DBE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE06CD7D8E050790A704077ED"
                },
                {
                    "value": "655792DFE06ED7D8E050790A704077ED"
                },
                {
                    "value": "6557927C867130C9E050790A704076FF"
                },
                {
                    "value": "655792DFDF4ED7D8E050790A704077ED"
                },
                {
                    "value": "58223FAD15CBDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15D0DEECE050790A70403CA4"
                },
                {
                    "value": "6EAD9D73194819E2E050790A704031FC"
                },
                {
                    "value": "6C7D3930ECFD634CE050790A70401414"
                },
                {
                    "value": "766B01096A13A70EE050790A6740E718"
                },
                {
                    "value": "5822400BE92DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE959E9DEE050790A70403D5F"
                },
                {
                    "value": "6C7D38CD549CA4B7E050790A70401387"
                },
                {
                    "value": "6C7D38CD549DA4B7E050790A70401387"
                },
                {
                    "value": "73A1976DCE94E135E050790A70400B1B"
                },
                {
                    "value": "5822400BEA46E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E87F14563FDE050790A70402713"
                },
                {
                    "value": "5E305E87F14863FDE050790A70402713"
                },
                {
                    "value": "655792DFE188D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88C430C9E050790A704076FF"
                },
                {
                    "value": "766B015D142CF611E050790A6740E7B7"
                },
                {
                    "value": "6557927C88C830C9E050790A704076FF"
                },
                {
                    "value": "6557927C88CA30C9E050790A704076FF"
                },
                {
                    "value": "6557927C88CE30C9E050790A704076FF"
                },
                {
                    "value": "766B0161AAEB363FE050790A6740E7C1"
                },
                {
                    "value": "655792DFE19DD7D8E050790A704077ED"
                },
                {
                    "value": "5E305E244E1EAEBBE050790A7040267D"
                },
                {
                    "value": "766B015D142AF611E050790A6740E7B7"
                },
                {
                    "value": "655792DFE196D7D8E050790A704077ED"
                },
                {
                    "value": "5E305E87EFF263FDE050790A70402713"
                },
                {
                    "value": "5E305E244E86AEBBE050790A7040267D"
                },
                {
                    "value": "6557927C87D130C9E050790A704076FF"
                },
                {
                    "value": "6557927C88C930C9E050790A704076FF"
                },
                {
                    "value": "655792DFE1A5D7D8E050790A704077ED"
                },
                {
                    "value": "6C7D3930ECFA634CE050790A70401414"
                },
                {
                    "value": "766B0167BE417672E050790A6740E7CB"
                },
                {
                    "value": "766B0167BE427672E050790A6740E7CB"
                },
                {
                    "value": "6EAD9DD3DC4BC113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC50C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73190F19E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73191019E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC5CC113E050790A7040327A"
                },
                {
                    "value": "58223FAD15D2DEECE050790A70403CA4"
                },
                {
                    "value": "5E305E244E7BAEBBE050790A7040267D"
                },
                {
                    "value": "6557927C88C130C9E050790A704076FF"
                },
                {
                    "value": "655792DFE1A8D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88E530C9E050790A704076FF"
                },
                {
                    "value": "6EAD9DD3DC65C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73194119E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC7FC113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC82C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73194419E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73194519E2E050790A704031FC"
                },
                {
                    "value": "5E305E244E20AEBBE050790A7040267D"
                },
                {
                    "value": "6557927C887230C9E050790A704076FF"
                },
                {
                    "value": "58223FAD15C7DEECE050790A70403CA4"
                },
                {
                    "value": "6EAD9D73191F19E2E050790A704031FC"
                },
                {
                    "value": "5E305E244E1CAEBBE050790A7040267D"
                },
                {
                    "value": "5E305E244E1DAEBBE050790A7040267D"
                },
                {
                    "value": "6557927C882330C9E050790A704076FF"
                },
                {
                    "value": "6557927C867230C9E050790A704076FF"
                },
                {
                    "value": "6EAD9DD3DC5AC113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73192519E2E050790A704031FC"
                },
                {
                    "value": "6EAD9DD3DC8EC113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73191C19E2E050790A704031FC"
                },
                {
                    "value": "6557927C87D230C9E050790A704076FF"
                },
                {
                    "value": "5E305E87EFF063FDE050790A70402713"
                },
                {
                    "value": "58223FAD15D3DEECE050790A70403CA4"
                },
                {
                    "value": "7336E6C2C539362EE050790A704017B2"
                },
                {
                    "value": "6557927C86B830C9E050790A704076FF"
                },
                {
                    "value": "6557927C88D530C9E050790A704076FF"
                },
                {
                    "value": "6557927C88D630C9E050790A704076FF"
                },
                {
                    "value": "6557927C88DE30C9E050790A704076FF"
                },
                {
                    "value": "655792DFE1B2D7D8E050790A704077ED"
                },
                {
                    "value": "6C7D38CD54ACA4B7E050790A70401387"
                },
                {
                    "value": "6C7D38CD54ADA4B7E050790A70401387"
                },
                {
                    "value": "6EAD9DD3DC55C113E050790A7040327A"
                },
                {
                    "value": "6EAD9DD3DC59C113E050790A7040327A"
                },
                {
                    "value": "6EAD9D73191819E2E050790A704031FC"
                },
                {
                    "value": "5E305E87EF8F63FDE050790A70402713"
                },
                {
                    "value": "6557927C87D830C9E050790A704076FF"
                },
                {
                    "value": "6EAD9D73195019E2E050790A704031FC"
                },
                {
                    "value": "6EAD9D73195119E2E050790A704031FC"
                },
                {
                    "value": "7336E66670B69A93E050790A70401780"
                },
                {
                    "value": "7336E6C2C53B362EE050790A704017B2"
                },
                {
                    "value": "7336E6C2C53C362EE050790A704017B2"
                },
                {
                    "value": "7336E66670B99A93E050790A70401780"
                },
                {
                    "value": "7336E6C2C53D362EE050790A704017B2"
                },
                {
                    "value": "73A1976DCE82E135E050790A70400B1B"
                },
                {
                    "value": "766B015871DE4917E050790A6740E7B2"
                },
                {
                    "value": "73A1976DCEA9E135E050790A70400B1B"
                },
                {
                    "value": "73A1976DCEA4E135E050790A70400B1B"
                },
                {
                    "value": "766B01553A5FA826E050790A6740E7AD"
                },
                {
                    "value": "766B01553A63A826E050790A6740E7AD"
                },
                {
                    "value": "766B015871DD4917E050790A6740E7B2"
                },
                {
                    "value": "766B015871E54917E050790A6740E7B2"
                },
                {
                    "value": "766B0167BE3B7672E050790A6740E7CB"
                },
                {
                    "value": "766B0161AAE0363FE050790A6740E7C1"
                },
                {
                    "value": "766B01096A17A70EE050790A6740E718"
                },
                {
                    "value": "766B01096A18A70EE050790A6740E718"
                },
                {
                    "value": "5822400BE448E9DEE050790A70403D5F"
                },
                {
                    "value": "766B015F030991D3E050790A6740E7BC"
                },
                {
                    "value": "5822400BE4A0E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF4BD7D8E050790A704077ED"
                },
                {
                    "value": "73A1976DCE86E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE4D9E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF50D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE4E1E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF94D7D8E050790A704077ED"
                },
                {
                    "value": "6557927C86B730C9E050790A704076FF"
                },
                {
                    "value": "5822400BE4F0E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F3C92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE4FDE9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F3D92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE504E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE514E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE51BE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE53CE9DEE050790A70403D5F"
                },
                {
                    "value": "4C07D24054DA4181E050790A704014DC"
                },
                {
                    "value": "73A1970D2F3B92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE54FE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE566E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE88E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE575E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE1B9D7D8E050790A704077ED"
                },
                {
                    "value": "6C7D38CD5490A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE5A0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5A7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5EAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE52DE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE55CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE579E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE589E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1976DCE9DE135E050790A70400B1B"
                },
                {
                    "value": "73A1976DCE9EE135E050790A70400B1B"
                },
                {
                    "value": "5822400BE597E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F5692B0E050790A70400AE8"
                },
                {
                    "value": "655792DFE18FD7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88C030C9E050790A704076FF"
                },
                {
                    "value": "6557927C878930C9E050790A704076FF"
                },
                {
                    "value": "5822400BE5EFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5F6E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE069D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE61DE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C878B30C9E050790A704076FF"
                },
                {
                    "value": "5822400BE4C0E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE570E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE431E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE44BE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88D330C9E050790A704076FF"
                },
                {
                    "value": "5E305E87EF8563FDE050790A70402713"
                },
                {
                    "value": "5822400BE47DE9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFE1ABD7D8E050790A704077ED"
                },
                {
                    "value": "6557927C88E730C9E050790A704076FF"
                },
                {
                    "value": "6557927C88EA30C9E050790A704076FF"
                },
                {
                    "value": "655792DFE1B7D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE51FE9DEE050790A70403D5F"
                },
                {
                    "value": "6557927C88B430C9E050790A704076FF"
                },
                {
                    "value": "5822400BE9AEE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD159BDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1536DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C1DEECE050790A70403CA4"
                },
                {
                    "value": "655792DFE06DD7D8E050790A704077ED"
                },
                {
                    "value": "5E305E244FCCAEBBE050790A7040267D"
                },
                {
                    "value": "5E305E87F14663FDE050790A70402713"
                },
                {
                    "value": "655792DFE141D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BEA30E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157CDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE9A9E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244FCDAEBBE050790A7040267D"
                },
                {
                    "value": "6EAD9DD3DC91C113E050790A7040327A"
                },
                {
                    "value": "5E305E244FCEAEBBE050790A7040267D"
                },
                {
                    "value": "73A1970D2F3892B0E050790A70400AE8"
                },
                {
                    "value": "73A1970D2F3792B0E050790A70400AE8"
                },
                {
                    "value": "73A1970D2F3992B0E050790A70400AE8"
                },
                {
                    "value": "73A1976DCE84E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE99BE9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244FD5AEBBE050790A7040267D"
                },
                {
                    "value": "73A1976DCEA2E135E050790A70400B1B"
                },
                {
                    "value": "766B01553A5EA826E050790A6740E7AD"
                },
                {
                    "value": "73A1970D2F5792B0E050790A70400AE8"
                },
                {
                    "value": "73A1976DCEA6E135E050790A70400B1B"
                },
                {
                    "value": "766B01096A0FA70EE050790A6740E718"
                },
                {
                    "value": "766B0161AADC363FE050790A6740E7C1"
                },
                {
                    "value": "766B01553A60A826E050790A6740E7AD"
                },
                {
                    "value": "766B0161AAEF363FE050790A6740E7C1"
                },
                {
                    "value": "73A1976DCEA3E135E050790A70400B1B"
                },
                {
                    "value": "766B015D1429F611E050790A6740E7B7"
                },
                {
                    "value": "73A1976DCEA8E135E050790A70400B1B"
                },
                {
                    "value": "766B0161AAEC363FE050790A6740E7C1"
                },
                {
                    "value": "766B01096A11A70EE050790A6740E718"
                },
                {
                    "value": "766B0164F6107F36E050790A6740E7C6"
                },
                {
                    "value": "766B0167BE3F7672E050790A6740E7CB"
                }
            ]
        },
        {
            "id": "0B3E2037852D4F2BA329694ADBA7B2F2",
            "meta": {
                "created": "2017-09-11 10:40:03.000",
                "lastModified": "2018-10-19 12:45:18.079",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0B3E2037852D4F2BA329694ADBA7B2F2"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_HUMAN_CAPITAL_MANAGEMENT_INTEGRATION_SPECIALIST_JOB_CUSTOM",
            "displayName": "MLC Human Capital Management Integration Specialist Custom",
            "description": "Individual responsible for planning, coordinating, and supervising all activities related to the integration of human capital management information systems.",
            "category": "JOB"
        },
        {
            "id": "2EA5587031EF47E5A7DF4B12EF2E2E68",
            "meta": {
                "created": "2017-09-11 11:21:24.339",
                "lastModified": "2018-10-19 12:45:17.199",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2EA5587031EF47E5A7DF4B12EF2E2E68"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_HCM_INTEGRATION_SPECIALIST_DATA_ROLE_DATA",
            "displayName": "MLC HCM Integration Specialist Data Role",
            "description": "MLC HCM Integration Specialist Data Role",
            "category": "DATA",
            "members": [
                {
                    "value": "58223FAD152CDEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD151CDEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "A2F1F75E897D4AF192D5B0328D62465D",
            "meta": {
                "created": "2017-09-18 03:03:01.000",
                "lastModified": "2018-10-19 12:45:18.386",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A2F1F75E897D4AF192D5B0328D62465D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_AP_Payment_Approvers",
            "displayName": "MLC AP Payment Approvers",
            "description": "When MLC AP Payment Approvers is assigned, the user is included in the AP Payment approval notification.",
            "category": "JOB",
            "members": [
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "18E67631C8DC498D8D8C1BC31A8BED58",
            "meta": {
                "created": "2017-09-18 03:20:59.000",
                "lastModified": "2018-10-19 12:45:16.948",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/18E67631C8DC498D8D8C1BC31A8BED58"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "AP_ACCOUNTS_PAYABLE_MANAGER_JOB_CUSTOM",
            "displayName": "MLC Accounts Payable Manager",
            "description": "Manages Accounts Payable department and personnel. Overrides exceptions, analyzes Oracle Fusion Payables balances, and submits income tax and withholding reports to meet regulatory requirements.\n\nCustomization: Removed ability to upload Supplier/Payee Bank Accounts",
            "category": "JOB",
            "members": [
                {
                    "value": "6C7D38CD54AAA4B7E050790A70401387"
                },
                {
                    "value": "5822400BE4EDE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4A7E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "14821201F5694A8397A6729C4809C0D5",
            "meta": {
                "created": "2017-09-18 03:21:01.000",
                "lastModified": "2018-10-19 12:45:15.706",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/14821201F5694A8397A6729C4809C0D5"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ASM_FUNCTIONAL_SETUPS_USER_ABSTRACT_CUSTOM",
            "displayName": "Functional Setups User Custom",
            "description": "Uses the functional user overview, and assigned tasks, and task lists. This role inherits the Functional Setups Duty job role and maintains a one to one relationship with this role. This role addresses dependency issues and should not be directly inherited by any product job or duty role.",
            "category": "ABSTRACT"
        },
        {
            "id": "6A6FCA41F15C416FBC1B04870E55020B",
            "meta": {
                "created": "2017-09-18 03:32:47.000",
                "lastModified": "2018-10-19 12:45:18.437",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/6A6FCA41F15C416FBC1B04870E55020B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "AP_ACCOUNTS_PAYABLE_SUPERVISOR_JOB_CUSTOM",
            "displayName": "MLC Accounts Payable Supervisor",
            "description": "Oversees the activities of Accounts Payables Specialists. Initiates and manages pay runs. Resolves nondata entry holds.\n\nCustomization: Removed ability to upload Supplier/Payee Bank Accounts",
            "category": "JOB",
            "members": [
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "13DE04FE0B2A4D418E0B8C7D009571EB",
            "meta": {
                "created": "2017-09-18 03:45:35.000",
                "lastModified": "2018-10-19 12:45:16.593",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/13DE04FE0B2A4D418E0B8C7D009571EB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_AP_ACCOUNTS_PAYABLE_MANAGER_JOB_CUSTOM_R",
            "displayName": "MLC Accounts Payable Manager R",
            "description": "Manages Accounts Payable department and personnel. Overrides exceptions, analyzes Oracle Fusion Payables balances, and submits income tax and withholding reports to meet regulatory requirements.\n\nCustomization: Removed ability to upload Supplier/Payee Bank Accounts\n\nCustomization2: Removed Standard Payable Period Close and assigned MLC Custom Payable Period Close without Force Approval Privilege",
            "category": "JOB",
            "members": [
                {
                    "value": "6C7D38CD549FA4B7E050790A70401387"
                },
                {
                    "value": "73A1970D2F4D92B0E050790A70400AE8"
                },
                {
                    "value": "7336E66670BB9A93E050790A70401780"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE85AE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "65BCCF56ADA54C698452B3817945B1B6",
            "meta": {
                "created": "2017-09-21 11:19:51.000",
                "lastModified": "2018-10-19 12:45:17.412",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/65BCCF56ADA54C698452B3817945B1B6"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_ESS_UPDATE_PROCESSES_CUSTOM",
            "displayName": "MLC ESS Update Processes",
            "description": "This will allow users to see all the ESS Processes\n\nAdded Data Security Policy to access Output files and also update job schedules for ESS Jobs submitted by other users",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                }
            ]
        },
        {
            "id": "8E563CD87D0A4165A9DF6A03B92BF966",
            "meta": {
                "created": "2017-10-10 01:01:14.657",
                "lastModified": "2018-10-19 12:45:16.864",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8E563CD87D0A4165A9DF6A03B92BF966"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_STANDARD_OTBI_ROLES_VIEWALL_DATA",
            "displayName": "MLC Standard OTBI Roles ViewAll",
            "description": "MLC Standard OTBI Roles ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                },
                {
                    "value": "655792DFDF96D7D8E050790A704077ED"
                },
                {
                    "value": "5822400BE469E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "10086B6C903C430CB80F8DD735AD36AC",
            "meta": {
                "created": "2017-10-27 00:47:49.000",
                "lastModified": "2018-10-19 12:45:16.762",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/10086B6C903C430CB80F8DD735AD36AC"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_BIPDataModelDeveloper_Custom",
            "displayName": "MLC BI Publisher Data Model Developer",
            "description": "BI Publisher Data Model Developer role to edit or create data models",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "655792DFDF96D7D8E050790A704077ED"
                }
            ]
        },
        {
            "id": "8D1FF498BEBB49488BE11AB510E30566",
            "meta": {
                "created": "2017-10-27 00:53:36.000",
                "lastModified": "2018-10-19 12:45:16.746",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/8D1FF498BEBB49488BE11AB510E30566"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_ORA_CMP_COMPENSATION_ADMIN_JOB_CUSTOM",
            "displayName": "MLC Compensation Administrator",
            "description": "Manages administration of compensation business objects and batch processes",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "A37ABE7D27F44042B3E66C67FACBDB49",
            "meta": {
                "created": "2017-10-31 04:39:02.975",
                "lastModified": "2018-10-19 12:45:17.174",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A37ABE7D27F44042B3E66C67FACBDB49"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_MANAGE_USER_ACCOUNT_DATA_DATA",
            "displayName": "MLC Manage User Account Data",
            "description": "MLC Manage User Account data roles provides access to manage User Accounts for all MLC users",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BE896E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "428F0277F5BB412BBC7E6AB603F805B6",
            "meta": {
                "created": "2017-11-16 03:45:58.000",
                "lastModified": "2018-10-19 12:45:16.353",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/428F0277F5BB412BBC7E6AB603F805B6"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_LEARNING_ADMINISTRATOR",
            "displayName": "MLC Learning Administrator",
            "description": "Learning administrator job role",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE728E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3EE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "123DA65409F74E8F9FC7EE969DC9E12B",
            "meta": {
                "created": "2017-11-16 03:52:25.891",
                "lastModified": "2018-10-19 12:45:18.129",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/123DA65409F74E8F9FC7EE969DC9E12B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_LEARNING_ADMINISTRATOR_DATA_ROLE_DATA",
            "displayName": "MLC Learning Administrator Data Role",
            "description": "MLC Learning Administrator Data Role Data",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE728E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA3EE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "0757644EC1F74FD2B304B995AA3D936E",
            "meta": {
                "created": "2017-11-23 23:44:12.000",
                "lastModified": "2018-10-19 12:45:17.601",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/0757644EC1F74FD2B304B995AA3D936E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_ADDITIONAL_ACCESS",
            "displayName": "MLC Additional Access",
            "description": "To give access to additional functions. \n1. Annoucements\n",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "473AF3195C814A8BBECB879087B6E900",
            "meta": {
                "created": "2017-12-14 04:42:25.751",
                "lastModified": "2018-10-19 12:45:16.649",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/473AF3195C814A8BBECB879087B6E900"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_TIME_AND_LABOR_MANAGER_DATA",
            "displayName": "MLC Time and Labor Manager",
            "description": "MLC Time and Labor Manager Data",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BE477E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "09F2A95C15CA425085D9D292643D9140",
            "meta": {
                "created": "2018-04-09 07:50:25.000",
                "lastModified": "2018-10-19 12:45:18.270",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/09F2A95C15CA425085D9D292643D9140"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_MANAGE_LEARNING_ASSIGNMENT",
            "displayName": "MLC Manage Learning Assignment",
            "description": "MLC Manage Learning Assignment",
            "category": "JOB"
        },
        {
            "id": "3B9B124252824E578FAC0446BD348E4E",
            "meta": {
                "created": "2018-04-09 07:55:26.625",
                "lastModified": "2018-10-19 12:45:17.163",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/3B9B124252824E578FAC0446BD348E4E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_MANAGE_LEARNING_ASSIGNMENT_DATA_DATA",
            "displayName": "MLC Manage Learning Assignment Data",
            "description": "MLC Manage Learning Assignment Data",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "A21ABAE1FF014675A856FB97103073D4",
            "meta": {
                "created": "2017-09-07 03:39:09.319",
                "lastModified": "2018-10-19 12:45:17.337",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/A21ABAE1FF014675A856FB97103073D4"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "HRANALYST_VIEWALL_DATA",
            "displayName": "HRAnalyst_ViewAll",
            "description": "HRAnalyst_ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "58223FAD1502DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD15C2DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1500DEECE050790A70403CA4"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "FD1A3A2024F34A32AC962034B40CE89D",
            "meta": {
                "created": "2017-09-07 03:41:59.136",
                "lastModified": "2018-10-19 12:45:16.905",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/FD1A3A2024F34A32AC962034B40CE89D"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "HCMAPPLICATIONADMINISTRATOR_VIEWALL_DATA",
            "displayName": "HCMApplicationAdministrator_ViewAll",
            "description": "HCMApplicationAdministrator_ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BEA49E9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "890029C0DF2F466595319834FC9887DA",
            "meta": {
                "created": "2017-09-07 03:45:27.678",
                "lastModified": "2018-10-19 12:45:17.363",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/890029C0DF2F466595319834FC9887DA"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "COMPENSATIONADMIN_VIEWALL_DATA",
            "displayName": "CompensationAdmin_ViewAll",
            "description": "CompensationAdmin_ViewAll Data",
            "category": "DATA",
            "members": [
                {
                    "value": "5822400BE54AE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1501DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE413E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA01E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "1A331D8CC8DF464C953E72E48E1E06AD",
            "meta": {
                "created": "2017-09-07 06:30:38.000",
                "lastModified": "2018-10-19 12:45:18.234",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1A331D8CC8DF464C953E72E48E1E06AD"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_Compensation_Approvers",
            "displayName": "MLC Compensation Approvers",
            "description": "Workflow approval role assigned to Compensation Team",
            "category": "JOB",
            "members": [
                {
                    "value": "73A1976DCE97E135E050790A70400B1B"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                }
            ]
        },
        {
            "id": "659BA9F9A0584D2986B9060E54BAB8DF",
            "meta": {
                "created": "2017-09-07 06:52:33.000",
                "lastModified": "2018-10-19 12:45:18.253",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/659BA9F9A0584D2986B9060E54BAB8DF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_HR_SPCLST_CUSTOM",
            "displayName": "MLC People Solution",
            "description": "Custom role to perform duties of a human resources specialist.",
            "category": "JOB",
            "members": [
                {
                    "value": "73A1976DCE97E135E050790A70400B1B"
                },
                {
                    "value": "6C7D38CD5491A4B7E050790A70401387"
                },
                {
                    "value": "5822400BE482E9DEE050790A70403D5F"
                },
                {
                    "value": "73A1970D2F4992B0E050790A70400AE8"
                },
                {
                    "value": "5822400BE555E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7E1E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE522E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE854E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE50CE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE7A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D5E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4AFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E1E9DEE050790A70403D5F"
                },
                {
                    "value": "766B01553A61A826E050790A6740E7AD"
                }
            ]
        },
        {
            "id": "1E87B47600FA48D88DF4E403FD3114CB",
            "meta": {
                "created": "2017-10-31 04:37:32.000",
                "lastModified": "2018-10-19 12:45:16.844",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/1E87B47600FA48D88DF4E403FD3114CB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_MANAGE_USER_ACCOUNT_CUSTOM",
            "displayName": "MLC Manage User Account",
            "description": "MLC Manage User Account roles provides access to manage User Accounts for all MLC users",
            "category": "JOB"
        },
        {
            "id": "441EF811C724407E9D9B6322433AC3BF",
            "meta": {
                "created": "2018-04-10 02:47:51.000",
                "lastModified": "2018-10-19 12:45:16.770",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/441EF811C724407E9D9B6322433AC3BF"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "MLC_AP_INVOICE_PAYMENT_INQUIRY_CUSTOM",
            "displayName": "MLC AP Invoice and Payment Inquiry",
            "description": "Custom Read Only for AP Invoice and Payments with OTBI Access to Invoices and Suppliers",
            "category": "JOB",
            "members": [
                {
                    "value": "5822400BE98CE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD1554DEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE947E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE688E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CBE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5E7E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BEA39E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE919E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE9A3E9DEE050790A70403D5F"
                },
                {
                    "value": "5E305E244E7EAEBBE050790A7040267D"
                },
                {
                    "value": "5822400BEA4FE9DEE050790A70403D5F"
                },
                {
                    "value": "6EAD9D73195319E2E050790A704031FC"
                },
                {
                    "value": "5E305E87EF9463FDE050790A70402713"
                },
                {
                    "value": "5822400BE641E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE8F3E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE4D9E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "7FE83D6CBB2240C9901658EFABB80D42",
            "meta": {
                "created": "2018-05-24 23:26:03.000",
                "lastModified": "2018-10-19 12:45:18.314",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/7FE83D6CBB2240C9901658EFABB80D42"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "POZ_SUPPLIER_MANAGER_ABSTRACT_CUSTOM",
            "displayName": "MLC Supplier Manager",
            "description": "Manages supplier information and authorizes promotion of prospective suppliers to spend authorized.\n\nCustomization: Added ability to upload Supplier/Payee Bank Accounts",
            "category": "ABSTRACT",
            "members": [
                {
                    "value": "5822400BEA3AE9DEE050790A70403D5F"
                },
                {
                    "value": "58223FAD157FDEECE050790A70403CA4"
                },
                {
                    "value": "5822400BE684E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE6CAE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE545E9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE5FFE9DEE050790A70403D5F"
                },
                {
                    "value": "5822400BE742E9DEE050790A70403D5F"
                }
            ]
        },
        {
            "id": "4EEEF8745F374EAF9E47B75A9F55A84B",
            "meta": {
                "created": "2018-09-21 19:57:16.216",
                "lastModified": "2018-10-19 12:45:17.386",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/4EEEF8745F374EAF9E47B75A9F55A84B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_CUSTOMER_SELF_SERVICE_USER_ABSTRACT",
            "displayName": "Customer Self-Service User",
            "description": "Individual needing to create, view, and edit owned service requests for a specific account.",
            "category": "JOB"
        },
        {
            "id": "5BB2D829B0474FB6817BBBFF6127FA9E",
            "meta": {
                "created": "2018-09-21 19:57:16.294",
                "lastModified": "2018-10-19 12:45:17.432",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5BB2D829B0474FB6817BBBFF6127FA9E"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_LOY_LOYALTY_MARKETING_MANAGER_JOB",
            "displayName": "Loyalty Marketing Manager",
            "description": "Business user specialized in Loyalty program management.",
            "category": "JOB"
        },
        {
            "id": "F21EEAD6B82C45C8948AB3701C1F3210",
            "meta": {
                "created": "2018-09-21 19:57:16.352",
                "lastModified": "2018-10-19 12:45:17.458",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/F21EEAD6B82C45C8948AB3701C1F3210"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_HUMAN_RESOURCE_HELP_DESK_ADMINISTRATOR_JOB",
            "displayName": "Human Resource Help Desk Administrator",
            "description": "Individual responsible for managing all aspects of human resource help desk service requests. In addition, can manage queues and administer the human resource help desk service application, including setup.",
            "category": "JOB"
        },
        {
            "id": "722A7CF64786409980E6F957D8C196DB",
            "meta": {
                "created": "2018-09-21 19:57:16.592",
                "lastModified": "2018-10-19 12:45:17.583",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/722A7CF64786409980E6F957D8C196DB"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_EDR_COMPLIANCE_BUSINESS_ANALYST_JOB",
            "displayName": "Compliance Business Analyst",
            "description": "Compliance Business Analyst",
            "category": "JOB"
        },
        {
            "id": "490CCD4D22794714AB67589296E986FC",
            "meta": {
                "created": "2018-09-21 19:57:16.669",
                "lastModified": "2018-10-19 12:45:17.618",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/490CCD4D22794714AB67589296E986FC"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_CUSTOMER_SELF_SERVICE_ACCOUNT_ADMINISTRATOR_ABSTRACT",
            "displayName": "Customer Self-Service Account Administrator",
            "description": "Individual responsible for approving customer self-service registration requests and managing customer self-service roles.",
            "category": "JOB"
        },
        {
            "id": "2B59C2CEE4A64355A44095CE9836E4DE",
            "meta": {
                "created": "2018-09-21 19:57:16.732",
                "lastModified": "2018-10-19 12:45:17.646",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/2B59C2CEE4A64355A44095CE9836E4DE"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_ACA_SUPPLIER_PRODUCT_DESIGN_ENGINEER_JOB",
            "displayName": "Supplier Product Design Engineer",
            "description": "Individual within a supplier's organization responsible for creating the definition of mechanical and electronic products including their shape, physical characteristics, electronic characteristics, and manufacturing parameters such as tolerance.",
            "category": "JOB"
        },
        {
            "id": "5F3D5F729E304BEA9199F1E0AA9C99B8",
            "meta": {
                "created": "2018-09-21 19:57:17.216",
                "lastModified": "2018-10-19 12:45:17.879",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5F3D5F729E304BEA9199F1E0AA9C99B8"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_FND_AUTHENTICATED_USER_ABSTRACT",
            "displayName": "Authenticated User",
            "description": "Maps to OPSS system Authenticated Role.",
            "category": "ABSTRACT"
        },
        {
            "id": "5FE94FFC32074B4A985EBE81E7D6C36B",
            "meta": {
                "created": "2018-09-21 19:57:17.356",
                "lastModified": "2018-10-19 12:45:17.921",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/5FE94FFC32074B4A985EBE81E7D6C36B"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CSO_KNOWLEDGE_AUTHOR_SERVICE_JOB",
            "displayName": "Knowledge Author Service",
            "description": "Provides for the ability to author service articles",
            "category": "JOB"
        },
        {
            "id": "D65F689C80E14DA49DC08C88892F1054",
            "meta": {
                "created": "2018-09-21 19:57:17.948",
                "lastModified": "2018-10-19 12:45:18.061",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/D65F689C80E14DA49DC08C88892F1054"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_SVC_FIELD_SERVICE_TECHNICIAN_JOB",
            "displayName": "Field Service Technician",
            "description": "The field service resource assigned to a service work order who is responsible for performing the work.",
            "category": "JOB"
        },
        {
            "id": "395495BE01D9452EA904360AA4F06595",
            "meta": {
                "created": "2018-09-21 19:57:18.225",
                "lastModified": "2018-10-19 12:45:18.155",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/395495BE01D9452EA904360AA4F06595"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_MSC_SUPPLY_CHAIN_PLANNER_JOB",
            "displayName": "Supply Chain Planner",
            "description": "Manage Supply Plan",
            "category": "JOB"
        },
        {
            "id": "DCEDDA00E721465AAAC34083AC45E928",
            "meta": {
                "created": "2018-09-21 19:57:18.510",
                "lastModified": "2018-10-19 12:45:18.261",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/DCEDDA00E721465AAAC34083AC45E928"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_VCS_SUPPLY_CHAIN_COLLABORATION_PLANNER_JOB",
            "displayName": "Supply Chain Collaboration Planner",
            "description": "Reviews order forecasts published to the trading partner and negotiates with the trading partner to ensure that forecast commits align with the expectations of the company's buyers and supply chain planners.",
            "category": "JOB"
        },
        {
            "id": "C680BB287FEA484BB641755CF8193F7F",
            "meta": {
                "created": "2018-09-22 00:46:26.176",
                "lastModified": "2018-10-19 12:45:17.321",
                "location": "https://efly.hcm.ap4.oraclecloud.com:443/hcmRestApi/scim/Roles/C680BB287FEA484BB641755CF8193F7F"
            },
            "schemas": [
                "urn:oracle:apps:scim:schemas:fa:1.0:Role"
            ],
            "name": "ORA_CRM_EXTN_PRIVILEGE_SCRIPT_ROLE",
            "displayName": "Privileged Script Administration",
            "description": "Privileged Script Administration",
            "category": "JOB",
            "members": [
                {
                    "value": "47DBFDC422875A76E050F40A76AB16F8"
                }
            ]
        }
    ]
})

returnResponseList = []
responseList = json.loads(responseJSON)


print(responseList)
print("\n")
grpMembersList =[]
Resource = responseList['Resources']
print("==========================================")
with open("C:\\Users\\s.anand.raichur\\Desktop\\GroupsNew3.csv", 'w',newline='') as csvfile:
    filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
    filewriter.writerow(['Group ID','Member ID','Group Name'])
    for grp in Resource:
        grpId = grp["id"]
        if ('members' in grp):
            grpMembersList = grp["members"]
        else:
            grpMembersList=[]
        grpName = grp["name"]
        print("Group Name is ======== "+str(grpName))
        grpDispName = grp["displayName"]
        print("Group Display Name ====== "+str(grpDispName))
        print("\n \n")
        print(type(grpMembersList))
        if oktaFunctions.Enquiry(grpMembersList):
            print("====================="+str(grpMembersList[0]))
            print("===========length"+str(len(grpMembersList)))
            count=0
            for grp in grpMembersList:
                if (count<=len(grpMembersList)):
                    value = grpMembersList[count]
                    print("Value is ========== "+str(value))
                    count=count+1
                    head , sep, tail = str(value).partition(':')
                    value1 = head
                    #print("head ========== "+str(value1))
                    value2 = tail
                    #print("tail ========== "+str(value2))
                    head , sep , tail = str(value2).partition('}')
                    mainValue = head
                    #print("Main Value ========== "+str(mainValue))
                    finalValue = str(mainValue).replace("'","")
                    finalValue = str(finalValue).strip()
                    print("Final Value ========== "+str(finalValue))
                    filewriter.writerow([grpId,finalValue,grpName])
                else:
                    print("No Members")
                    break;