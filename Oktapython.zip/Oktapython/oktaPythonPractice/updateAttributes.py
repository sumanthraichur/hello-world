'''
Created on Sep 25, 2018

@author: sumanth.raichur
'''
import requests
import json
import milestokmfunction
import rectareafunction
import csv
import os

def GETObject(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
 

headers = {
    'Accept': "application/json",
    'Content-Type': "application/json",
    'Authorization': "SSWS 00ajIu_pDtYFXCQYKq1FFhJkrrvI8gUE6t8FK_fBG0"
    }

orgName = "dev-397928.oktapreview"
listUserUrl = "https://" + orgName + ".com/api/v1/users"#"?filter=profile.login eq \""+str(userManager)+"\""
userList=GETObject(listUserUrl)

for user in userList:
    userId = user["id"]
    userstatus=user["status"]
    profile=user["profile"]
    login=profile['login']
    print(login)
    if ('manager' in profile):
        userManager=user["profile"]['manager']
    else:
        userManager="None"
    print(userManager)
    managerURL=listUserUrl+"?filter=profile.login eq \""+str(userManager)+"\""
    managerList=GETObject(managerURL)
    for manager in managerList:
        managerId=manager["id"]
        managerLogin=manager["profile"]['login']
        print("Manager Login - "+str(managerLogin))
        print(managerId)
        ismanager = manager["profile"]['isManager']
        if ismanager!=True:
            managerPayload="{\n  \"profile\": {\n    \"isManager\": \"true\"\n  }\n}"
            print(managerPayload)
            managerURL=listUserUrl+"/"+managerId
            print(managerURL)
            response = requests.request("POST", managerURL, data=managerPayload, headers=headers)
            print(response.text)
        else:
            print("isManager already True")
    #===========================================================================
    # payload = "{\n  \"profile\": {\n    \"customID\": \""+userId+"\",\n    \"customStatus\": \""+userstatus+"\"\n  }\n}"
    # print(payload)
    # url=listUserUrl+"/"+userId
    # print(url)
    # response = requests.request("POST", url, data=payload, headers=headers)
    # print(response.text) 
    #===========================================================================
    print("\n")
#payload = "{\n  \"profile\": {\n   \"customID\": "+userId+",\n\"customStatus\": "+userstatus+"  \n}  \n}"
#print(payload)



#===============================================================================
# response = requests.request("GET", listUserUrl, headers=headers)
# returnResponseList = []
# managerList = []
# responseJSON = json.dumps(response.json())
# print(type(responseJSON))
# responseList = json.loads(responseJSON)
# print(type(responseList))
# returnResponseList = returnResponseList+responseList
# print(type(returnResponseList))
# managerList=returnResponseList
# #response = requests.request("POST", url, data=payload, headers=headers)
# print(response.text)
# for user in returnResponseList:
#     userId=user["id"]
#     if userId=="00ugbnzywszVTgBir0h7":
#         userLogin=user["profile"]['login']
#         print("User Login is - "+userLogin) 
#         userManager=user["profile"]['manager']
#         print("Manager is - "+userManager)
#         if userManager is not None:
#             for manager in managerList:
#                 managerLogin=manager["profile"]['login']
#                 print("Manager Login - "+managerLogin)
#                 if managerLogin==userManager:
#                     managerId=manager["id"]
#                     print("Manager ID - "+managerId)
#                     managerPayload="{\n  \"profile\": {\n    \"isManager\": \"true\"\n  }\n}"
#                     print(managerPayload)
#                     managerURL=listUserUrl+"/"+managerId
#                     print(managerURL)
#                     managerResponse = requests.request("POST", managerURL, data=managerPayload, headers=headers)
#                     print(managerResponse.text)
#     else:
#         print("Continue Looping")
#===============================================================================
print("Outside & Complete")