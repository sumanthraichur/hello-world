'''
Created on Oct 19, 2018

@author: sumanth.raichur
'''
try:
    import sys
    import traceback
    import oktaFunctions
    import csv
    import oktaPayloads
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
#===============================================================================
# #============PROD=======
# orgName = "mlcinsurance.okta"
#===============================================================================

#===============================================================================
# #===========MyDev================
# orgName = "dev-397928.oktapreview"
#===============================================================================

#===================TEST================
orgName = "mlclimited-test.oktapreview"
groupsIdFileName = "C:\\Users\\s.anand.raichur\\Desktop\\Python\\RuleOps\\groupsId_List.csv"
assignToGroupFileName = "C:\\Users\\s.anand.raichur\\Desktop\\Python\\RuleOps\\assignToGroup_List.csv"
ruleName = "Power BI Report Browser Rule"
ruleUrl = "https://" + orgName + ".com/api/v1/groups/rules"

try:
    
    #groupsId
    count=1
    grpIdList = []
    with open(groupsIdFileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ Group Check =================#
            print("Group number : "+str(count)+" in CSV File.")
            count=count+1
             
            grpName = row['groups']
            print("Group Name ::"+str(grpName))
            
            print("#============ Group Check =================#")   
            listUserUrl = "https://" + orgName + ".com/api/v1/groups?q="+str(grpName)
            grpList = oktaFunctions.GETObject(listUserUrl)
            print("List ====================== "+str(grpList))
            for grp in grpList:
                grpId = grp['id']
                print("Group Id is ======== "+str(grpId))
                groupName = grp["profile"]['name']
                #if groupName == grpName:
                grpIdList.append(grpId)
                print("Groups ID List ======"+str(grpIdList))
        groupsId = (', '.join('\\"' + item + '\\"' for item in grpIdList))
        print(groupsId)
        print("\n")
    
    #assignToGroup
    count=1
    assignToGroupList = []
    with open(assignToGroupFileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ Assign To Group Check =================#
            print("Group number : "+str(count)+" in CSV File.")
            count=count+1
             
            grpName = row['groups']
            print("Group Name ::"+str(grpName))
            
            print("#============ Assign To Group Check =================#")   
            listUserUrl = "https://" + orgName + ".com/api/v1/groups?q="+str(grpName)
            grpList = oktaFunctions.GETObject(listUserUrl)
            for grp in grpList:
                grpId = grp['id']
                assignToGroupList.append(grpId)
        assignToGroupId = (', '.join('"' + item + '"' for item in assignToGroupList))
        print(assignToGroupId)
        print("\n")
    
    #Rule Create with activation
    responseRulePayload = oktaPayloads.groupRule(ruleName, groupsId, assignToGroupId)
    print("RulePayload : "+str(responseRulePayload))
    responseRule = oktaFunctions.POSTRequest(ruleUrl, responseRulePayload)
    if responseRule != "Error":
        print(str(ruleName)+ " created in successfully")
        seacrhRule = responseRule['id']
        ruleList = []
        ruleList = seacrhRule
        ruleList = ''.join(ruleList)
        print("Rule ID for "+str(ruleName)+" :: "+str(ruleList))
        activateRuleUrl = ruleUrl + "/" + ruleList + "/lifecycle/activate"
        response = oktaFunctions.POSTRuleRequest(activateRuleUrl, "")
        if response != "Error":
            print (str(ruleName)+" Activated")
        print("\n")
        
                    
except Exception as e:
    print(traceback.format_exc())
