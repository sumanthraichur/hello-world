'''
Created on Oct 5, 2018

@author: sumanth.raichur
'''
import requests
import json
import milestokmfunction
import rectareafunction
import csv
import os


def GETObject(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def Enquiry(lis1):
    if len(lis1) == 0:
        return 0
    else:
        return 1
    
def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        print("\nYou encountered following Error: \n")
        print(responseJSON)
        print ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            print ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList


def GetPaginatedResponseLogin(url):
    response = requests.request("GET", url, headers=headers,verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    #returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        print("\nYou encountered following Error: \n")
        print(responseJSON)
        print ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            print ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            #returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        #returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return responseList
#===============================================================================
# headers = {
#     'Accept': "application/json",
#     'Content-Type': "application/json",
#     'Authorization': "SSWS 00ajIu_pDtYFXCQYKq1FFhJkrrvI8gUE6t8FK_fBG0",
#     'Cache-Control': "no-cache",
#     'Postman-Token': "a61ca360-633d-4660-8301-29bc4e6e3821"
#     }
# fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\AppUsersMyDev.csv'
# orgName = "dev-397928.oktapreview"
#===============================================================================
#===============================================================================
# 
# #============ SIT API TOKEN ==================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
#     }
#   
#===============================================================================

#============ PROD API TOKEN =================================================
headers = {
     'accept': "application/json",
     'content-type': "application/json",
     'authorization': "SSWS 00MicNpvJD6Ekwxuc1_J6-KDvlfdjt-gb_EFX8lY21"
     #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
     }
  
fileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\TaleoAppUsers.csv'
#===============================================================================
# orgName="mlclimited-sit.oktapreview"
#===============================================================================
#============PROD=======
orgName = "mlcinsurance.okta"

appLabel="Taleo"
listAppsUrl = "https://" + orgName + ".com/api/v1/apps?filter=status eq \"ACTIVE\""
print(listAppsUrl)
appsList = GETObject(listAppsUrl)
print("Apps List=========="+str(appsList))
with open(fileName, 'w',newline='') as csvfile:
    filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
    filewriter.writerow(['User ID','User Login','First Name','Last Name','E-mail'])
    for app in appsList:
        appId = app["id"]
        appName = app["label"]
        print("App Label ========="+appName)
        if appName==appLabel:
            print("Equals======="+appId)
            listUsersinAppUrl = "https://" + orgName + ".com/api/v1/apps/"+str(appId)+"/users"
            #print("List Users URL ============ "+listUsersinAppUrl)
            usersList = GetPaginatedResponse(listUsersinAppUrl)
            #print("Users List============"+str(usersList))
            for user in usersList:
                userId = user["id"]
                checklogin=user["credentials"]['userName']
                userLogin = str(checklogin) +"@ad.mlclife.com.au"
                #print("Userlogin=============="+str(userLogin))
                listUserLoginUrl = "https://" + orgName + ".com/api/v1/users/"+str(userId)
                LoginList = requests.request("GET", listUserLoginUrl, headers=headers,verify=False)
                returnResponseList = []
                responseJSON = json.dumps(LoginList.json())
                responseList = json.loads(responseJSON)
                #print("Dictionary================ "+str(responseList))
                profile=responseList['profile']
                #print("Profile=========="+str(profile))
                login = profile['login']
                firstName=user["profile"]['firstName']
                lastName=user["profile"]['lastName']
                email=user["profile"]['email']
                filewriter.writerow([userId,login,firstName,lastName,email])
        else:
            print("Different, continue traversing")
    
