'''
Created on Sep 26, 2018

@author: sumanth.raichur
'''
#===============================================================================
# import csv
# import string
# from random import choice
# 
# def GenPasswd2(length=8, chars=string.ascii_letters+string.digits):
#     return ''.join([choice(chars) for i in range(length)])
# 
# #===============================================================================
# # with open("C:\\Users\\s.anand.raichur\\Desktop\\Python\\UserGroups.csv") as csv_file:
# #     csv_reader = csv.DictReader(csv_file, delimiter=',')
# #     line_count = 1
# #     for row in csv_reader:
# #         line_count=line_count+1
# #         userLogin = row['Username']
# #         print("User Login is =="+str(userLogin))
# #         groupName = row['Group']
# #         print("Group Name is =="+str(groupName))
# #===============================================================================
# 
# for i in range(6):
#     password = GenPasswd2(8, string.ascii_letters+string.digits)
#     print(password)   
#===============================================================================


import string
from random import *

characters = string.ascii_lowercase + string.ascii_uppercase + string.digits
for i in range(10):
    password =  "1".join([choice(characters) for i in range(8)])#join(choice(characters) for x in range(randint(8,9)))
    print(password)
    
