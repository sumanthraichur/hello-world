'''
Created on Oct 16, 2018

@author: sumanth.raichur
'''

import oktaFunctions
import csv
readfileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\MLC Docs\\SirionLabs_Production.csv'
writefileName = 'C:\\Users\\s.anand.raichur\\Desktop\\Python\\MLC Docs\\SirionLabsResult_Production.csv'

#===============================================================================
# #My Dev
# orgName="dev-397928.oktapreview"
#===============================================================================

# PROD # 
orgName = "mlcinsurance.okta"


with open(readfileName) as csv_file:
    csv_reader = csv.DictReader(csv_file, delimiter=',')
    line_count = 1
    with open(writefileName, 'w',newline='') as csvfile:
        filewriter=csv.writer(csvfile,delimiter=',',quoting=csv.QUOTE_NONNUMERIC)
        filewriter.writerow(['User ID','User Login','E-mail','Status'])
        for row in csv_reader:
            
            emailId = row['EMAIL ID']
            print("\n \nCount == "+str(line_count))
            line_count=line_count+1
            print("Email ID is == "+str(emailId))
            #listUsersUrl = "https://" + orgName + ".com/api/v1/users?filter=profile.email eq \""+str(emailId)+"\""
            listUsersUrl = "https://" + orgName + ".com/api/v1/users?q="+str(emailId)
            print(listUsersUrl)
            userData = oktaFunctions.GETObject(listUsersUrl)
            print("User Data=========="+str(userData))
            if oktaFunctions.Enquiry(userData):
                for user in userData:
                    userId = user["id"]
                    login = user["profile"]['login']
                    email = emailId
                    status = user["status"]
                
            else:
                userId="None"
                login="None"
                status="User Not Found"
                email=emailId
            filewriter.writerow([userId,login,email,status])        
                
    