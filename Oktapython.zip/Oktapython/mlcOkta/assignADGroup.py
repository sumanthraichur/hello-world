try:
    import requests
    import okta
    import sys
    from okta import UsersClient
    from okta.models.user import User
    from okta.models.user import UserProfile
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
apiKey = "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq"
apiUrl = "https://dev-530347.oktapreview.com"
gid = "00ga4ujnjwZ61Ul3c0h7"

# Creating okta client
usersClient = UsersClient(apiUrl, apiKey)
users = usersClient.get_users()

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + apiKey,
    'cache-control': "no-cache"
    }

while True:
    for user in users :
            print("User Manager : {}".format(user.profile.managerId))
    else:
        break
