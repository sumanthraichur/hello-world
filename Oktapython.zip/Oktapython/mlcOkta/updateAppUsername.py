try:
    import sys
    import csv
    import oktaFunctions
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName = "mlclimited-sit.oktapreview"
orgNameAdmin = "mlclimited-sit-admin.oktapreview"
fileName = 'C:/Users/debmalya.biswas/Desktop/userNameUpdate.csv'

logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
print("\n")
print('Start reading group CSV file')
print("\n")    
    
try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            print("User number : %s in CSV File.", count)
            count=count+1 
            print("#============ User Check =================#")
            
            login = row['login']
            print("User login :: "+str(login))
            
            userName = row['userName']
            print("User Name :: "+str(userName))

            groupName = row['GroupName']
            print("Group Name :: "+str(groupName))
            print("\n")
            getUserDetailsUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(login)+"\")"
            getUserDetailsList = oktaFunctions.GETObject(getUserDetailsUrl)
            for getUserDetails in getUserDetailsList:
                userId = getUserDetails["id"]
                print("User ID :: "+str(userId))
                
            getGroupDetailsUrl = "https://" + orgName + ".com/api/v1/groups?q="+str(groupName)
            getGroupDetailsList =  oktaFunctions.GETObject(getGroupDetailsUrl)
            for getGroupDetails in getGroupDetailsList:
                groupId = getGroupDetails["id"]
                print("Group ID :: "+str(groupId))
                
            getAppsFromGroupDetailsUrl = "https://" + orgName + ".com/api/v1/groups/"+str(groupId)+"/apps"
            getAppsFromGroupDetailsList = oktaFunctions.GETObject(getAppsFromGroupDetailsUrl)
            for getAppsFromGroupDetails in getAppsFromGroupDetailsList:
                appId = getAppsFromGroupDetails["id"]
                label = getAppsFromGroupDetails["label"]
                print("App ID :: "+str(appId))
                
            
            changeUsernamePayload = oktaPayLoad.changeUsernamePayload(userId, userName, orgName, groupName, appId, groupId)
            print("Change Username Payload :: " +str(changeUsernamePayload))
            
            updateUsernameUrl = "https://"+orgNameAdmin+".com/api/v1/apps/"+str(appId)+"/users/"+str(userId)
            updateUsernameResponse = oktaFunctions.POSTRequest(updateUsernameUrl, changeUsernamePayload)
            if updateUsernameResponse !="Error":
                print("Username changed to "+str(userName)+" for user "+str(login)+" in App "+str(label))
                print("\n")
except Exception as e:
    print(traceback.format_exc())