'''
Created on May 23, 2017

@author: debmalya.biswas
'''
import requests

url = "https://dev-530347.oktapreview.com/api/v1/apps/0oaa94a1zxod13PEN0h7/users/00uak4vpyqmfo0gI00h7"

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq",
    'cache-control': "no-cache"
    }

response = requests.request("DELETE", url, headers=headers)

print(response.text)