try:
    import sys
    import readFromPropertiesFile
    import oktaLogger
    import traceback
    import os
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

orgName = "mlcgroupportal.okta"

try:
    header = ("login,status,created,activated,statusChanged,lastLogin,passwordChanged,providerType,email,firstName,lastName,ApplicationOwners,mobilePhone,organization,secondEmail,ClaimOwners")
    filename = 'C:/Users/debmalya.biswas/Desktop/UsersOktaExternalPROD.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
        
    listUserUrl = "https://" + orgName + ".com/api/v1/users"
    userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
    for user in userList:
        userId = user["id"]
        status = user["status"]
        lastLogin= user["lastLogin"]
        passwordChanged= user["passwordChanged"]
        activated= user["activated"]
        statusChanged= user["statusChanged"]
        
        created = user["created"]
        created = created.replace("T", " ")
        created = created.replace(".000Z", "")
        
        if (activated != None):
            activated = user["activated"]
            activated = activated.replace("T", " ")
            activated = activated.replace(".000Z", "")
        else:
            activated = "None"
        
        if (statusChanged != None):
            statusChanged = user["statusChanged"]
            statusChanged = statusChanged.replace("T", " ")
            statusChanged = statusChanged.replace(".000Z", "")
        else:
            statusChanged = "None"            
       
        if (lastLogin != None):
            lastLogin = user["lastLogin"]
            lastLogin = lastLogin.replace("T", " ")
            lastLogin = lastLogin.replace(".000Z", "")
        else:
            lastLogin = "None"            
        
        if (passwordChanged != None):
            passwordChanged = user["passwordChanged"]
            passwordChanged = passwordChanged.replace("T", " ")
            passwordChanged = passwordChanged.replace(".000Z", "")                  
        else:
            passwordChanged = "None"
        
        profile = user['profile']
        
        firstName = profile['firstName']
        lastName = profile['lastName']
        email = profile['email']
        login = profile['login']
        
        
        if ("ApplicationOwners" in profile):
            ApplicationOwners = profile['ApplicationOwners']
            ApplicationOwners = ''.join(ApplicationOwners)
            ApplicationOwners = ApplicationOwners.replace(",", ".")
            ApplicationOwners = ApplicationOwners.replace("{", "")
            ApplicationOwners = ApplicationOwners.replace("}", "")
        else:
            ApplicationOwners = "None"

        if ("mobilePhone" in profile):
            mobilePhone = profile['mobilePhone']
        else:
            mobilePhone = "None"    
            
        if ("organization" in profile):
            organization = profile['organization']
        else:
            organization = "None"
            
        if ("ClaimOwners" in profile):
            ClaimOwners = profile['ClaimOwners']
            ClaimOwners = ''.join(ClaimOwners)
            ClaimOwners = ClaimOwners.replace(",", ".")
            ClaimOwners = ClaimOwners.replace("{", "")
            ClaimOwners = ClaimOwners.replace("}", "")
        else:
            ClaimOwners = "None"
            
        if ("secondEmail" in profile):
            secondEmail = profile['secondEmail']
        else:
            secondEmail = "None"                                         
                                   
        
        credentials = user["credentials"]
        provider = credentials["provider"]
        providerType = provider["type"]
        
        addingValues = '{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}'.format(login,status,created,activated,statusChanged,lastLogin,passwordChanged,providerType,email,firstName,lastName,ApplicationOwners,mobilePhone,organization,secondEmail,ClaimOwners)
    
        # Amending with user values to the csv
        with open(filename, "a") as file:
            file.write(addingValues)
            file.write('\n')
        file.close()  

except Exception as e:
    print(traceback.format_exc())
