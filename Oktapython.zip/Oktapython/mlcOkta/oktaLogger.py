try:
    import logging   
    from datetime import datetime
    import readFromPropertiesFile
    import errno
    import os
    import sys
except:
    print("Please install okta/Python libaries. Refer to documentation for help :: Class Logger")
    sys.exit()

def loggerFilename(filename):
    # Logger File Logic <--> Starts
    dateTime = datetime.now().strftime('%d_%m_%Y')
    method = os.path.splitext(filename)[0]
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__+" :: "+str(method))
    logger.setLevel(logging.INFO)

    try:
        folderName = "logs\logs_{}".format(dateTime)
        # If folder does not exists create 'logs_<current date>' folder
        if not os.path.exists(folderName):
            os.makedirs(folderName)
    except OSError as e:
        if (e.errno != errno.EEXIST):
            raise
    
    loggerFilename = folderName + "/" + method + "_" + dateTime + ".log"
    
    # If logger file exists append logger
    if os.path.exists(loggerFilename):
    # creating a file handler
        handler = logging.FileHandler(loggerFilename)
        handler.setLevel(logging.INFO)

    # creating a logging format
        formatter = logging.Formatter('%(asctime)s - %(name)s method- %(levelname)s - %(message)s')
        handler.setFormatter(formatter)

    # adding the handlers to the logger
        logger.addHandler(handler)   
    else:
        # creating a file handler
        handler = logging.FileHandler(loggerFilename)
        handler.setLevel(logging.INFO)

    # creating a logging format
        formatter = logging.Formatter('%(asctime)s - %(name)s method - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)

    # adding the handlers to the logger
        logger.addHandler(handler)
    return logger
# Logger File Logic <--> Ends