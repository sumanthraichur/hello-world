import re
import csv
import logging
import traceback
import os
import errno
from datetime import datetime
import requests
import json



# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends


#===============================================================================
# #============ DEV API TOKEN ===================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 00pCgoznpH2YD1vE4PFdHpFXCDm0ncUFUgIs90Hiih"
#     }
#===============================================================================

#===============================================================================
# #============ SIT API TOKEN ==================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
#     }
#===============================================================================

#===============================================================================
# #============ PROD-SUP API TOKEN =================================================
# headers = {
#      'accept': "application/json",
#      'content-type': "application/json",
#      'authorization': "SSWS 00T8khxWUn2VUkRm1zcmNRcs-ot-KlMVH_0JSXVBZK"
#      #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
#      }
#===============================================================================

#============ PROD API TOKEN =================================================
headers = {
     'accept': "application/json",
     'content-type': "application/json",
     'authorization': "SSWS 00MicNpvJD6Ekwxuc1_J6-KDvlfdjt-gb_EFX8lY21"
     #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
     }

fileName = 'C:/Users/debmalya.biswas/Desktop/CV Prov Integration/CVGroupCreationWithProRole.csv'
orgName="mlcinsurance.okta"

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers, verify=False)
    else:
        response = requests.post(url, headers=headers, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            print ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers, verify=False)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList


def GETObject(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def PUTRequest(url):
    response = requests.request("PUT",url, headers=headers, verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response
try:
    header = ("login,manager")
    filename = 'C:/Users/debmalya.biswas/Desktop/UsersSIT.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')

    userlogin = "OKTA-ClaimVantage-"
    print('login: '+str(userlogin))

    #===== User =========#
    listUserUrl = "https://" + orgName + ".com/api/v1/groups?q="+str(userlogin)
    print("listUserUrl :: "+str(listUserUrl))
    userList = GETObject(listUserUrl)
    for user in userList:
        userId = user['id']
        profile = user['profile']
        name = profile ['name']
        name = str("\"") + name + str("\"")
        print (name)
        print (userId)
        addingValues = '{},{}'.format(name,userId)
        # Amending with user values to the csv
        with open(filename, "a") as file:
            file.write(addingValues)
            file.write('\n')
        file.close()
                
                
        

except Exception as e:
    print(traceback.format_exc())            