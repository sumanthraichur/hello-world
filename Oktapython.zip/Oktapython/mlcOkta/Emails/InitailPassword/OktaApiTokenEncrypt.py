try:
    import configparser
    import base64
    import sys
    import logging
    import traceback
    import time
    import errno
    import os
    from datetime import datetime
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends


# Encrypting to API Token to Bytes
logger.info("Reading Okta API Token properties File :")
logger.info("\n")

config = configparser.ConfigParser()
config.sections()
config.read('apiTokenKey.properties')
config.sections()


try:
    for key in config['column']: 
        column = config['column']
        apiKey = (column['apiKey'])
        
        # Encrypting to API Token to Bytes
        logger.info("Encrypting to API Token to Bytes")
        apiKeyOktaEncoded = (apiKey).encode('utf-8')
        apiKeyEncoded = base64.b64encode(apiKeyOktaEncoded)
        apiKeyOktaEncoded = str(apiKeyEncoded, 'utf-8')
        logger.info("Encoded OKTA API Key : {}".format(apiKeyOktaEncoded))

        # Writing only the API Token Value to the file
        logger.info("Writing the API Token Value to the file")
        file_conn = open('apiTokenKey(copy).properties', 'w')
        file_conn.write('[column]')
        file_conn.write('\n')
        file_conn.write("apiKey = " + apiKeyOktaEncoded)
        file_conn.write('\n')

        file_conn.close()
    
        os.remove('apiTokenKey.properties')
        time.sleep(2)
        os.rename('apiTokenKey(copy).properties', 'apiTokenKey.properties')
        logger.info("Okta API Token Encyrted")
        
except Exception as e:
    logging.error(traceback.format_exc())