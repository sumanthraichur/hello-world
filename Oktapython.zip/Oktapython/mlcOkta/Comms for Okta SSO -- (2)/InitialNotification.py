try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from os.path import basename
    from datetime import datetime
    import OktaApiTokenDecrypt
    import smtplib
    from smtplib import SMTPException
    from email.header import Header
    from email.utils import formataddr
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from email.mime.image import MIMEImage
    from email.mime.application import MIMEApplication
    import csv
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = "mlclimited.oktapreview"

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00pCgoznpH2YD1vE4PFdHpFXCDm0ncUFUgIs90Hiih",
    }


def GetObject(url):
    response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()
    
def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()

def POSTRequestPassword(url, querystring):
    if querystring != "":
        response = requests.post(url, headers=headers, params=querystring)
        response = "[" + response.text + "]"
        json_response = json.loads(response)
        for item in json_response:
            seacrhPassword = item['tempPassword']
            passwordList = []
            passwordList = seacrhPassword
        return passwordList


fileName ="users.csv"
outPutFilename = "users_List.csv"
try:
    # Writing to a CSV File
    header = ("firstName,lastName,login,email")
    if os.path.exists(outPutFilename):
        print("File exists")
    elif not os.path.exists(outPutFilename):
        print("File does not exists, creating new file")
        file = open(outPutFilename, 'w+')
        file.write(header)
        file.write('\n')
    
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
             
            #============ User Check =================#
            print("User number : "+str(count)+" in CSV File.")
            count=count+1
            print("#============ User Check =================#")
            login = row['login']
            print("User Login :: "+str(login))
            listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(login)+"\")"
            response = requests.get(listUserUrl, headers=headers)
            userList = []
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            userList = userList + responseList
        
            
            activationHeadFilename = "CommsforOktaSSO/ActivationHead.html"
            activationHeadhtmlFile = open(activationHeadFilename, 'r', encoding='utf-8')
            activationHeadhtmlFilesource_code = activationHeadhtmlFile.read()
        
            activationP1Filename = "CommsforOktaSSO/ActivationP1.html"
            activationP1htmlFile = open(activationP1Filename, 'r', encoding='utf-8')
            activationP1htmlFilesource_code = activationP1htmlFile.read()
        
            activationP2Filename = "CommsforOktaSSO/ActivationP2.html"
            activationP2htmlFile = open(activationP2Filename, 'r', encoding='utf-8')
            activationP2htmlFilesource_code = activationP2htmlFile.read()
            
            activationP3Filename = "CommsforOktaSSO/ActivationP3.html"
            activationP3htmlFile = open(activationP3Filename, 'r', encoding='utf-8')
            activationP3htmlFilesource_code = activationP3htmlFile.read()            
        
            activationFinalFilename = "CommsforOktaSSO/ActivationFinal.html"
            activationFinalhtmlFile = open(activationFinalFilename, 'r', encoding='utf-8')
            activationFinalhtmlFilesource_code = activationFinalhtmlFile.read()
        
            attachment = 'logo.png'
            for user in userList:
                userId = user['id']
                profile = user['profile']
                userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
                user_info = {}
                user_info['profile'] = {}
                
                # Password Reset
                expirePasswordUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId) + "/lifecycle/expire_password"
                query = {"tempPassword":"true"}
                response = POSTRequestPassword(expirePasswordUrl, query)
                fromaddr = readFromPropertiesFile.notifyFromaddr
                toaddr = str(profile["email"])
                userLogin = str(profile["login"]).rsplit('@', 1)[0]
                         
                # #<-------------------- Notification ------------------------------>##
                msg = MIMEMultipart()
                msg['From'] = formataddr((str(Header('MLC Tech Support', 'utf-8')), fromaddr))
                msg['To'] = toaddr
                msg['Subject'] = "Important information | Your new MLC Life Insurance Logon Credentials"
                         
                activationBody = activationHeadhtmlFilesource_code
                activationBody = activationBody + '<img width="642" height="182" src="cid:image1"></span></span>'
                activationBody = activationBody + activationP1htmlFilesource_code
                activationBody = activationBody + 'Hello {}'.format(str(profile["firstName"]))
                activationBody = activationBody + activationP2htmlFilesource_code
                activationBody = activationBody + '{}'.format(str(profile["firstName"])+"."+str(profile["lastName"]))
                activationBody = activationBody + activationP3htmlFilesource_code
                activationBody = activationBody + '{}'.format(str(response))
                activationBody = activationBody + activationFinalhtmlFilesource_code
         
                msg.attach(MIMEText(activationBody, 'HTML'))
                fp = open(attachment, 'rb')
                img = MIMEImage(fp.read())
                fp.close()
                img.add_header('Content-ID', '<image1>')
                msg.attach(img)
                try:
                    smtpObj = smtplib.SMTP('192.168.1.29', 25)
                    #smtpObj.starttls()
                    text = msg.as_string()
                    smtpObj.sendmail(fromaddr, toaddr, text)
                    smtpObj.quit()
                    print ("User Activation Email with Password was sent to user email: {}\n".format(profile["email"]))
         
                except SMTPException as error:
                    print ("Error: unable to send email :  {err}".format(err=error))
                         
                
                addingValues = '{},{},{},{}'.format(str(profile["firstName"]), str(profile["lastName"]), str(profile["login"]), str(profile["email"]))
                # Amending with user values to the csv
                with open(outPutFilename, "a") as file:
                    file.write(addingValues)
                    file.write('\n')
                file.close()
  

except Exception as e:
    print(traceback.format_exc())
