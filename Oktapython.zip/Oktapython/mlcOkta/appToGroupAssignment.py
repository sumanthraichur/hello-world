try:
    import sys
    import csv
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    import json
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
fileName = 'C:/Users/debmalya.biswas/Desktop/groupToApplication.csv'
orgName="mlclimited-prodsup.oktapreview"
orgAdminName = "mlclimited-prodsup-admin.oktapreview"



try:
        
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        count=1
        for row in reader:
            print("Group number : "+str(count)+" in CSV File.")
            count=count+1             
             
            grpName = row['Group Name']
            print('grpName: '+str(grpName))
             
            appName = row['Application']
            print('appName: '+str(appName))

               
            #===== Group =========#
            listGroupUrl="https://" + orgName + ".com/api/v1/groups?q="+str(grpName)
            print("listGroupUrl :: "+str(listGroupUrl))
            groupList = oktaFunctions.GETObject(listGroupUrl)
            for group in groupList:
                groupId = group["id"]
                print("Group ID :: "+str(groupId))

            #===== App =========#
            listAppUrl="https://" + orgName + ".com/api/v1/apps?q="+str(appName)
            print("listAppUrl :: "+str(listAppUrl))
            appList = oktaFunctions.GETObject(listAppUrl)
            for app in appList:
                appId = app["id"]
                print("App ID :: "+str(appId))
            
            #===== Application to Group Assignment =========#   
            groupToAppAssignmentUrl = "https://" +orgAdminName+ ".com/api/v1/apps/"+str(appId)+"/groups/"+str(groupId)
            print("groupToAppAssignmentUrl :: "+str(groupToAppAssignmentUrl))
            groupToAppAssignmentPayload = oktaPayLoad.groupToAppAssignment(groupId)
            groupToAppAssignmentRespone = oktaFunctions.PUTRequest(groupToAppAssignmentUrl,groupToAppAssignmentPayload)
            if groupToAppAssignmentRespone != "Error":
                print ("Application "+str(appName)+" added to "+str(grpName)+" group")
                print ("\n")
 



except Exception as e:
    logger.info(traceback.format_exc()) 