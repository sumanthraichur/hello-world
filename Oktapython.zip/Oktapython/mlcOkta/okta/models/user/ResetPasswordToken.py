class ResetPasswordToken:

    types = {
        'resetPasswordUrl': str
    }

    def __init__(self):

        self.resetPasswordUrl = None  # str
