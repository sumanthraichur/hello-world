try:
    import sys
    import readFromPropertiesFile
    import oktaLogger
    import traceback
    import os
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

#===============================================================================
# # PROD # 
# orgName = "mlcinsurance.okta"
#===============================================================================

#==========DEV===========
orgName = "mlclimited.oktapreview"

#===============================================================================
# #UAT#
# orgName = "mlclimited-prodsup.oktapreview"
#===============================================================================

try:
    header = ("login,id,activated,statusChanged,lastLogin,passwordChanged,status,isManager,providerType,created,firstName,lastName,middleName,honorificPrefix,honorificSuffix,email,title,displayName,secondEmail,mobilePhone,primaryPhone,preferredLanguage,userType,department,employeeNumber,organization,managerId,manager,gender,location,city,countryCode,zipCode,knownAs,country,mlcUserStatus,startDate,endDate,faxNumber,PersonId,initialLogin,isHCMUser,hcmUsername,nabEmployeeID,serviceRequestNumber,resourceOwner,employeeType,vendorCompany,contractEndDate")
    filename = 'C:/Users/s.anand.raichur/Desktop/DevUsers.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
        
    #listUserUrl = "https://" + orgName + ".com/api/v1/users"
    #listUserUrl = "https://" + orgName + ".com/api/v1/groups/00g2brssgoirvpvYV2p7/users"
    #listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\")"
    listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\" or status eq \"STAGED\" or status eq \"DEPROVISIONED\" or status eq \"RECOVERY\" or status eq \"LOCKED_OUT\" or status eq \"PASSWORD_EXPIRED\")"
    print("URL ============ "+listUserUrl)
    dict = {}  # @ReservedAssignment
    userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
    for user in userList:
        userId = user["id"]
        
        status = user["status"]
        profile = user['profile']
        #=======================================================================
        # if(userId == "00u2841rwhSkPZ95P2p7"):
        #     print("===============")
        #     if "isHCMUser" in profile:
        #         isHCMUser = profile['isHCMUser']
        #         if isHCMUser == True:
        #             print("================Works===============")
        #=======================================================================
        #=======================================================================
        # if ("PersonId" in profile):
        #     dict[profile["PersonId"]] = profile["login"]
        #     print("==========Added===============")
        #=======================================================================
        lastLogin= user["lastLogin"]
        passwordChanged= user["passwordChanged"]
        activated= user["activated"]
        statusChanged= user["statusChanged"]
        
        created = user["created"]
        created = created.replace("T", " ")
        created = created.replace(".000Z", "")
        
        if (activated != None):
            activated = user["activated"]
            activated = activated.replace("T", " ")
            activated = activated.replace(".000Z", "")
        else:
            activated = "None"
        
        if (statusChanged != None):
            statusChanged = user["statusChanged"]
            statusChanged = statusChanged.replace("T", " ")
            statusChanged = statusChanged.replace(".000Z", "")
        else:
            statusChanged = "None"            
       
        if (lastLogin != None):
            lastLogin = user["lastLogin"]
            lastLogin = lastLogin.replace("T", " ")
            lastLogin = lastLogin.replace(".000Z", "")
        else:
            lastLogin = "None"            
        
        if (passwordChanged != None):
            passwordChanged = user["passwordChanged"]
            passwordChanged = passwordChanged.replace("T", " ")
            passwordChanged = passwordChanged.replace(".000Z", "")                  
        else:
            passwordChanged = "None"
        
        profile = user['profile']
        
        firstName = profile['firstName']
        lastName = profile['lastName']
        email = profile['email']
        login = profile['login']
        #=======================================================================
        # head , sep ,tail = login.partition('@')
        # login = head
        #=======================================================================
        
        if ("middleName" in profile):
            middleName = profile['middleName']
        else:
            middleName = "None"
            
        if ("isManager" in profile):
            isManager = profile['isManager']
        else:
            isManager = "None"            
        
        if ("honorificPrefix" in profile):
            honorificPrefix = profile['honorificPrefix']
        else:
            honorificPrefix = "None"
        
        if ("honorificSuffix" in profile):
            honorificSuffix = profile['honorificSuffix']
        else:
            honorificSuffix = "None"

        if ("title" in profile):
            title = profile['title']
            title = str("\"")+title+str("\"")
        else:
            title = "None"

        if ("displayName" in profile):
            displayName = profile['displayName']
        else:
            displayName = "None"                                 
            
        if ("secondEmail" in profile):
            secondEmail = profile['secondEmail']
        else:
            secondEmail = "None"                                             
            
        if ("mobilePhone" in profile):
            mobilePhone = profile['mobilePhone']
        else:
            mobilePhone = "None"            
            
        if ("primaryPhone" in profile):
            primaryPhone = profile['primaryPhone']
        else:
            primaryPhone = "None"            

        if ("preferredLanguage" in profile):
            preferredLanguage = profile['preferredLanguage']
        else:
            preferredLanguage = "None" 

        if ("userType" in profile):
            userType = profile['userType']
        else:
            userType = "None" 
            
        if ("department" in profile):
            department = profile['department']
            department = str("\"")+department+str("\"")
        else:
            department = "None"             

        if ("employeeNumber" in profile):
            employeeNumber = profile['employeeNumber']
        else:
            employeeNumber = "None" 

        if ("organization" in profile):
            organization = profile['organization']
        else:
            organization = "None" 

        if ("managerId" in profile):
            managerId = profile['managerId']
        else:
            managerId = "None" 

        if ("manager" in profile):
            manager = profile['manager']
        else:
            manager = "None" 

        if ("gender" in profile):
            gender = profile['gender']
        else:
            gender = "None" 

        if ("location" in profile):
            location = profile['location']
            location = str("\"")+location+str("\"")
        else:
            location = "None" 
            
        if ("city" in profile):
            city = profile['city']
        else:
            city = "None"

        if ("countryCode" in profile):
            countryCode = profile['countryCode']
        else:
            countryCode = "None"
            
        if ("zipCode" in profile):
            zipCode = profile['zipCode']
        else:
            zipCode = "None"                           
            
        if ("knownAs" in profile):
            knownAs = profile['knownAs']
        else:
            knownAs = "None" 

        if ("country" in profile):
            country = profile['country']
        else:
            country = "None" 

        if ("mlcUserStatus" in profile):
            mlcUserStatus = profile['mlcUserStatus']
        else:
            mlcUserStatus = "None" 
            
        if ("startDate" in profile):
            startDate = profile['startDate']
        else:
            startDate = "None" 

        if ("endDate" in profile):
            endDate = profile['endDate']
        else:
            endDate = "None" 

        if ("faxNumber" in profile):
            faxNumber = profile['faxNumber']
        else:
            faxNumber = "None"

        if ("PersonId" in profile):
            PersonId = profile['PersonId']
        else:
            PersonId = "None"

        if ("initialLogin" in profile):
            initialLogin = profile['initialLogin']
        else:
            initialLogin = "None"

        if ("isHCMUser" in profile):
            isHCMUser = profile['isHCMUser']
        else:
            isHCMUser = "None"

        if ("hcmUsername" in profile):
            hcmUsername = profile['hcmUsername']
        else:
            hcmUsername = "None"
            
        if ("nabEmployeeID" in profile):
            nabEmployeeID = profile['nabEmployeeID']
        else:
            nabEmployeeID = "None"     
            
        if ("serviceRequestNumber" in profile):
            serviceRequestNumber = profile['serviceRequestNumber']
        else:
            serviceRequestNumber = "None"
                          
        if ("resourceOwner" in profile):
            resourceOwner = profile['resourceOwner']
        else:
            resourceOwner = "None"                           

        if ("employeeType" in profile):
            employeeType = profile['employeeType']
        else:
            employeeType = "None" 
            
        if ("vendorCompany" in profile):
            vendorCompany = profile['vendorCompany']
        else:
            vendorCompany = "None"  
            
        if ("contractEndDate" in profile):
            contractEndDate = profile['contractEndDate']
        else:
            contractEndDate = "None"                           
        
        credentials = user["credentials"]
        provider = credentials["provider"]
        providerType = provider["type"]
        
        addingValues = '{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}'.format(login,userId,activated,statusChanged,lastLogin,passwordChanged,status,isManager,providerType,created,firstName,lastName,middleName,honorificPrefix,honorificSuffix,email,title,displayName,secondEmail,mobilePhone,primaryPhone,preferredLanguage,userType,department,employeeNumber,organization,managerId,manager,gender,location,city,countryCode,zipCode,knownAs,country,mlcUserStatus,startDate,endDate,faxNumber,PersonId,initialLogin,isHCMUser,hcmUsername,nabEmployeeID,serviceRequestNumber,resourceOwner,employeeType,vendorCompany,contractEndDate)
   
        # Amending with user values to the csv
        with open(filename, "a") as file:
            file.write(addingValues)
            file.write('\n')
        file.close()  
    #===========================================================================
    # print("=============KEY============")
    # print(dict.keys())
    # print("============================")
    # print("=============VALUES============")
    # print(dict.values())
    # print("============================")
    # print("=================="+str(dict.__contains__('300000002209544')))
    #===========================================================================
except Exception as e:
    print(traceback.format_exc())
