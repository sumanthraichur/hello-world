
try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    from ldap3 import Server, Connection
    import AdTokenDecrypt
    import OktaApiTokenDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = readFromPropertiesFile.orgName
attributeManager = readFromPropertiesFile.attributeManager
attributeManagerID = readFromPropertiesFile.attributeManagerID
attributeEmail = readFromPropertiesFile.attributeEmail

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()
    
def GetObject(url):
    response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            logger.info ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList


try:
    
    search_base = "OU=Users,OU=Australia,OU=MLCLCore,DC=ad,DC=mlclife,DC=com,DC=au"
    hostName = "ad.mlclife.com.au"
    username = "mlcl\svc-OktaADAgent"
    
    listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\") and profile.email eq \"no-reply@mlctech.io\""
    logger.info(listUserUrl)
    userList = GetPaginatedResponse(listUserUrl)
    for user in userList:
        userId = user["id"]
        profile = user['profile']
        login = profile['login']
        
        search_filter = "(&(userAccountControl=512)(mail={}))".format(login)
        logger.info("AD search filter :: "+search_filter)
        
        with Connection(Server(hostName, port=389, get_info=all), user=username, password=AdTokenDecrypt.adKeyDecoded) as c:
            c.search(search_base=search_base, search_filter=search_filter, attributes=['mail'])
            response = (c.response_to_json())
            json_response = json.loads(response) 
            for entry in json_response['entries']:
                attributes = entry['attributes']
                dn = entry['dn']
                logger.info ('dn :' + dn)
                for mail in attributes['mail']:
                    logger.info('mail :' + mail)
        
                    userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
                    user_info = {}
                    user_info['profile'] = {}
                    if mail is not None:
                        user_info['profile'] [attributeEmail] = mail
                        user_info_json = json.dumps(user_info)
                        response = POSTRequest(userUrl, user_info_json)
                        if response != "Error":
                            logger.info ("Attribute " + attributeEmail + " Set to " + str(mail) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                logger.info ("\n")
except Exception as e:
    logger.info(traceback.format_exc())
