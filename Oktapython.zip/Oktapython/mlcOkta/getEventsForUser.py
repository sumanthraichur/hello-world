'''
Created on May 20, 2017

@author: debmalya.biswas
'''
import okta
from okta import EventsClient
from okta.models.event import Event
from okta.models.event import Action
from okta.models.event import Actor
from okta.models.event import Target


eventsClient = EventsClient("https://dev-530347.oktapreview.com", "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq")

events = eventsClient.get_events()

while True:
    for event in events:
        print("App eventId :               {}".format(event.eventId))
        print("App action :                {}".format(event.action))
        print("App actors :                {}".format(event.actors))
        print("App requestId :             {}".format(event.requestId))
        print("App sessionId :             {}".format(event.sessionId))
        print("App action :                {}".format(event.action))
        print("App action.message :        {}".format(event.action.message))
        print("App action.categories :     {}".format(event.action.categories))
        print("App action.objectType :     {}".format(event.action.objectType))
        print("App action.requestUri :     {}".format(event.action.requestUri))
        print("App targets :               {}\n".format(event.targets))

    if not event in events:
        
        print("No Events")
    else:
        break
