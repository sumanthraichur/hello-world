try:   
    import sys
    import csv
    import requests
    import logging
    import json
    import os
    from datetime import datetime
    import readFromPropertiesFile
    import errno
    import traceback
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends

getHCMheaders = {
    'content-type': "application/json",
    'authorization': "Basic VEVTVF9BUEk6UGVvcGxlQ291bnRAMTIz",
    }

hcmPatchHeaders = {
    'content-type': "application/vnd.oracle.adf.resourceitem+json",
    'authorization': "Basic VEVTVF9BUEk6UGVvcGxlQ291bnRAMTIz",
    }

def GetHCMObject(url): 
    response = requests.request("GET", url, headers=getHCMheaders)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.text


def PATCHRequest(url, data):
    if data != "":
        response = requests.patch(url, data=data, headers=hcmPatchHeaders)
    else:
        response = requests.patch(url, headers=hcmPatchHeaders)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

try:
    with open(readFromPropertiesFile.PersonDetailsFromUAT, 'r') as f:
        reader = csv.reader(f)
        personDetailsFromUATlist = list(reader)
        logger.info(personDetailsFromUATlist)
        
    # Reading ESBUserList csv file   
    with open('dataCheck.csv', 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        count = 1
        for row in reader:
            logger.info(" ")
            
            # Reading the CSV file attributes
            
            personNumber = row['personNumber']
            print('personNumber: %s', personNumber)
            
            UserName = row['UserName']
            logger.info('UserName: %s', UserName)
            logger.info('\n')
            
            # if not personNumber in chain.from_iterable(personDetailsFromUATlist):
            hcmUrl = "https://efly.hcm.ap4.oraclecloud.com:443/hcmCoreApi/resources/11.12.1.0/emps?q=PersonNumber=" + personNumber
            logger.info('hcmUrl : ' + hcmUrl)
            logger.info('\n')
            response = GetHCMObject(hcmUrl)
            hcmUser = json.loads(response)
                  
            for user in hcmUser['items']:
                links = user['links']
                linksList = []
                linksList = links
                for item in linksList:
                    rel = item['rel']
                    if (rel == 'self'):
                        hrefUrl = item['href']
                        logger.info("hrefUrl : " + hrefUrl)
                        logger.info('Total count: ' + str(count))
                        print('Total count: ' + str(count))
                        count += 1
                        payload = "{\r\n\t\"UserName\": """
                        payload = payload + "\"{}\"".format(UserName)
                        payload = payload + "\r\n}"
                        logger.info('Payload : \n' + payload)
                        #=======================================================
                        #       
                        # # PATCH HCM username
                        # response = PATCHRequest(hrefUrl, payload)
                        # if response != "Error":
                        #     oktaLogger.info("Username :: " + UserName + " updated in HCM ")
                        #     print("Username :: " + UserName + " updated in HCM ")
                        #     oktaLogger.info ("\n")
                        #=======================================================
except Exception as e:
    logging.error(traceback.format_exc())
