try:
    import sys
    import csv
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    import json
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
fileName = 'C:/Users/debmalya.biswas/Desktop/passwordRest.csv'
orgName="mlclimited-prodsup.oktapreview"

try:
    header = ("login")
    filename = 'C:/Users/debmalya.biswas/Desktop/UsersUATRECM.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
    grpName="SG-MLCL-RECM-UAT-User"
    listGroupUrl="https://" + orgName + ".com/api/v1/groups?q="+str(grpName)
    print("listGroupUrl :: "+str(listGroupUrl))
    groupList = oktaFunctions.GETObject(listGroupUrl)
    for group in groupList:
        groupId = group["id"]
        print("Group ID :: "+str(groupId))
        
    listUserInGrpUrl = "https://" + orgName + ".com/api/v1/groups/"+str(groupId)+"/users"
    print(listUserInGrpUrl)
    userList = oktaFunctions.GETObject(listUserInGrpUrl)
    userLst=[]
    for user in userList:
        userId = user["id"]
        profile = user['profile']
        login = profile['login']
        userLst.append(userId)
        addingValues = '{}'.format(login)
        # Amending with user values to the csv
        with open(filename, "a") as file:
            file.write(addingValues)
            file.write('\n')
        file.close()  
    usersInList = ', '.join('"' + item + '"' for item in userLst)
    updateRecmRulePayload = oktaPayLoad.updateRule(usersInList)
    print("updateRecmRulePayload :: "+str(updateRecmRulePayload))
    updateRecmRuleUrl = "https://" + orgName + ".com/api/v1/groups/rules"
    response = oktaFunctions.POSTRuleRequest(updateRecmRuleUrl, updateRecmRulePayload)
    print(response.text)
       
except Exception as e:
    logger.info(traceback.format_exc())