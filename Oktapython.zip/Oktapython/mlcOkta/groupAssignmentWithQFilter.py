import re
import csv
import logging
import traceback
import os
import errno
from datetime import datetime
import requests
import json


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends

#===============================================================================
# #============ PROD-SUP API TOKEN =================================================
# headers = {
#      'accept': "application/json",
#      'content-type': "application/json",
#      'authorization': "SSWS 00T8khxWUn2VUkRm1zcmNRcs-ot-KlMVH_0JSXVBZK"
#      #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
#      }
#===============================================================================

#===============================================================================
# #============ DEV API TOKEN ===================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 00pCgoznpH2YD1vE4PFdHpFXCDm0ncUFUgIs90Hiih"
#     }
#===============================================================================

#===============================================================================
# #============ SIT API TOKEN ==================================================
# headers = {
#     'accept': "application/json",
#     'content-type': "application/json",
#     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
#     }
#===============================================================================

#============ PROD API TOKEN =================================================
headers = {
     'accept': "application/json",
     'content-type': "application/json",
     'authorization': "SSWS 00MicNpvJD6Ekwxuc1_J6-KDvlfdjt-gb_EFX8lY21"
     #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
     }

fileName = 'C:/Users/debmalya.biswas/Desktop/AnypointUser.csv'
orgName="mlcinsurance.okta"

def GETObject(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
    
def GETRequest(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def PUTRequest(url):
    response = requests.request("PUT",url, headers=headers, verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response
try:
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        count=1
        for row in reader:
            
            logger.info("User number : "+str(count)+" in CSV File.")
            count=count+1             
            
            userlogin = row['Email']
            logger.info('login: '+str(userlogin))
            
            grpName = row['Group']
            logger.info('Group Name: '+str(grpName))
                       
            #===== User =========#
            listUserUrl = "https://" + orgName + ".com/api/v1/users?q="+str(userlogin)
            logger.info("listUserUrl :: "+(listUserUrl))
            userList = GETObject(listUserUrl)
            for user in userList:
                userId = user["id"]
                logger.info("User ID :: "+str(userId))
            
                #===== Group =========#
                listGroupUrl="https://" + orgName + ".com/api/v1/groups?q="+str(grpName)
                logger.info("listGroupUrl :: "+str(listGroupUrl))
                groupList = GETRequest(listGroupUrl)
                for group in groupList:
                    groupId = group["id"]
                    logger.info("Group ID :: "+str(groupId))
                
                    #===== Group Assignment =========#    
                    groupAddUrl ="https://"+orgName+".com/api/v1/groups/"+str(groupId)+"/users/"+str(userId)
                    logger.info("Group Add Url :: "+str(groupAddUrl))
                    logger.info("User :: "+str(userlogin)+" added to :: "+str(grpName)+" group in Okta")
                    logger.info("\n")
                    response = PUTRequest(groupAddUrl)
                    if response != "Error":
                        logger.info("User :: "+str(userlogin)+" added to :: "+str(grpName)+" group in Okta")
                        logger.info('\n')
                 


except Exception as e:
    logger.info(traceback.format_exc())