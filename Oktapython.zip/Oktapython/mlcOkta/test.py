try:
    import sys
    import readFromPropertiesFile
    import oktaLogger
    import traceback
    import os
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

orgName = "mlcinsurance.okta"

try:
    header = ("login,firstName,lastName,email,status,manager,resourceOwner,Application,Group")
    filename = 'C:/Users/A-debmalya.biswas/Desktop/UsersPROD.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
        
    listUserUrl = "https://" + orgName + ".com/api/v1/users"
    userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
    for user in userList:
        userId = user["id"]
        status = user["status"]
        profile = user['profile']
        firstName = profile['firstName']
        lastName = profile['lastName']
        login = profile['login']
        email = profile['email']
        if ("manager" in profile):
            manager = profile['manager']
        else:
            manager = "None"

        if ("resourceOwner" in profile):
            resourceOwner = profile['resourceOwner']
        else:
            resourceOwner = "None"                
        
        userAppURL = "https://" + orgName + ".com/api/v1/apps?filter=(user.id eq \""+str(userId)+"\")"
        print(userAppURL)
        userAppList = oktaFunctions.GETObject(userAppURL)
        appList = []
        for userApp in userAppList:
            label = userApp['label']
            if (label =="OpenText") or (label == "ClaimVantage") or (label == "GMC Inspire"):
                appList.append(label)
        usersAppList = ', '.join(appList)
        if usersAppList !="":
            print("Login :: "+str(login))
            usersAppList = str("\"")+usersAppList+str("\"")
            print("App Name :: "+str(usersAppList))
        else:
            print("Login :: "+str(login))
            usersAppList = "No RECM/CV/OCM Application"
            print("App Name :: "+str(usersAppList))
            
        userGrpURL = "https://" + orgName + ".com/api/v1/users/"+str(userId)+"/groups"
        userGrpList = oktaFunctions.GETObject(userGrpURL)
        grpList = []
        for userGrp in userGrpList:
            profile = userGrp['profile']
            name = profile['name']
            name = str("\"")+name+str("\"")
            print("App Group :: "+str(name))
            if (name !="Everyone"):
                addingValues = '{},{},{},{},{},{},{},{},{}'.format(login,firstName,lastName,email,status,manager,resourceOwner,usersAppList,name)
                print(addingValues)
                print("\n")
                # Amending with user values to the csv
                with open(filename, "a") as file:
                    file.write(addingValues)
                    file.write('\n')
                file.close()
            
except Exception as e:
    print(traceback.format_exc())
