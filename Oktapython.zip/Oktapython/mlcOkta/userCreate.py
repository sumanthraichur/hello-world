import os
import requests
import csv
import traceback
import json
import time


orgName="mlcinsurance.okta"
url = "https://"+orgName+".com/api/v1/users"
fileName = 'C:/Users/debmalya.biswas/Desktop/oktasdk-python-master/userCreate.csv'

querystring = {"activate":"true"}

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00MicNpvJD6Ekwxuc1_J6-KDvlfdjt-gb_EFX8lY21",
    }
def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            print ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
    

def POSTRequestPassword(url, querystring):
    if querystring != "":
        response = requests.post(url, headers=headers, params=querystring)
        response = "[" + response.text + "]"
        json_response = json.loads(response)
        for item in json_response:
            seacrhPassword = item['tempPassword']
            passwordList = []
            passwordList = seacrhPassword
        return passwordList    


def GETRequest(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()

   
try:
    header = ("login,Password")
    outputFilename = 'C:/Users/debmalya.biswas/Desktop/TechMusers.csv'
    if os.path.exists(outputFilename):
        print("File exists")
    elif not os.path.exists(outputFilename):
        print("File does not exists, creating new file")
        file = open(outputFilename, 'w+')
        file.write(header)
        file.write('\n')
    
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            print("User number : "+str(count)+" in CSV File.")
            count=count+1 
            print("#============ User Check =================#")
            firstName = row['firstName']
            print("First Name :: "+str(firstName))
            
            lastName = row['lastName']
            print("Last Name :: "+str(lastName))
            
            email = row['email']
            print("Email :: "+str(email))
            
            login = row['login']
            print("Login :: "+str(login))
            
            UserPayload = "{\n  \"profile\": {\n    \"firstName\": \""+str(firstName)+"\",\n    \"lastName\": \""+str(lastName)+"\",\n    \"email\": \""+str(email)+"\",\n    \"login\": \""+str(login)+"\"\n  }\n}"
            print("User Creation Payload :: \n"+str(UserPayload))
            querystring = {"activate":"true"}
            response = requests.request("POST", url, data=UserPayload, headers=headers, params=querystring)
            print("User "+str(login)+" created in Okta "+str(orgName))
            time.sleep(5)
            
            listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(login)+"\")"
            print(listUserUrl)
            userList = GetPaginatedResponse(listUserUrl)
            for user in userList:
                userId = user["id"]
                print("Okta User Unique ID :: "+str(userId))
                print("\n")
                
            groups = row['groups']
            print("Groups :: "+str(groups))
            groupList = groups.split(',')
            for x in groupList:
                groupUrl = "https://"+orgName+".com/api/v1/groups?q="+str(x)
                print("Group URL :: "+str(groupUrl))
                groupList = GETRequest(groupUrl)
                for group in groupList:
                    groupId = group["id"]
                    print("Okta Group Unique ID :: "+str(groupId))
                    userToAddGroupUrl="https://"+orgName+".com/api/v1/groups/"+str(groupId)+"/users/"+str(userId)
                    print("User Added to Group URL :: "+str(userToAddGroupUrl))
                    response = requests.request("PUT", userToAddGroupUrl, headers=headers)
                    print("User added to "+str(x)+" group")
                    print("\n")
            
            time.sleep(10)        
            expirePasswordUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId) + "/lifecycle/expire_password"
            print("Temporary Password URL :: "+str(expirePasswordUrl))
            query = {"tempPassword":"true"}
            userPassword = POSTRequestPassword(expirePasswordUrl, query)
            addingValues = '{},{}'.format(login,userPassword)
   
            # Amending with user values to the csv
            with open(outputFilename, "a") as file:
                file.write(addingValues)
                file.write('\n')
            file.close()              
            print("\n")
                 
except Exception as e:
    print(traceback.format_exc())            