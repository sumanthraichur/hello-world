try:
    import sys
    import logging
    import traceback
    import json
    import errno
    import os
    import csv
    import oktaFunctions
    from datetime import datetime
    from ldap3 import Server, Connection
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = "mlcinsurance.okta"
search_base = "OU=ExtUsers,OU=Australia,OU=MLCLCore,DC=ad,DC=mlclife,DC=com,DC=au"
hostName = "ad.mlclife.com.au"
username = "mlcl\svc-oktaagent-p"
password = "7Mkc(RVFxfHJ]w$7"
fileName = "C:/Users/debmalya.biswas/Desktop/CWUsers.csv"
try:
    #===========================================================================
    # header = ("SamAccountName,UserPrincipalName,ADAccountStatus,AccountExpirationDate,LastLogon,LastLogonTimestamp,ContractEndDate")
    # filename = 'C:/Users/debmalya.biswas/Desktop/CWUsersADPROD.csv'
    # if os.path.exists(filename):
    #     print("File exists")
    # elif not os.path.exists(filename):
    #     print("File does not exists, creating new file")
    #     file = open(filename, 'w+')
    #     file.write(header)
    #     file.write('\n')
    #===========================================================================
    
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            print("User number : "+str(count)+" in CSV File.")
            count=count+1
             
            userLogin = row['UserPrincipalName']
            print("userLogin ::"+str(userLogin))
    
            listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(userLogin)+"\")"
            logger.info(listUserUrl)
            userList = oktaFunctions.GETObject(listUserUrl)
            for user in userList:
                userId = user["id"]
                status = user["status"]
                profile = user['profile']
                login = profile['login']
                if ("contractEndDate" in profile):
                    contractEndDate = profile['contractEndDate']
                else:
                    contractEndDate = "None" 
                
                search_filter = "(userPrincipalName={})".format(login)
                logger.info("AD search filter :: "+search_filter)
                
                with Connection(Server(hostName, port=389, get_info=all), user=username, password=password) as c:
                    c.search(search_base=search_base, search_filter=search_filter, attributes=['sAMAccountName','userPrincipalName','accountExpires','userAccountControl','lastLogon','lastLogonTimestamp'])
                    response = (c.response_to_json())
                    json_response = json.loads(response) 
                    for entry in json_response['entries']:
                        attributes = entry['attributes']
                        print(attributes)
                        dn = entry['dn']
                        print ('dn :' + dn)
                        
                        for accountExpires in attributes['accountExpires']:
                            if (accountExpires!="9223372036854775807") or (accountExpires!="0"):
                                accountExpires = oktaFunctions.LDAPToHumanTime(int(accountExpires))
                                print ('accountExpires : ' + str(accountExpires))
                            else:
                                accountExpires="Junk Value"
                                print ('accountExpires : ' + str(accountExpires))
                                
                        for userPrincipalName in attributes['userPrincipalName']:
                            print ('userPrincipalName : ' + userPrincipalName)
                            
                        for sAMAccountName in attributes['sAMAccountName']:
                            print ('sAMAccountName : ' + sAMAccountName)                            
                        
                        for userAccountControl in attributes['userAccountControl']:
                            print ('userAccountControl : ' + userAccountControl)
                        
                        if oktaFunctions.Enquiry(attributes['lastLogonTimestamp']):
                            print("Last Logon Timestamp Attribute value :: "+str(attributes['lastLogonTimestamp']))
                            for lastLogonTimestamp in attributes['lastLogonTimestamp']:
                                lastLogonTimestamp = int(lastLogonTimestamp)
                                lastLogonTimestamp = oktaFunctions.LDAPToHumanTime(lastLogonTimestamp)
                                print ('lastLogonTimestamp : ' + str(lastLogonTimestamp))
                        else:
                            lastLogonTimestamp = "None"
                            print ('lastLogonTimestamp : ' + str(lastLogonTimestamp))
                            
                        if oktaFunctions.Enquiry(attributes['lastLogon']):
                            print("Last Logon Attribute value :: "+str(attributes['lastLogon']))
                            for lastLogon in attributes['lastLogon']:
                                lastLogon = int(lastLogon)
                                lastLogon = oktaFunctions.LDAPToHumanTime(lastLogon) 
                                print ('lastLogon : ' + str(lastLogon))
                        else:
                            lastLogon = "None"
                            print ('lastLogon : ' + str(lastLogon))                            
                                              
                    print("contractEndDate : "+str(contractEndDate))
                    print("\n")
                    
           #====================================================================
           #          addingValues = '{},{},{},{},{},{},{}'.format(sAMAccountName,userPrincipalName,userAccountControl,accountExpires,lastLogon,lastLogonTimestamp,contractEndDate)
           # 
           #          # Amending with user values to the csv
           #          with open(filename, "a") as file:
           #              file.write(addingValues)
           #              file.write('\n')
           #          file.close()                                                 
           #====================================================================

except Exception as e:
    logger.info(traceback.format_exc())
