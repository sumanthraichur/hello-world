try:
    import sys
    import csv
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    import json
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
fileName = 'C:/Users/debmalya.biswas/Desktop/users.csv'
orgName="mlclimited-sit.oktapreview"

def Enquiry(lst):
    if len(lst) == 0:
        return 0
    else:
        return 1

try:
    header = ("login,manager,SaviyntApp")
    ofilename = 'C:/Users/debmalya.biswas/Desktop/UsersSIT_Saviynt.csv'
    if os.path.exists(ofilename):
        print("File exists")
    elif not os.path.exists(ofilename):
        print("File does not exists, creating new file")
        file = open(ofilename, 'w+')
        file.write(header)
        file.write('\n')
        
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        count=1
        for row in reader:
            
            print("User number : "+str(count)+" in CSV File.")
            count=count+1             
            
            userlogin = row['login']
            print('login: '+str(userlogin))
                       
            #===== User =========#
            listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(userlogin)+"\")"
            print("listUserUrl :: "+(listUserUrl))
            userList = oktaFunctions.GETObject(listUserUrl)
            if Enquiry(userList):
                for user in userList:
                    userId = user["id"]
                    profile = user['profile']
                    login = profile['login']
                    print("login :: "+str(login))
                    if ("manager" in profile):
                        manager = profile['manager']
                    else:
                        manager = "None"                 
                    print("manager :: "+str(manager))
                    if (manager !="None"):
                        listMngrUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(manager)+"\")"
                        mngrList = oktaFunctions.GETObject(listMngrUrl)
                        for mngr in mngrList:
                            profile = mngr['profile']
                            if ("isManager" in profile):
                                isManager = profile['isManager']
                            else:
                                isManager = "None" 
                            print("isManager :: "+str(isManager))
                            print('\n')
                    elif (manager =="None"):
                        isManager = "None"
            else:
                manager = "User not present in Okta"
                print(manager)
                isManager = ""
            addingValues = '{},{},{}'.format(userlogin,manager,isManager)
   
            # Amending with user values to the csv
            with open(ofilename, "a") as file:
                file.write(addingValues)
                file.write('\n')
            file.close()  



except Exception as e:
    logger.info(traceback.format_exc()) 