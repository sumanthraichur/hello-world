try:   
    import sys
    import csv
    import requests
    import logging
    import json
    import re
    import os
    from datetime import datetime
    import errno
    import traceback
    import readFromPropertiesFile
    import OktaApiTokenDecrypt
    from okta import AppInstanceClient
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends


orgName = readFromPropertiesFile.orgName
userLogin = readFromPropertiesFile.userLogin
filterUserLogin = readFromPropertiesFile.filterUserLogin
jobFamily = readFromPropertiesFile.jobFamily
jobFunction = readFromPropertiesFile.jobFunction
jobRole = readFromPropertiesFile.jobRole


oktaUrl = "https://" + orgName + ".com"
grpUrl = "https://" + orgName + ".com/api/v1/groups"
ruleUrl = "https://" + orgName + ".com/api/v1/groups/rules"
appUrl = "https://" + orgName + ".com/api/v1/apps/"
userUrl = "https://" + orgName + ".com/api/v1/users"

appInstanceClient = AppInstanceClient(oktaUrl, OktaApiTokenDecrypt.apiKeyOktaDecoded)
apps = appInstanceClient.get_app_instances()


def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers, verify=False)
    else:
        response = requests.post(url, headers=headers, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()
    
def POSTRuleRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers, verify=False)
    else:
        response = requests.post(url, headers=headers, verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response
    
def PUTRequest(url):
    response = requests.request("PUT",url, headers=headers, verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response

def GETRequest(url, params):
    response = requests.request("GET", url, params=params, headers=headers, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS "+ OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }


logger.info("\n")
logger.info('Start reading group CSV file')

try:
    with open(readFromPropertiesFile.fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader: 
            #print(" ")
            logger.info(" ")
        #==================================================================================================#
            #Reading the CSV file attributes
            grpName = row[readFromPropertiesFile.groupName]
            logger.info('GroupName: %s', grpName)
         
            grpDesc = row[readFromPropertiesFile.groupDescription]
            logger.info('Group Description: %s', grpDesc)
         
            grpType = row[readFromPropertiesFile.groupType]
            logger.info('GroupType(Manual/Auto): %s', grpType)
         
            grpMembershipRuleType = row[readFromPropertiesFile.membershipRuleType]
            logger.info('Membership Rule Type: %s', grpMembershipRuleType)
         
            grpCascadingName = row[readFromPropertiesFile.cascadingGroupName]
            logger.info('Cascading Group Name: %s', grpCascadingName)
        
            grpAttributeRule = row[readFromPropertiesFile.attributeRule]
            logger.info('Attribute Rule: %s', grpAttributeRule)
         
            grpManualMembershipAssistant = row[readFromPropertiesFile.manualMembershipAssignment]
            logger.info('Manual Membership Assignment: %s', grpManualMembershipAssistant)
         
            groupApplicationAssignment = row[readFromPropertiesFile.groupApplicationAssignment] 
            logger.info('Group Application Assignment: %s', groupApplicationAssignment)
            
            payLoad = "{\n  \"profile\": {\n    \""
            payLoad = payLoad+(("name\": \"{}").format(grpName))
            payLoad = payLoad+(("\",\n    \"description\": \"{}").format(grpDesc))
            payLoad = payLoad+"\"\n  }\n}"
            logger.info("Creating group with parameter : {}".format(payLoad))
            logger.info("\n")
         
            logger.info('Creating Groups ...')
            responseRuleGroup = POSTRequest(grpUrl, payLoad)
            if responseRuleGroup != "Error":
                logger.info('Finished Creating Groups')
                logger.info("Json output : {}".format(responseRuleGroup))
            
                seacrhGroup = responseRuleGroup['id']
                groupList = []
                groupList = seacrhGroup
                logger.info("Searched Group ID : {}".format(groupList))
                if groupApplicationAssignment is not None:
                    logger.info(groupApplicationAssignment)
                    groupApplicationAssignment = re.split(r';', groupApplicationAssignment)
                    for i, valueOfApp in enumerate(groupApplicationAssignment):
                        if valueOfApp != "":
                            logger.info("Application Name: {}".format(valueOfApp))
                        else:
                            logger.info("Application Name is null")
                        logger.info("\n")
                        for app in apps:
                            appId = app.id
                            appLabel = app.label
                            aDict = {}
                            aDict[appLabel] = appId
                            for appId in enumerate(aDict):
                                if valueOfApp == appLabel:
                                    applicationId = ''.join(aDict.values())
                                    logger.info("Application ID : {}".format(applicationId))
                                    groupApplicationUrl = appUrl + "/" + applicationId + "/groups/" + groupList
                                    logger.info("Assigning application to group URL : {}".format(groupApplicationUrl))
                                    payload = "{\n}"
                                    response = PUTRequest(groupApplicationUrl, payload)
                                    if response != "Error":
                                        logger.info(response)
                                        logger.info("\n")
            else:
                logger.info('Error Creating Groups')
            logger.info("\n")        
    #==================================================================================================#                           
            #When Membership Type is Attribute Rule and Group Rule Creation Type is Automatic    
            if grpType.upper() == 'AUTO' and grpMembershipRuleType.upper() == 'ATTRIBUTE' and responseRuleGroup != "Error":
                logger.info("When Membership Type is Attribute Rule and Group Rule Creation Type is Automatic") 
                logger.info("Creating User in AD in with values : {}".format(grpAttributeRule))
                logger.info("Group attribute rule data : {}".format(grpAttributeRule))
                grpAttributeRule = json.loads(grpAttributeRule)
                grpAttributeRulejobFamily = grpAttributeRule[jobFamily]
                grpAttributeRulejobFunction = grpAttributeRule[jobFunction]
                grpAttributeRulejobRole = grpAttributeRule[jobRole]
                
                logger.info("User job Family : {}".format(grpAttributeRulejobFamily))
                logger.info("User job Function : {}".format(grpAttributeRulejobFunction))
                logger.info("User job Role : {}\n".format(grpAttributeRulejobRole))
                     
                grpAttributeRulejobFamily = re.split(r';', grpAttributeRulejobFamily)
                grpAttributeRulejobFunction = re.split(r';', grpAttributeRulejobFunction)
                grpAttributeRulejobRole = re.split(r';', grpAttributeRulejobRole)
                     
                logger.info ("grpAttributeRulejobFamily : {}".format(grpAttributeRulejobFamily))
                logger.info ("grpAttributeRulejobFunction : {}".format(grpAttributeRulejobFunction))
                logger.info ("grpAttributeRulejobFunction : {}".format(grpAttributeRulejobRole))
                     
                logger.info("\n")
                     
                grpAttributeRulejobFamily = '{\\"' + '\\",\\"'.join(grpAttributeRulejobFamily) + '\\"}' 
                logger.info("Group attribute rule job family value : {}".format(grpAttributeRulejobFamily))
                     
                logger.info("\n")
                
                grpAttributeRulejobFunction = '{\\"' + '\\",\\"'.join(grpAttributeRulejobFunction) + '\\"}' 
                logger.info("Group attribute Rule job function value : {}".format(grpAttributeRulejobFunction))
                     
                logger.info("\n")
                
                grpAttributeRulejobRole = '{\\"' + '\\",\\"'.join(grpAttributeRulejobRole) + '\\"}' 
                logger.info("Group attribute Rule job role value: {}".format(grpAttributeRulejobRole))
                     
                payload = "{\n      \"type\": \"group_rule\",\n      \"name\""
                payload = payload+(": \"{} rule\",\n      \"status\": \"INACTIVE\",\n      \"conditions\"").format(grpName)
                payload = payload+": {\n          \"expression\": {\n            \"value\""
                payload = payload+": \"Arrays.contains({},".format(grpAttributeRulejobFamily)
                payload = payload+"user.{})".format(jobFamily)
                payload = payload+" and Arrays.contains({},".format(grpAttributeRulejobFunction)
                payload = payload+"user.{})".format(jobFunction)
                payload = payload+" and Arrays.contains({},".format(grpAttributeRulejobRole)
                payload = payload+"user.{})\"".format(jobRole)
                payload = payload+",\n            \"type\": \"urn:okta:expression:1.0\"\n          }\n        },\n      \"actions\""
                payload = payload+": {\n        \"assignUserToGroups\": {\n          \"groupIds\""
                payload = payload+": [\n            \"{}\"\n          ]".format(groupList)
                payload = payload+"\n        }\n    }\n}\n"
                logger.info("Attribute Rule creation value: {}".format(payload))
                     
                responseRule = POSTRequest(ruleUrl, payload)
                logger.info("Attribute Rule creation response : {}".format(responseRule))
                logger.info("{} Rule Created".format(grpName))
                seacrhRule = responseRule['id']
                ruleList = []
                ruleList = seacrhRule
                logger.info("Searched Rule ID : {}".format(ruleList))
                 
                activateRuleUrl = ruleUrl + "/" + ruleList + "/lifecycle/activate"
                logger.info("Rule activation URL : {}".format(activateRuleUrl))
                response = POSTRuleRequest(activateRuleUrl, payload)
                logger.info ("{} Rule Activated".format(grpName))
                logger.info("\n")
    #==================================================================================================# 
            #When Membership Type is Cascade Rule and Group is not null 
            elif grpMembershipRuleType.upper() == 'CASCADE' and grpCascadingName is not None and responseRuleGroup != "Error":
                logger.info("When Membership Type is Cascade Rule and Group is not null")
                cascadeGroupName = None
                grpCascadingName = re.split(r';', grpCascadingName)
                logger.info("Cascading Group Name: {}".format(grpCascadingName))
                for i, valueOfGroup in enumerate(grpCascadingName):
                    querystring = {"q":"" + valueOfGroup}
                    response = GETRequest(grpUrl, querystring)
                    for item in response:
                        cascadeGroupUserId = item['id']
                        cascadeGroupList = []
                        cascadeGroupList = (cascadeGroupUserId)
                        grpCascading = (cascadeGroupList) 
                    if cascadeGroupName is None:
                        cascadeGroupName = '(\\"' + grpCascading + '\\",'
                    elif cascadeGroupName is not None:
                        cascadeGroupName += '\\"' + grpCascading + '\\",'
                  
                cascadeGroupName = re.sub(',$', ')', cascadeGroupName)
                logger.info("Cascade Group Name: {}".format(cascadeGroupName))
              
                payload = "{\n      \"type\": \"group_rule\",\n      \""
                payload = payload+"name\": \"{} Rule\",\n      \"".format(grpName)
                payload = payload+"status\": \"INACTIVE\",\n      \"conditions\": {\n          \"expression\": {\n        \t\"value\": \""
                payload = payload+"isMemberOfAnyGroup{}\"".format(cascadeGroupName)
                payload = payload+",\n           \"type\": \"urn:okta:expression:1.0\"\n          }\n        },\n      \"actions\": {\n        \"assignUserToGroups\": {\n          \"groupIds\""
                payload = payload+": [\n            \"{}\"\n          ]\n        ".format(groupList)
                payload = payload+"}\n      }\n    }\n"
               
                logger.info("Is member of group value : {}".format(payload))
            
                responseRule = POSTRequest(ruleUrl, payload)
                logger.info("Response Rule: {}".format(responseRule))
            
                logger.info("{} Rule Created".format(grpName))
            
                seacrhRule = responseRule['id']
                ruleList = []
                ruleList = seacrhRule
                logger.info("Searched Rule ID : {}".format(ruleList))
                 
                activateRuleUrl = ruleUrl + "/" + ruleList + "/lifecycle/activate"
                logger.info("Rule activation URL: {}".format(activateRuleUrl))
                
                response = POSTRuleRequest(activateRuleUrl, payload)
                logger.info ("{} Rule Activated".format(grpName))
                logger.info("\n")
    #==================================================================================================#  
            #When Membership Type is Manual, and user login is not null, adding user to that group
            elif grpMembershipRuleType.upper() == 'MANUAL'and grpManualMembershipAssistant is not None and responseRuleGroup != "Error":
                logger.info("When Membership Type is Manual, and user login is not null, adding user to that group")
                json_response = json.loads(grpManualMembershipAssistant)
                grpManualMembershipAssistant = json_response[userLogin]
                grpmanualMembershipAssignment = re.split(r';', grpManualMembershipAssistant)
                logger.info("Group membership user login value : {}".format(grpmanualMembershipAssignment))
                for i, valueOfUser in enumerate(grpmanualMembershipAssignment):
                    querystring = {"filter":"" + filterUserLogin + " eq \"" + valueOfUser + "\""}
                    response = GETRequest(userUrl, querystring)
                    for item in (response):
                        manualMembershipAssignmentUserId = item['id']
                        manualMembershipAssignmentUserIdList = []
                        manualMembershipAssignmentUserIdList = (manualMembershipAssignmentUserId)
                        manualMembershipAssignmentUserId = (manualMembershipAssignmentUserIdList)
                        logger.info("User id adding to group : {}".format(manualMembershipAssignmentUserId))
                        membershipUrl = grpUrl + "/" + groupList + "/users/" + manualMembershipAssignmentUserId
                        logger.info("Adding User to group URL : {}".format(membershipUrl))
                        response = PUTRequest(membershipUrl)
                        logger.info ("User" + manualMembershipAssignmentUserId + " Added to group {} \n".format(grpName))
                        logger.info("\n")           
            
except Exception as e:
    logging.error(traceback.format_exc())