try:
    import json
    import requests
    import datetime
    import sys
    import logging
    import readFromPropertiesFile
    import OktaApiTokenDecrypt
    import traceback
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
orgName = readFromPropertiesFile.orgName
attributeNameStatus = readFromPropertiesFile.attributeNameStatus
attributeNameID = readFromPropertiesFile.attributeNameID

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# creating a file handler
handler = logging.FileHandler('logs/mlcUserSuspend.log')
handler.setLevel(logging.INFO)

# creating a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

# adding the handlers to the oktaLogger
logger.addHandler(handler)


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + OktaApiTokenDecrypt.apiKeyOktaDecoded ,
    }

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            logger.info ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList


def GetObject(url): 
    response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

def SUSPENDRequest(url):
    response = requests.post(url, headers=headers)
    responseJSON = response
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return responseJSON

def ACTIVERequest(url):
    response = requests.post(url, headers=headers)
    responseJSON = response
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return responseJSON

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

try:       
    currentDate = datetime.datetime.now().strftime("%Y-%m-%d")
    url = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\") and lastUpdated gt \"{}T00:00:00.000Z\"".format(currentDate)
    activedUsers = GetPaginatedResponse(url)
    for user in activedUsers:
        userId = str(user["id"])
        userStatus = user["status"]
        profile = user['profile']
        if "mlcUserStatus" in profile:
            mlcUserStatus = profile["mlcUserStatus"]
            if "contractEndDate" in profile:
                endDate = profile["contractEndDate"]
                if ((endDate is not None) or (endDate != "") or (endDate != "null"))and (endDate < currentDate):
                    
                    logger.info("User Login : " + profile["login"])
                    logger.info("currentDate : {}".format(currentDate))
                    logger.info("mlcUserStatus : {}".format(mlcUserStatus))
                    logger.info("contractEndDate : {}".format(endDate))
                   
                    suspendUrl = "https://" + orgName + ".com/api/v1/users/" + userId + "/lifecycle/suspend"
                    logger.info("suspendUrl : {}".format(suspendUrl))
                    logger.info("\n")
                       
                    userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
                    
                    user_info_json = "{\n  \"profile\": {\n\t\t\""
                    user_info_json = user_info_json + "{}\":\"".format(attributeNameStatus)
                    user_info_json = user_info_json + "SUSPENDED\"\n  "
                    user_info_json = user_info_json + "}\t\n}"
                    responsePost = POSTRequest(userUrl, user_info_json)
                     
                    logger.info(attributeNameStatus + " for User {} updated with value : 'SUSPENDED'".format(str(profile["firstName"]) + " " + str(profile["lastName"])))
                         
                    responseSuspend = SUSPENDRequest(suspendUrl)
                    if responseSuspend != "Error":
                        logger.info("User {} suspended as Contract End date is before current date".format(str(profile["firstName"]) + " " + str(profile["lastName"])))
                        logger.info("\n")
                    
            elif "endDate" in profile:
                endDate = profile["endDate"]
                if ((endDate is not None) or (endDate != "") or (endDate != "null")) and (endDate < currentDate):
                    
                    logger.info("User Login : " + profile["login"])
                    logger.info("currentDate : {}".format(currentDate))
                    logger.info("mlcUserStatus : {}".format(mlcUserStatus))
                    logger.info("EndDate : {}".format(endDate))
                   
                    suspendUrl = "https://" + orgName + ".com/api/v1/users/" + userId + "/lifecycle/suspend"
                    logger.info("suspendUrl : {}".format(suspendUrl))
                       
                    userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
                    
                    user_info_json = "{\n  \"profile\": {\n\t\t\""
                    user_info_json = user_info_json + "{}\":\"".format(attributeNameStatus)
                    user_info_json = user_info_json + "SUSPENDED\"\n  "
                    user_info_json = user_info_json + "}\t\n}"
                    responsePost = POSTRequest(userUrl, user_info_json)
                     
                    logger.info(attributeNameStatus + " for User {} updated with value : 'SUSPENDED'".format(str(profile["firstName"]) + " " + str(profile["lastName"])))
                         
                    responseSuspend = SUSPENDRequest(suspendUrl)
                    if responseSuspend != "Error":
                        logger.info("User {} suspended as End date is before current date".format(str(profile["firstName"]) + " " + str(profile["lastName"])))
                        logger.info("\n")
            
except Exception as e:
    logger.info(traceback.format_exc())
