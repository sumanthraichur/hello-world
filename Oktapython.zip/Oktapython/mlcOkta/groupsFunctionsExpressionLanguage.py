try:   
    import sys
    import logging
    import oktaFunctions
    import oktaLogger
    import traceback
    import oktaPayLoad
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName = "mlclimited.oktapreview"
grpUrl = "https://" + orgName + ".com/api/v1/groups"
mappingUrl = "https://" + orgName + ".com/api/internal/v1/mappings"
oktaIdUrl = "https://" + orgName + ".com/api/v1/user/types/default"
adUrl = "https://" + orgName + ".com/api/v1/apps/user/types?expand=app%2CappLogo&category=directory"


try:
    lst = []     
    groupList = oktaFunctions.GetPaginatedResponse(grpUrl)
    for group in groupList:
        groupIds = group["id"]
        grptype = group["type"]
        profile = group["profile"]
        name = profile["name"]
        objectClass =''.join(group["objectClass"])
        if ((grptype == "OKTA_GROUP") and (objectClass=="okta:user_group")) or ((grptype == "APP_GROUP") and (objectClass=="okta:windows_security_principal")):
            lst.append(groupIds)
            
    getFilteredGroups="getFilteredGroups({"
    getFilteredGroups=getFilteredGroups+(', '.join('\\"' + item + '\\"' for item in lst))+"},\\"
    getFilteredGroups = getFilteredGroups+""""(group.objectClass[0] == 'okta:user_group') ? group.name : null\\", 100)"""
    oktaLogger.logger.info("Groups Functions for Static Group Whitelists :: "+str(getFilteredGroups))
    
    oktaIdList = oktaFunctions.GETRequest(oktaIdUrl,"")
    oktaIdList = oktaIdList[0]
    oktaTargetId = ''.join(oktaIdList[1])
     
    adIdList = oktaFunctions.GetPaginatedResponse(adUrl)
    for adId in adIdList:
        sourceId = adId["id"]
    
    adPayLoad = oktaPayLoad.adPayLoad(sourceId, oktaTargetId, getFilteredGroups)
    
    oktaLogger.logger.info("Mapping :: AD --> Okta \n"+str(adPayLoad))  
    #===========================================================================
    # mappingResponse = oktaFunctions.PUTRequest(mappingUrl,payLoad.adPayLoad)
    # if mappingResponse != "Error":
    #     oktaLogger.logger.info("Mapping updated in AD --> Okta")
    #===========================================================================
     
    
except Exception as e:
    logging.error(traceback.format_exc())