
from ldap3 import Server, Connection, ALL, MODIFY_REPLACE, MODIFY_ADD
import traceback
import csv
import json
import oktaLogger
import os


logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
logger.info('Start reading group CSV file')
logger.info("\n") 


search_base = "OU=ExtUsers,OU=Australia,OU=MLCLCore,DC=ad,DC=mlclife,DC=com,DC=au"
hostName = "ad.mlclife.com.au"
username = "mlcl\svc-oktaagent-p"
password = "7Mkc(RVFxfHJ]w$7"
fileName = "C:/Users/debmalya.biswas/Desktop/users_List.csv"


try:
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        count=1
        for row in reader:
            logger.info("User number : "+str(count)+" in CSV File.")
            count=count+1             
             
            login = row['sAMAccountName']
            logger.info('login: '+str(login))
            
            email = row['mail']
            logger.info('email: '+str(email))
    
            search_filter = "(&(userAccountControl=512)(sAMAccountName={}))".format(login)
            logger.info("AD search filter :: "+search_filter)        
            with Connection(Server(hostName, port=389, get_info=all), user=username, password=password) as c:
                c.search(search_base=search_base, search_filter=search_filter, attributes=['sAMAccountName','mail'])
                response = (c.response_to_json())
                json_response = json.loads(response)
                logger.info(json_response)
                for entry in json_response['entries']:
                    attributes = entry['attributes']
                    dn = entry['dn']
                    logger.info ('dn :' + dn)
                    logger.info("\n")
                    c.bind()
                    # perform the Modify operation
                    c.modify(dn,{'mail': [(MODIFY_ADD, [str(email)])]})
                    logger.info(c.result)
                    logger.info("\n")
                    # close the connection
                    c.unbind()

except Exception as e:
    logger.info(traceback.format_exc())