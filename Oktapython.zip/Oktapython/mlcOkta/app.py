
from okta import AppInstanceClient
import readFromPropertiesFile

appInstanceClient = AppInstanceClient(readFromPropertiesFile.oktaUrl, readFromPropertiesFile.apiKey)
apps = appInstanceClient.get_app_instances()

for app in apps:
    appId = app.id
    appLabel = app.label
    aDict = {}
    aDict[appLabel] = appId
    for appId in enumerate(aDict):
        if 'ServiceNow' == appLabel:
            applicationId = ''.join(aDict.values())
            print(applicationId)