:class:`EventsClient`
=====================

.. currentmodule:: okta

.. autoclass:: EventsClient
  :members: