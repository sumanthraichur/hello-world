import okta
from okta import UsersClient
from okta.models.user import User
from okta.models.user import UserProfile

appUrl = "https://dev-530347.oktapreview.com"
appAPiKey = "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq"
usersClient = UsersClient(appUrl, appAPiKey)

users = usersClient.get_user_applinks("debmalya.biswas@accenture.com")

while True:
    for user in users:
        print("App Name :   {}".format(user.profile.firstName))
    if not user in users:
        print ("No Users")
    else:
        break

