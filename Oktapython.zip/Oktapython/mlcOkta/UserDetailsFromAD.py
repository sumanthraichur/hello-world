try:
    import sys
    import csv
    import oktaFunctions
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    from ldap3 import Server, Connection
    import json
    from datetime import datetime
    from dateutil import tz
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
from_zone = tz.gettz('UTC')
to_zone = tz.gettz('Australia/Sydney')

def zuluToHumanTime(time):
    from_zone = tz.tzutc()
    to_zone = tz.tzlocal()
    string = time
    string = string.replace(".0Z", "")
    string = string[:4] + '-' + string[4:]
    string = string[:7] + '-' + string[7:]
    string = string[:10] + ' ' + string[10:]
    string = string[:13] + ':' + string[13:]
    string = string[:16] + ':' + string[16:]
    utc = datetime.strptime(string, '%Y-%m-%d %H:%M:%S')
    utc = utc.replace(tzinfo=from_zone)
    aest = str(utc.astimezone(to_zone))
    aest = aest.replace("+10:00", "")
    return aest


def LDAPtoHumanTime(time):
    toHumanTime = datetime.fromtimestamp((time - 116444736000000000) // 10000000)
    return toHumanTime

search_base = "DC=ad,DC=mlclife,DC=com,DC=au"
hostName = "ad.mlclife.com.au"
username = "mlcl\svc-oktaagent-p"
password = "7Mkc(RVFxfHJ]w$7"
fileName = 'C:/Users/debmalya.biswas/Desktop/ADusers.csv'

logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
print("\n")
print('Start reading group CSV file')
print("\n")    


try:
    header = ("login,whenCreated,lastLogon,lastLogonTimestamp")
    filename = 'C:/Users/debmalya.biswas/Desktop/UsersPROD_JIRA.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
        
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            print("User number : %s in CSV File.", count)
            count=count+1 
            print("#============ User Check =================#")
            
            login = row['login']
            print("User login :: "+str(login))
            
            search_filter = "(&(userAccountControl=512)(userPrincipalName={}))".format(login)
            logger.info("AD search filter :: "+search_filter)
            with Connection(Server(hostName, port=389, get_info=all), user=username, password=password) as c:
                c.search(search_base=search_base, search_filter=search_filter, attributes=['whenCreated','lastLogon','lastLogonTimestamp'])
                response = (c.response_to_json())
                json_response = json.loads(response)
                logger.info(json_response)
                for entry in json_response['entries']:
                    attributes = entry['attributes']
                    dn = entry['dn']
                    logger.info ('dn :' + dn)
                    
                    whenCreated = ''.join(attributes['whenCreated'])
                    whenCreated = zuluToHumanTime(whenCreated)
                    logger.info ('whenCreated :' + str(whenCreated))
                    
                    lastLogon = "None"
                    for lastLogon in attributes['lastLogon']:
                        lastLogon = ''.join(attributes['lastLogon'])
                        if lastLogon!="0":
                            lastLogon = int(lastLogon)
                            lastLogon = LDAPtoHumanTime(lastLogon)
                        else:
                            lastLogon = "None"
                        logger.info ('lastLogon :' + str(lastLogon))
                    
                    lastLogonTimestamp = "None"
                    for lastLogonTimestamp in attributes['lastLogonTimestamp']:
                        lastLogonTimestamp = ''.join(attributes['lastLogonTimestamp'])
                        if lastLogonTimestamp!="0":
                            lastLogonTimestamp = int(lastLogonTimestamp)
                            lastLogonTimestamp = LDAPtoHumanTime(lastLogonTimestamp)
                        else:
                            lastLogonTimestamp = "None"
                        logger.info ('lastLogonTimestamp :' + str(lastLogonTimestamp))                                 
                        logger.info("\n")
                    
                    addingValues = '{},{},{},{}'.format(login,whenCreated,lastLogon,lastLogonTimestamp)
   
                    # Amending with user values to the csv
                    with open(filename, "a") as file:
                        file.write(addingValues)
                        file.write('\n')
                    file.close()     
            

except Exception as e:
    print(traceback.format_exc())