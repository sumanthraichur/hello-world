try:
    import feedparser
    import requests
    import readFromPropertiesFile
    import OktaApiTokenDecrypt
    import json
    import re
    import sys
    import traceback
    import smtplib
    from smtplib import SMTPException
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    import logging
    import datetime
    from okta import UsersClient
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# creating a file handler
handler = logging.FileHandler('hcmToOktaCreateUser.log')
handler.setLevel(logging.INFO)

# creating a logging format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

# adding the handlers to the oktaLogger
logger.addHandler(handler)



#===============================================================================
# # HCM feed reading and writing to a XML file
# headers = {
#     'content-type': "application/json",
#     'authorization': "Basic " + OktaApiTokenDecrypt.apiKeyHcmDecoded
#     }
# response = requests.request("GET", readFromPropertiesFile.hcmUrl, headers=headers, params=readFromPropertiesFile.hcmQuerystring)
# f = open(readFromPropertiesFile.hcmXml, 'w+')
# f.write(response.text)
# f.close()
#===============================================================================
usersClient = UsersClient(readFromPropertiesFile.oktaUrl, OktaApiTokenDecrypt.apiKeyOktaDecoded)

# HCM feed parsing and creating user in Okta
logger.info("HCM feed parsing and creating user in Okta :")
logger.info("\n")


hcmFeed = feedparser.parse(readFromPropertiesFile.hcmXml)
hcmFeed.feed.title
headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }
try:
    for post in hcmFeed['items']:
        text = post.content[0]['value'].encode('utf-8')
        j_obj = json.loads(text)
        for item in j_obj['Context']:
            primaryPhoneNumber = '{}'.format(item['PrimaryPhoneNumber'])
            logger.info("primaryPhoneNumber : {}".format(primaryPhoneNumber))
        
            personId = '{}'.format(item['PersonId'])
            logger.info("PersonId : {}".format(personId))
        
            personName = '{}'.format(item['PersonName'])
            logger.info("PersonName : {}".format(personName))
            personName = personName.split(" ")
            firstName = None
            for i, valueOfGroup in enumerate(personName):
                if firstName is None:
                    firstName = personName[i]
                    logger.info("First Name : {}".format(firstName))
            if len(personName) > 2:
                lastName = personName[i]
                logger.info("Last Name : {}".format(lastName))
            elif len(personName) <= 2:
                lastName = personName[i]
                logger.info("Last Name : {}".format(lastName))
                effectiveStartDate = '{}'.format(item['EffectiveStartDate'])
                logger.info("EffectiveStartDate : {}".format(effectiveStartDate))
        
                effectiveDate = '{}'.format(item['EffectiveDate'])
                logger.info("EffectiveDate : {}".format(effectiveDate))
        
                workerType = '{}'.format(item['WorkerType'])
                logger.info("WorkerType : {}".format(workerType))
        
                periodType = '{}'.format(item['PeriodType'])
                logger.info("PeriodType : {}".format(periodType))
                
                personNumber = '{}'.format(item['PersonNumber'])
                logger.info("PersonNumber : {}".format(personNumber))
                    
            try:
                workEmail = '{}'.format(item['WorkEmail'])
                logger.info("WorkEmail : {}\n".format(workEmail))
            except KeyError:
                workEmail = None
                logger.info("WorkEmail : {}\n".format(workEmail))
    
        
        
        effectiveStartDate = datetime.datetime.strptime(effectiveStartDate, '%Y-%m-%d').date()
        currentDate = datetime.datetime.now().date()
        createInactiveUser = ((effectiveStartDate - currentDate).days)
        
        
        mlcUserName = firstName.lower() + "." + lastName.lower()
        userLogin = mlcUserName + "@mlclimited.com"
        querystring = {"filter":"profile.login eq \"" + userLogin + "\""}
        logger.info(querystring)
        responsequery = requests.request("GET", readFromPropertiesFile.userUrl, headers=headers, params=querystring)
        logger.info(responsequery.text)
        json_responsequery = json.loads(responsequery.text)
    
        for itemSeacrhUserQuery in json_responsequery:
            seacrhUserQuery = itemSeacrhUserQuery['id']
            userQueryList = []
            userQueryList = seacrhUserQuery
            logger.info("Searched User ID from Query : {}".format(userQueryList))
        
            users = usersClient.get_user(userQueryList)
            userLogin = users.profile.login
            currentDate = datetime.datetime.now()
            logger.info("User Name : {}".format(mlcUserName))
            logger.info("User Login : {}".format(userLogin))
            newMlcUserName = re.findall('\d+', mlcUserName)
            if userLogin == users.profile.login and not newMlcUserName:
                mlcUserName += "1"
                logger.info("If Clause : " + mlcUserName)
            else:
                mlcUserName = re.sub('\d(?!\d)', lambda x: str(int(x.group(0)) + 1), mlcUserName)
                logger.info("Else Clause : " + mlcUserName)
    
        userLogin = mlcUserName + "@mlclimited.com"       
        pattern = re.compile(r'\@,')
        
        querystringTrue = {"activate":"true"}
        querystringFalse = {"activate":"false"}
        
        payload1 = "{\n  \"profile\": {\n    \"firstName\""
        payload2 = ": \"{}\",\n    \"lastName\"".format(firstName)
        payload3 = ": \"{}\",\n    \"email\"".format(lastName)
        if workEmail is None:
            payload4 = ": \"{}\",\n    \"login\"".format(userLogin)
        elif workEmail is not None:
            if '@' in workEmail:
                payload4 = ": \"{}\",\n    \"login\"".format(userLogin)
            else:
                payload4 = ": \"{}\",\n    \"login\"".format(userLogin)
        payload5 = ": \"{}""\"".format(userLogin)
        payload6 = ",\n    \"displayName\" : \"" + firstName + " " + lastName + "\""
        payload7 = ",\n    \"primaryPhone\":\"{}\"".format(primaryPhoneNumber)
        payload8 = ",\n    \"employeeNumber\":\"{}\"".format(personId)
        payload9 = ",\n    \"startDate\":\"{}\"\n  """.format(effectiveStartDate)
        payload10 = "}\n}"
        payload = payload1 + payload2 + payload3 + payload4 + payload5 + payload6 + payload7 + payload8 + payload9 + payload10
        logger.info(payload)
        if createInactiveUser >= 1:
            responseUser = requests.request("POST", readFromPropertiesFile.userUrl, data=payload, headers=headers, params=querystringFalse)
            logger.info(responseUser.text)
            responseUser = "[" + responseUser.text + "]"
            json_responseUser = json.loads(responseUser) 
            for itemSeacrhUser in json_responseUser:
                seacrhUser = itemSeacrhUser['id']
                userList = []
                userList = seacrhUser
       
                logger.info("Searched User ID : {}".format(userList))
                url = readFromPropertiesFile.userUrl + "/" + userList
                logger.info(url)
                users = usersClient.get_user(userList)
                userId = users.id
                status = users.status
                payload1 = "{\n  \"profile\": {\n    \"userStatus\""
                payload2 = ": \"{}\",\n    \"".format(status)
                payload3 = "mlcUserId\":\"{}\"\n  ".format(userId)
                payload4 = "}\n}"
               
                payload = payload1 + payload2 + payload3 + payload4
                logger.info(payload)
                response = requests.request("POST", url, data=payload, headers=headers)
                logger.info(response.text)
                logger.info("User " + firstName + " " + lastName + " created")
                logger.info("\n")
        else:
            responseUser = requests.request("POST", readFromPropertiesFile.userUrl, data=payload, headers=headers, params=querystringTrue)
            logger.info(responseUser.text)
            responseUser = "[" + responseUser.text + "]"
            json_responseUser = json.loads(responseUser) 
            for itemSeacrhUser in json_responseUser:
                seacrhUser = itemSeacrhUser['id']
                userList = []
                userList = seacrhUser
       
                logger.info("Searched User ID : {}".format(userList))
                url = readFromPropertiesFile.userUrl + "/" + userList
                logger.info(url)
                users = usersClient.get_user(userList)
                userId = users.id
                status = users.status
                payload1 = "{\n  \"profile\": {\n    \"userStatus\""
                payload2 = ": \"{}\",\n    \"".format(status)
                payload3 = "mlcUserId\":\"{}\"\n  ".format(userId)
                payload4 = "}\n}"
               
                payload = payload1 + payload2 + payload3 + payload4
                logger.info(payload)
                response = requests.request("POST", url, data=payload, headers=headers)
                logger.info(response.text)
                logger.info("User " + firstName + " " + lastName + " created")
                logger.info("\n")
except Exception as e:
    logging.error(traceback.format_exc())
    fromaddr = readFromPropertiesFile.notifyFromaddr
    toaddr = readFromPropertiesFile.notifyToaddr
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "***Alert*** Notification for User Okta Account Creation/Udation error"
    body = "<body><div><p><span>Hi Admin" + "," + "<p></p></span></p>" + "<p><span> This is to inform that there is an error while creating/updating Okta account of user. <p>Error details: " + traceback.format_exc() + "<p><span>If you experience difficulties accessing your account, you can send a help request to your Okta system administrator.<p></p></span></p><p><span>This is an automatically generated message by Okta. Replies are not monitored or answered.<p></p></span></p><p><span><p>&nbsp;</p></span></p><p><b><span>Regards,<p></p></span></b></p><p><b><span>Okta Admin Team.<p></p></span></b></p><p><p>&nbsp;</p></p></div></body>"
    msg.attach(MIMEText(body, 'HTML'))
            
    try:
        smtpObj = smtplib.SMTP(readFromPropertiesFile.notifyIP, readFromPropertiesFile.notifyPort)
        text = msg.as_string()
        smtpObj.sendmail(fromaddr, toaddr, text)
        smtpObj.quit()
        logger.info ("Email was sent to user manager: {}\n".format(toaddr))
        
    except SMTPException as error:
        logging.error ("Error: unable to send email :  {err}".format(err=error))
    
