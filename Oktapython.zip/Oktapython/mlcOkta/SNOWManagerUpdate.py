try:
    import sys
    import csv
    import re
    import oktaFunctions
    import oktaLogger
    import traceback
    from collections import Counter
    import string
    import json
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName="mlclimited-sit.oktapreview"
fileName = 'C:/Users/s.anand.raichur/Desktop/Python/oktasdk-python-master/manager.csv'
domain = "@ad.mlclife.com.au"
   
    
print("\n")
print('Start reading group CSV file')
print("\n")
try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            
            #============ User Check =================#
            print("User number : %s in CSV File.", count)
            count=count+1 
            print("#============ User Check =================#")
            empName = row['Employee User name From ServiceNow']
            empLogin = empName.split(" ")
            #Checking special character in User Firstname
            if re.match("^[a-zA-Z0-9_]*$", empLogin[0]):
                empFN = empLogin[0]
            else:
                empFN = empLogin[0].replace("'", "")
            print('Employee Firstname: %s', empFN)
            
            #Checking special character in User Lastname
            if re.match("^[a-zA-Z0-9_]*$", empLogin[-1]):
                empLN = empLogin[-1]
            else:
                empLN = empLogin[-1].replace("'", "")
            print('Employee Lastname: %s', empLN)
            empLogin=empFN+"."+empLN+domain
            
            
            #============ Username count =================#
            valid_letters = string.ascii_letters
            userNameCounter = Counter(empFN+"."+empLN)  # this counts all the letters, including invalid ones
            userNameCount = sum(userNameCounter[letter] for letter in valid_letters) + 1  # add up valid letters
            print("For user : "+str(empFN.title())+"."+(empLN.title()) +", Username Count is : "+str(userNameCount))
            
            #============ User Search in Okta =================#
            if (userNameCount <= 20):
                listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \"{}\")".format(empLogin)
                userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
                print("User List : {}".format(userList))
                
                #User not found in OKta
                if not userList:
                    print('Employee Login: %s not present in Okta', empLogin)
                    print('Trying to search in Okta again with another User Login approach')
                    empLogin = (empFN.title())+"."+(empLN.title())+domain
                    listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \"{}\")".format(empLogin)
                    userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
                    print("New User List : {}".format(userList))
                    if not userList:
                        print('Employee Login: %s still not present in Okta', empLogin)
                        print('Please check the user : '+str(empFN)+" "+str(empLN)+', manually in Okta')
                        print('Skipping User Manager Check')
                        print("\n")
                        continue
                else:
                    print('Employee Login: %s present in Okta', empLogin)
            
            elif (userNameCount >= 20):
                print("Username count is more than 20, skipping User Manager Check ")
                print("Please check AD provisioning for user : "+str(empFN.title())+"."+(empLN.title())+" in Okta Dashboard : "+str("https://"+orgName+".com/admin/tasks"))
                print("\n")
                continue
            print("\n")
            
              
            #============ User Manager Check =================#
            print("#============ User Manager Check =================#")
            managerName = row['Manager Name']
            print('Manager Display Name: %s', managerName)
            managerLogin = managerName.split(" ")

            #Checking special character in Manager Firstname
            if re.match("^[a-zA-Z0-9_]*$", managerLogin[0]):
                mngrFN = managerLogin[0]
            else:
                mngrFN = managerLogin[0].replace("'", "")
            print('Manager Firstname: %s', mngrFN)
            
            #Checking special character in Manager Lastname
            if re.match("^[a-zA-Z0-9_]*$", managerLogin[-1]):
                mngrLN = managerLogin[-1]
            else:
                mngrLN = managerLogin[-1].replace("'", "")
            print('Manager Lastname: %s', mngrLN)
            
            managerLogin=mngrFN+"."+mngrLN+domain
            listMngrUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \"{}\")".format(managerLogin)
            mngrList = oktaFunctions.GetPaginatedResponse(listMngrUrl)
            print("Manager List : {}".format(mngrList))
            if not mngrList:
                managerLogin = (mngrFN.title())+"."+(mngrLN.title())+domain
            print('Manager Login: %s present in Okta', managerLogin)
            print("\n")
            
            
            #============ User Manager Update =================#
            print("#============ User Manager Update =================#")
            for user in userList:
                userId = user["id"]
                profile = user['profile']
                userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
                user_info = {}
                user_info['profile'] = {}
                user_info['profile']['manager'] = managerLogin
                user_info_json = json.dumps(user_info)
    #===========================================================================
    #             response = oktaFunctions.POSTRequest(userUrl, user_info_json)
    #             if response != "Error":
    #                 print ("Attribute Manager Set to " + str(managerLogin) + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
    #         print("\n")
    # print("\n")
    # print("Updated manager names for users present in CSV.")
    #===========================================================================
    
except Exception as e:
    print(traceback.format_exc())
