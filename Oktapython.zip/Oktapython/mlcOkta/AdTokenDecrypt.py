try:
    import configparser
    import base64
    import sys
    import traceback
    import logging
    import errno
    import os
    from datetime import datetime
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "C:/python_logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends

# Encrypting to API Token to Bytes
logger.info("Reading AD Encrypted Token properties File :")
logger.info("Starting AD Key Decryption ::::")


config = configparser.ConfigParser()
config.sections()
config.read('adKey.properties')
config.sections()


try:
    for key in config['column']: 
        column = config['column']
        adKey = (column['adKey'])
    
    # Decrypting the encryptyed API Token
    logger.info("Decrypting the encryptyed AD Key to Bytes")
    adKeyData = adKey
    adKeyData = adKey.encode()
    adKeyDecoded = (adKeyData).decode('utf-8')
    adKeyDecoded = base64.b64decode(adKeyDecoded)
    adKeyDecoded = str(adKeyDecoded, 'utf-8')
    # oktaLogger.info("Decoded Okta API Key : {}".format(apiKeyOktaDecoded))
    logger.info("AD Key Decryption Finished.")
except Exception as e:
    logging.error(traceback.format_exc())
