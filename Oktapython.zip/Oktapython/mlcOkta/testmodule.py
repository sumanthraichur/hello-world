try:
    import sys
    import readFromPropertiesFile
    import oktaLogger
    import traceback
    import os
    import oktaFunctions
    import csv
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

orgName = "mlclimited-sit.oktapreview"
#fileName = "C:/Users/debmalya.biswas/Desktop/users.csv"


def Enquiry(lis1):
    if len(lis1) == 0:
        return 0
    else:
        return 1

try:
    header = ("groupName,ID")
    filename = 'C:/Users/debmalya.biswas/Desktop/GroupsPROD.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
    
    #===========================================================================
    # count=1
    # with open(fileName, 'r') as file:
    #     reader = csv.DictReader(file, delimiter=',')
    #     for row in reader:
    #         #============ User Check =================#
    #         print("User number : %s in CSV File.", count)
    #         count=count+1
    #         
    #         userLogin = row['login']
    #         print("userLogin ::"+str(userLogin))
    #         
    #         print("#============ User Check =================#")   
    #===========================================================================
    listUserUrl = "https://" + orgName + ".com/api/v1/groups"
    userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
    count=1
    for user in userList:
        userId = user["id"]
        profile = user['profile']
        login = profile['login']
        print("User Count :: "+str(count))
        print("User Id :: "+str(userId))
        print("User login :: "+str(login))
        count=count+1
        getGroupsForUserUrl = "https://" + orgName + ".com/api/v1/users/"+str(userId)+"/groups"
        userGroupList = oktaFunctions.GETObject(getGroupsForUserUrl)
        grpList=[]
        for userGroup in userGroupList:
            profile = userGroup['profile']
            name = profile['name']
            grpList.append(name)
            #===================================================================
            # listGroupUrl = "https://" + orgName + ".com/api/v1/groups?q="+str(name)
            # listGroupList = oktaFunctions.GETObject(listGroupUrl)
            # for listGroup in listGroupList:
            #     groupId = listGroup['id']
            #     listAssignedAppsUrl = "https://" + orgreName + ".com/api/v1/groups/"+str(groupId)+"/apps"
            #     listAssignedAppsList = oktaFunctions.GETObject(listAssignedAppsUrl)
            #     if Enquiry(listAssignedAppsList):
            #         for listAssignedApps in listAssignedAppsList:
            #             label = listAssignedApps['label']
            #     else:
            #         label = "None"
            #     print(label)
            #     print("\n")    
            #===================================================================
        grpName = ', '.join(grpList)
        grpName = str("\"")+grpName+str("\"")
        print("Group Name :: "+str(grpName))
        print("\n")
        addingValues = '{},{}'.format(login,grpName)
        # Amending with user values to the csv
        with open(filename, "a") as file:
            file.write(addingValues)
            file.write('\n')
        file.close()      


except Exception as e:
    print(traceback.format_exc())
