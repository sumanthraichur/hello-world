import configparser
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

config = configparser.ConfigParser()
config.sections()
config.read('config.properties')
config.sections()

#===============================================================================
# # print("Columns Names:")
# logger.info("Columns Names:")
#===============================================================================

for key in config['column']: 
    # print(key)
    # logger.info(key)
    column = config['column']
    jobFamily = (column['jobFamily'])
    jobFunction = (column['jobFunction'])
    jobRole = (column['jobRole'])
    grpUrl = (column['grpUrl'])
    ruleUrl = (column['ruleUrl'])
    fileName = (column['fileName'])
    cascadeGroupName = (column['cascadeGroupName'])
    filterUserLogin = (column['filterUserLogin'])
    userUrl = (column['userUrl'])
    userLogin = (column['userLogin'])
    appUrl = (column['appUrl'])
    oktaUrl = (column['oktaUrl'])
    notifyIP = (column['notifyIP'])
    notifyPort = (column['notifyPort'])
    notifyFromaddr = (column['notifyFromaddr'])
    notifyToaddr = (column['notifyToaddr'])
    mlcOktaUrl = (column['mlcOktaUrl'])
    mlcUserUrl = (column['mlcUserUrl'])
    orgName = (column['orgName'])
    attributeNameStatus = (column['attributeNameStatus'])
    attributeNameID = (column['attributeNameID'])
    attributeManager = (column['attributeManager'])
    attributeManagerID = (column['attributeManagerID'])
    attributePersonID = (column['attributePersonID'])
    attributeNameContractEndDate = (column['attributeNameContractEndDate'])
    attributeInitialLogin = (column['attributeInitialLogin'])
    sendUserPassword = (column['sendUserPassword'])
    search_base = (column['search_base'])
    hostName = (column['hostName'])
    username = (column['username'])
    search_filter = (column['search_filter'])
#===============================================================================
# 
# # print("\n")
# logger.info("\n")
# 
# # print("csvFile Attribute Name:")
# logger.info("csvFile Attribute Name:")
#===============================================================================

for key in config['csvFile']: 
    # print(key)
    # logger.info(key)
    csvFile = config['csvFile']
    groupName = (csvFile['groupName'])
    groupDescription = (csvFile['groupDescription'])
    groupType = (csvFile['groupType'])
    membershipRuleType = (csvFile['membershipRuleType'])
    cascadingGroupName = (csvFile['cascadingGroupName'])
    attributeRule = (csvFile['attributeRule'])
    manualMembershipAssignment = (csvFile['manualMembershipAssignment'])
    groupApplicationAssignment = (csvFile['groupApplicationAssignment'])
