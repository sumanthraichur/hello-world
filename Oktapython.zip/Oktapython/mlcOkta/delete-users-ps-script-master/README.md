Disclaimer: an Okta user deletion is a permanent process that cannot be reversed. Use these scripts at your own risk. All scripts are provided AS IS without warranty of any kind. Okta disclaims all implied warranties including, without limitation, any implied warranties of fitness for a particular purpose. We highly recommend testing scripts in a preview environment if possible.

For instructions on how to use this script, please visit https://support.okta.com/help/Documentation/Knowledge_Article/How-to-Perform-a-Bulk-Delete-of-Okta-Users-With-API


Download the GitHub Repository(https://github.com/OktaSupport/delete-users-ps-script) and extract the files to a folder of your choice (we recommend a short path such as C:\OktaScripts to simplify typing it in Powershell)
Add the full Okta usernames of the users you want to delete in the column named "login" inside users-list.csv.  This column can contain either Active or Deactivated/Deprovisioned users.
Open PowerShell and change the directory to the path where the above files were saved

Run this command: .\delete.ps1 –orgurl "YourOktaTenantURL" -apikey "YourApiToken" -filepath "user-list.csv"
Replace YourOktaTenantURL with your entire Okta URL, and YourApiToken with the API Token you've generated.
user-list.csv can be replaced by the CSV file of your choice.  The script requires that the CSV file has a "login" column that contains the username of each user that is to be deleted.  Additional columns can exist in the CSV file and will be ignored by the script.