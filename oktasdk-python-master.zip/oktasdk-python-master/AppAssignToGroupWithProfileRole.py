try:
    import sys
    import csv
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName = "mlcinsurance.okta"
orgNameAdmin = "mlcinsurance-admin.okta"
fileName = 'C:/Users/debmalya.biswas/Desktop/CV Prov Integration/CVGroupCreationWithProRole.csv'
grpUrl = "https://"+orgName+".com/api/v1/groups"



logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
logger.info('Start reading group CSV file')
logger.info("\n")    


try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            logger.info("Group number : %s in CSV File.", count)
            count=count+1 
            logger.info("#============ Group Name Check =================#")
            grpName = row['Group Name']
            logger.info("Group Name ::"+str(grpName))
            
            grpDesc = row['Group Description']
            logger.info("Group description ::"+str(grpDesc))
                        
            application = row['Application Name']
            logger.info("Application Name ::"+str(application))
            
            profile = row['Profile']
            logger.info("Application profile ::"+str(profile))
            
            role = row['Role']
            logger.info("Application Role ::"+str(role))
            
            groupPayLoad = oktaPayLoad.oktaGroupPayLoad(grpName, grpDesc)
            #Create group in Okta
            groupResponse = oktaFunctions.POSTRequest(grpUrl, groupPayLoad)
            if groupResponse != "Error":
                logger.info ("Group "+str(grpName)+" is created in Okta")
                logger.info ("\n")
                             
            querystring = {"q":""+str(grpName)+""}
            groupResponse = oktaFunctions.GETGroupRequest(grpUrl, querystring)
            for group in groupResponse:
                groupId = group["id"]
                appUrl = "https://" + orgName + ".com/api/v1/apps?q="+str(application)
                logger.info("appUrl :: "+str(appUrl))
                appList = oktaFunctions.GETObject(appUrl)
                for app in appList:
                    appId = app['id']
                    assignGroupToAppUrl = "https://"+orgNameAdmin+".com/api/v1/apps/"+str(appId)+"/groups/"+str(groupId)
                    logger.info("Assign Group To App Url :: "+str(assignGroupToAppUrl))
                    appPayload = oktaPayLoad.appTOGroupWithProfileRole(groupId, profile, role)
                    response = oktaFunctions.PUTmappingRequest(assignGroupToAppUrl, appPayload)
                    if response != "Error":
                        logger.info ("Application " + str(application) + " assigned to Group " + str(grpName)+ "With Profile "+str(profile)+" and Role "+str(role))
                        logger.info("\n")
except Exception as e:
    logger.info(traceback.format_exc())