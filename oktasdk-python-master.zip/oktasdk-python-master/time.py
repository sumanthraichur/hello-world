from datetime import datetime
from dateutil import tz
    
from_zone = tz.gettz('UTC')
to_zone = tz.gettz('Australia/Sydney')


def zuluToHumanTime(time):
    from_zone = tz.tzutc()
    to_zone = tz.tzlocal()
    string = time
    string = string.replace(".000Z", "")
    string = string[:4] + '-' + string[4:]
    string = string[:7] + '-' + string[7:]
    string = string[:10] + ' ' + string[10:]
    string = string[:13] + ':' + string[13:]
    string = string[:16] + ':' + string[16:]
    utc = datetime.strptime(string, '%Y-%m-%d %H:%M:%S')
    utc = utc.replace(tzinfo=from_zone)
    aest = str(utc.astimezone(to_zone))
    aest = aest.replace("+10:00", "")
    return aest

def remafterellipsis(text):
    where_ellipsis = text.find('+')
    if where_ellipsis == -1:
        return text
    return text[:where_ellipsis]

 
ts = datetime.fromtimestamp((131836896000000000 - 116444736000000000) // 10000000)
ts = str(ts)
ts=datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
aest = str(ts.astimezone(to_zone))
aest = remafterellipsis(aest)
aest = aest + str(" AEDT")
print(aest)




