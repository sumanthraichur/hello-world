try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    import ssl
    from datetime import datetime
    import OktaApiTokenDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "C:/python_logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends

orgName = readFromPropertiesFile.orgName

getObjectheaders = {
    'authorization': "Basic YTRmYWRmOTlkMTkzNDM5NDg5MmM0M2I5N2VmZTFiZmQ6RjQ5ODhCMTVlNjY4NDI4OGIzZjM3Njg4NjIwNmI5REM=",
    }

getOktaheaders = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00MicNpvJD6Ekwxuc1_J6-KDvlfdjt-gb_EFX8lY21",
    # + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }

getHCMheaders = {
    'content-type': "application/vnd.oracle.adf.resourceitem+json",
    'authorization': "Basic VEVTVF9BUEk6UGVvcGxlQ291bnRAMTIz",
    }

def GetESBObject(url): 
    response = requests.request("GET", url, headers=getObjectheaders, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.text
    
def GetOktaObject(url): 
    response = requests.request("GET", url, headers=getOktaheaders, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.text

def GetHCMObject(url): 
    response = requests.request("GET", url, headers=getHCMheaders, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.text

try:
    
    header = ("familyName,givenName,personNumber,userName,managerId,StartDate,EndDate")
    filename = 'C:/Users/debmalya.biswas/Desktop/hcmProd.csv'
    if os.path.exists(filename):
        print("File exists")
    elif not os.path.exists(filename):
        print("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
        
    
    _create_unverified_https_context = ssl._create_unverified_context
    # Reading users from ESB
    ESBurl = "https://api.mlcinsurance.com.au/v1/security/Users?startIndex=1&count=1"
    response = GetESBObject(ESBurl)
    json_response = json.loads(response)
    totalResults = json_response['totalResults']
    #totalResults = totalResults + 199
    totalResults = 1
    print("totalResults: {}".format(totalResults))
    
    for x in range (1, totalResults, 20):
        url = "https://api.mlcinsurance.com.au/v1/security/Users?"
        url = url + "startIndex=" + str(x) + "&count=20"
        print("url : " + url)
        response = GetESBObject(url)
        json_response = json.loads(response)
        dict = {}  # @ReservedAssignment
        for entry in json_response['Resources']:
            hcm = entry['urn:okta:mlclimitedprod_oraclehcm_2:1.0:user:custom']
            userName = entry['userName']
            if ('personID' in hcm):
                dict[hcm['personID']] = userName
        
        count = 1
        print('Reading User from ESB')
        for entry in json_response['Resources']:
            schemas = entry['schemas']
            hcm = entry['urn:okta:mlclimitedprod_oraclehcm_2:1.0:user:custom']
            if 'personNumber' in hcm:
                personNumber = hcm['personNumber']
                print('personNumber : ' + personNumber)
                
                hcmUrl = "https://efly.hcm.ap4.oraclecloud.com:443/hcmCoreApi/resources/11.12.1.0/emps?q=PersonNumber=22990223"
                #+personNumber
                print('hcmUrl : ' + hcmUrl)
                print('\n')
                response = GetHCMObject(hcmUrl)
                hcmUser = json.loads(response)
                for user in hcmUser['items']:
                    firstName = user['FirstName']
                    lastName = user['LastName']
                    userName = user['UserName']
                    links = user['links']
                    linksList = []
                    linksList = links
                    for item in linksList:
                        rel = item['rel']
                        name = item['name']
                        if (rel == 'child') and (name == 'assignments'):
                            hrefUrl = item['href']
                            print("hrefUrl : " + hrefUrl)
                            print("name ::"+name)
                            response = GetHCMObject(hrefUrl)
                            hcmUrlUser = json.loads(response)
                            for hcmUser in hcmUrlUser['items']:
                                if ('ManagerId' in hcmUser):
                                    managerId = hcmUser['ManagerId']
                                    managerId = '{}'.format(managerId)
                                    print("managerId : "+managerId)
                                
                                if ('EffectiveStartDate' in hcmUser):
                                    startDate = hcmUser['EffectiveStartDate']
                                    print("startDate : "+startDate)
                    
                                if ('ActualTerminationDate' in hcmUser):
                                    endDate = hcmUser['ActualTerminationDate']   
                                    print("endDate : "+endDate)
                                    print("\n")
                        
                                    addingValues = '{},{},{},{},{},{},{}'.format(lastName, firstName, personNumber, userName, managerId,startDate,endDate)
                                    print('count : {}'.format(count))
                                    count = count+1
                                    # Amending with user values to the csv
                                    with open(filename, "a") as file:
                                        file.write(addingValues)
                                        file.write('\n')
                                    file.close()

except Exception as e:
    print(traceback.format_exc())
    pass