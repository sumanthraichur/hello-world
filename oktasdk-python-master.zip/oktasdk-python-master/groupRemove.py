try:
    import sys
    import csv
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    import json
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
fileName = 'C:/Users/debmalya.biswas/Desktop/groupRemove.csv'
orgName="mlclimited-sit.oktapreview"

try:
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        count=1
        for row in reader:
            
            print("User number : "+str(count)+" in CSV File.")
            count=count+1             
            
            userlogin = row['login']
            print('login: '+str(userlogin))
            
            grpName = row['Group Name']
            print('Group Name: '+str(grpName))
                       
            #===== User =========#
            listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(userlogin)+"\")"
            print("listUserUrl :: "+(listUserUrl))
            userList = oktaFunctions.GETObject(listUserUrl)
            for user in userList:
                userId = user["id"]
                print("User ID :: "+str(userId))
            
            #===== Group =========#
            listGroupUrl="https://" + orgName + ".com/api/v1/groups?q="+str(grpName)
            print("listGroupUrl :: "+str(listGroupUrl))
            groupList = oktaFunctions.GETObject(listGroupUrl)
            for group in groupList:
                groupId = group["id"]
                print("Group ID :: "+str(groupId))
                
            #===== Group Unassignment =========#    
            groupRemoveUrl ="https://"+orgName+".com/api/v1/groups/"+str(groupId)+"/users/"+str(userId)
            print("Group Remove Url :: "+str(groupRemoveUrl))
            response = oktaFunctions.DELETEuser(groupRemoveUrl)
            if response != "Error":
                print("User :: "+str(userlogin)+" removed from :: "+str(grpName)+" group in Okta")
                print('\n')

except Exception as e:
    logger.info(traceback.format_exc()) 