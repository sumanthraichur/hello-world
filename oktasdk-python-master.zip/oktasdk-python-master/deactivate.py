import okta
from okta import UsersClient

usersClient = UsersClient("https://dev-530347.oktapreview.com", "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq")

usersClient.deactivate_user("stuart.broad@oktatrial.com")
print("User Deactivated")
