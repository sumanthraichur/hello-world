try:
    import sys
    import csv
    import re
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    from collections import Counter
    import string
    import json
    import errno
    import os
    from datetime import datetime
    import OktaApiTokenDecrypt
    import oktaFunctions
    import oktaLogger
    import oktaPayLoad
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

    
orgName = "mlclimited.oktapreview"
fileName = 'C:/Users/debmalya.biswas/Desktop/PowerBIGroups.csv'
grpUrl = "https://"+orgName+".com/api/v1/groups"


logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
logger.info('Start reading group CSV file')
logger.info("\n")    
    
try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            logger.info("Group number : %s in CSV File.", count)
            count=count+1 
            logger.info("#============ Group Name Check =================#")
            grpName = row['Group Name']
            logger.info("Group Name ::"+str(grpName))
            
            grpDesc = row['Group Description']
            logger.info("Group description ::"+str(grpDesc))
            
            groupPayLoad = oktaPayLoad.oktaGroupPayLoad(grpName, grpDesc)
            logger.info("groupPayLoad ::"+str(groupPayLoad))
            #Create group in Okta
            groupResponse = oktaFunctions.POSTRequest(grpUrl, groupPayLoad)
            logger.info("groupResponse ::"+str(groupResponse))
            if groupResponse != "Error":
                logger.info ("Group "+str(grpName)+" is created in Okta")
                logger.info ("\n")
                
except Exception as e:
    logger.info(traceback.format_exc())