try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    import OktaApiTokenDecrypt
    import smtplib
    from smtplib import SMTPException
    from email.header import Header
    from email.utils import formataddr
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from email.mime.image import MIMEImage
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = readFromPropertiesFile.orgName
attributeInitialLogin = readFromPropertiesFile.attributeInitialLogin

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }


def GetObject(url):
    response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()
    
def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

def POSTRequestPassword(url, querystring):
    if querystring != "":
        response = requests.post(url, headers=headers, params=querystring)
        response = "[" + response.text + "]"
        json_response = json.loads(response)
        for item in json_response:
            seacrhPassword = item['tempPassword']
            passwordList = []
            passwordList = seacrhPassword
        return passwordList
  
try:
    userSchemaUrl = "https://" + orgName + ".com/api/v1/meta/schemas/user/default"
    userSchema = GetObject(userSchemaUrl)
    baseAttributesList = userSchema["definitions"]["base"]["properties"]
    customAttributesList = userSchema["definitions"]["custom"]["properties"]
    if ((attributeInitialLogin in baseAttributesList) or (attributeInitialLogin in customAttributesList)):
        listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \"Catherine.Humphreys@ad.mlclife.com.au\")"
        # querystring = "{" + "filter" + ":" + "status eq \"ACTIVE\" or status eq \"PROVISIONED\"" + "}"
        response = requests.get(listUserUrl, headers=headers)
        userList = []
        responseJSON = json.dumps(response.json())
        responseList = json.loads(responseJSON)
        userList = userList + responseList
        # Writing to a CSV File
        header = ("firstName,lastName,login,initialLogin")
        filename = readFromPropertiesFile.sendUserPassword
        if os.path.exists(filename):
            logger.info("File exists")
        elif not os.path.exists(filename):
            logger.info("File does not exists, creating new file")
            file = open(filename, 'w+')
            file.write(header)
            file.write('\n')
        
        
        activationHeadFilename = "emailTemplate/ActivationHead.html"
        activationHeadhtmlFile = open(activationHeadFilename, 'r', encoding='utf-8')
        activationHeadhtmlFilesource_code = activationHeadhtmlFile.read()
        
        activationP1Filename = "emailTemplate/ActivationP1.html"
        activationP1htmlFile = open(activationP1Filename, 'r', encoding='utf-8')
        activationP1htmlFilesource_code = activationP1htmlFile.read()
        
        activationP2Filename = "emailTemplate/ActivationP2.html"
        activationP2htmlFile = open(activationP2Filename, 'r', encoding='utf-8')
        activationP2htmlFilesource_code = activationP2htmlFile.read()
        
        activationFinalFilename = "emailTemplate/ActivationFinal.html"
        activationFinalhtmlFile = open(activationFinalFilename, 'r', encoding='utf-8')
        activationFinalhtmlFilesource_code = activationFinalhtmlFile.read()
            
        HeadFilename = "emailTemplate/Head.html"
        HeadhtmlFile = open(HeadFilename, 'r', encoding='utf-8')
        Headsource_code = HeadhtmlFile.read()
    
        P1Filename = "emailTemplate/P1.html"
        P1htmlFile = open(P1Filename, 'r', encoding='utf-8')
        P1source_code = P1htmlFile.read() 
    
        P2Filename = "emailTemplate/P2.html"
        P2htmlFile = open(P2Filename, 'r', encoding='utf-8')
        P2source_code = P2htmlFile.read()
    
        Finalfilename = "emailTemplate/Final.html"
        FinalHtmlFile = open(Finalfilename, 'r', encoding='utf-8')
        FinalSource_code = FinalHtmlFile.read()
        
        attachment = 'logo.png'
        count = 0
        for user in userList:
            userId = user['id']
            profile = user['profile']
            userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
            user_info = {}
            user_info['profile'] = {}
            # User coming from Oracle HCM where mlcUserStatus is always set to 'Active'
            if (("initialLogin" in profile) and ("isHCMUser" in profile)):
                initialLogin = profile["initialLogin"]
                isHCMUser = profile["isHCMUser"]
                
                if ((initialLogin == False) and (isHCMUser == True)):
                        logger.info(str(profile["firstName"]) + " " + str(profile["lastName"]) + " :::: " + str(initialLogin) + " :::: " + str(isHCMUser))
                        logger.info("Attribute " + attributeInitialLogin + " is 'FALSE' for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                        expirePasswordUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId) + "/lifecycle/expire_password"
                        query = {"tempPassword":"true"}
                        response = POSTRequestPassword(expirePasswordUrl, query)
                        fromaddr = readFromPropertiesFile.notifyFromaddr
                        toaddr = str(profile["email"])
                        userLogin = str(profile["login"]).rsplit('@', 1)[0]
                         
                        # #<-------------------- Activation Email ------------------------------>##
                        msg = MIMEMultipart()
                        msg['From'] = formataddr((str(Header('MLC Tech Support', 'utf-8')), fromaddr))
                        msg['To'] = toaddr
                        msg['Subject'] = "Your new MLC Life Insurance Logon Credentials"
                         
                        activationBody = activationHeadhtmlFilesource_code
                        activationBody = activationBody + '<img width="642" height="182" src="cid:image1"></span></span>'
                        activationBody = activationBody + activationP1htmlFilesource_code
                        activationBody = activationBody + 'Hello {}'.format(str(profile["firstName"]))
                        activationBody = activationBody + activationP2htmlFilesource_code
                        activationBody = activationBody + '{}'.format(userLogin)
                        activationBody = activationBody + activationFinalhtmlFilesource_code
         
                        msg.attach(MIMEText(activationBody, 'HTML'))
                        fp = open(attachment, 'rb')
                        img = MIMEImage(fp.read())
                        fp.close()
                        img.add_header('Content-ID', '<image1>')
                        msg.attach(img)
                         
                        try:
                            smtpObj = smtplib.SMTP('smtp.mlctech.io', 25)
                            smtpObj.starttls()
                            text = msg.as_string()
                            smtpObj.sendmail(fromaddr, toaddr, text)
                            smtpObj.quit()
                            logger.info ("User Activation Email was sent to user email: {}\n".format(profile["email"]))
         
                        except SMTPException as error:
                            logger.info ("Error: unable to send email :  {err}".format(err=error))
                         
                        # #<-------------------- Initial Password Email ------------------------------>##
                        msg = MIMEMultipart()
                        msg['From'] = formataddr((str(Header('MLC Tech Support', 'utf-8')), fromaddr))
                        msg['To'] = toaddr
                        msg['Subject'] = "Temporary password for MLC Life Insurance Logon Credentials"
                         
                         
                        body = Headsource_code
                        body = body + '<img width="642" height="182" src="cid:image1"></span></span>'
                        body = body + P1source_code
                        body = body + 'Hello {}'.format(str(profile["firstName"]))
                        body = body + P2source_code
                        body = body + 'Your temporary password is: {}'. format(response)
                        body = body + FinalSource_code
                       
                        msg.attach(MIMEText(body, 'HTML'))
                        fp = open(attachment, 'rb')
                        img = MIMEImage(fp.read())
                        fp.close()
                        img.add_header('Content-ID', '<image1>')
                        msg.attach(img)
                         
                        try:
                            smtpObj = smtplib.SMTP('smtp.mlctech.io', 25)
                            smtpObj.starttls()
                            text = msg.as_string()
                            smtpObj.sendmail(fromaddr, toaddr, text)
                            smtpObj.quit()
                            logger.info ("Initial Temporary Password Email was sent to user email: {}\n".format(profile["email"]))
                             
                            # Setting Initial Login attribute value to 'TRUE'
                            user_info['profile'] [attributeInitialLogin] = True
                            user_info_json = json.dumps(user_info)
                            response = POSTRequest(userUrl, user_info_json)
                            if response != "Error":
                                logger.info ("Attribute " + attributeInitialLogin + " Set to 'TRUE' for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                            logger.info ("\n")
         
                        except SMTPException as error:
                            logger.info ("Error: unable to send email :  {err}".format(err=error))
                             
                        addingValues = '{},{},{},{}'.format(str(profile["firstName"]), str(profile["lastName"]), str(profile["login"]), user_info['profile'] [attributeInitialLogin])
                        count += 1
                        print(count)
                        # Amending with user values to the csv
                        with open(readFromPropertiesFile.sendUserPassword, "a") as file:
                            file.write(addingValues)
                            file.write('\n')
                            file.close()
                        if (count == 100):
                            break
              
    else:
        logger.info ("Attribute " + attributeInitialLogin + " Not Found in User Schema. Please Create and Try Again.")

except Exception as e:
    logger.info(traceback.format_exc())
