from collections import Counter
import string
import oktaLogger
import os


word = "sit-l.papavasiliou"
print(len(word))
