import requests

url = "https://dev-530347.oktapreview.com/api/v1/groups/00gaj3yg4rrwxHE9z0h7/users/00uaiao9tbFXWH8UL0h7"


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq",
    'cache-control': "no-cache"
    }

response = requests.request("DELETE", url, headers=headers)
print ("User deleted from group")
print(response.text)

