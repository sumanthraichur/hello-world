try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    import ssl
    from datetime import datetime
    import OktaApiTokenDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "C:/python_logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends

orgName = readFromPropertiesFile.orgName

getObjectheaders = {
    'authorization': "Basic MTQwZDE3YmRkMzlhNDE4YmE3YmIzZGQ1OTU5MmUwMjQ6OTQ2NUQ2OTNmZjY1NDFGYjk1MDBkRmI3NGYxYTUyMzc=",
    }

getOktaheaders = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00PXsAceaSqXdvCUWKMJ_OzIkeDkLiukL3UPSJvUQ8"
    # + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }

getHCMheaders = {
    'content-type': "application/json",
    'authorization': "Basic TXVsZVNvZnRfQVBJOldlbGNvbWUxMg==",
    }

hcmPatchHeaders = {
    'content-type': "application/vnd.oracle.adf.resourceitem+json",
    'authorization': "Basic TUxDXzE4MDpXZWxjb21lNA==",
    }

def GetESBObject(url): 
    response = requests.request("GET", url, headers=getObjectheaders, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.text
    
def GetOktaObject(url): 
    response = requests.request("GET", url, headers=getOktaheaders, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.text

def GetHCMObject(url): 
    response = requests.request("GET", url, headers=getHCMheaders, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.text
    
def PATCHRequest(url, data):
    if data != "":
        response = requests.patch(url, data=data, headers=hcmPatchHeaders)
    else:
        response = requests.patch(url, headers=hcmPatchHeaders)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

try:
    
    header = ("firstName,lastName,personNumber,PersonId,userName,userPersonType,hcmUsername")
    filename = 'userPersonType.csv'
    if os.path.exists(filename):
        logger.info("File exists")
    elif not os.path.exists(filename):
        logger.info("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
    
    _create_unverified_https_context = ssl._create_unverified_context
    # Reading users from ESB
    ESBurl = "https://dev.api.mlcinsurance.com.au/v1/security/Users?startIndex=1&count=1"
    response = GetESBObject(ESBurl)
    json_response = json.loads(response)
    totalResults = json_response['totalResults']
    totalResults = totalResults + 199
    logger.info("totalResults: {}".format(totalResults))
    
    for x in range (1, totalResults, 200):
        url = "https://dev.api.mlcinsurance.com.au/v1/security/Users?"
        url = url + "startIndex=" + str(x) + "&count=200"
        logger.info("url : " + url)
        response = GetESBObject(url)
        json_response = json.loads(response)
        dict = {}  # @ReservedAssignment
        for entry in json_response['Resources']:
            hcm = entry['urn:okta:mlclimited_esbintegration_1:1.0:user:custom']
            userName = entry['userName']
            if ('personID' in hcm):
                dict[hcm['personID']] = userName
         
        logger.info('Reading User from ESB')
        for entry in json_response['Resources']:
            schemas = entry['schemas']
            hcm = entry['urn:okta:mlclimited_esbintegration_1:1.0:user:custom']
            userName = entry['userName']
            name = entry['name']
            logger.info('userName : ' + userName)
            if ('familyName' in name):
                familyName = name['familyName']
                logger.info('familyName : ' + familyName)
            if ('givenName' in name):
                givenName = name['givenName']
                logger.info('lastName : ' + givenName)
            if ('personID' in hcm):
                personID = hcm['personID']
                logger.info('personID : ' + personID)
            if 'personNumber' in hcm:
                personNumber = hcm['personNumber']
                logger.info('personNumber : ' + personNumber)
            if 'personID' in hcm:
                personID = hcm['personID']
                logger.info('personID : ' + personID)            
            if 'hcmUsername' in hcm:
                hcmUsername = hcm['hcmUsername']
                logger.info('hcmUsername : ' + hcmUsername)
            if 'displayName' in hcm:
                displayName = hcm['displayName']
                logger.info('displayName : ' + displayName)
            if 'userPersonType' in hcm:
                userPersonType = hcm['userPersonType']
                logger.info('userPersonType : ' + userPersonType)  
                logger.info('\n')
            addingValues = '{},{},{},{},{},{},{}'.format(familyName, givenName, personNumber, personID, userName, userPersonType, hcmUsername)
   
            # Amending with user values to the csv
            with open(filename, "a") as file:
                file.write(addingValues)
                file.write('\n')
            file.close()

        #=======================================================================
        # hcmUrl = "https://efly-dev1.hcm.ap4.oraclecloud.com:443/hcmCoreApi/resources/11.12.1.0/emps?q=PersonNumber=" + personNumber
        # logger.info('hcmUrl : ' + hcmUrl)
        # logger.info('\n')
        # response = GetHCMObject(hcmUrl)
        # hcmUser = json.loads(response)
        # for user in hcmUser['items']:
        #     links = user['links']
        #     linksList = []
        #     linksList = links
        #     for item in linksList:
        #         rel = item['rel']
        #         if (rel == 'self'):
        #             hrefUrl = item['href']
        #             logger.info("hrefUrl : " + hrefUrl)
        #                          
        #             payload = "{\r\n\t\"UserName\": """
        #             payload = payload + "\"{}\"".format(userName)
        #             payload = payload + "\r\n}"
        #             logger.info('Payload : \n' + payload)
        #                         
        #             #PATCH HCM username
        #             response = PATCHRequest(hrefUrl, payload)
        #             if response != "Error":
        #                 logger.info("Username :: " + userName + " updated in HCM ")
        #                 logger.info ("\n")
        #=======================================================================

except Exception as e:
    logger.info(traceback.format_exc())
    pass
