try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import re
    import errno
    import string
    import random
    import os
    import csv
    import ssl
    from datetime import datetime
    import OktaApiTokenDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "C:/python_logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends

with open('ESBUserList.csv', 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        personDetailsFromUATlist = []
        for row in reader:
            logger.info(" ")
            
            # Reading the CSV file attributes
            
            userName = row['userName']
            logger.info('userName: %s', userName)
            logger.info('\n')
            personDetailsFromUATlist.append(userName)
            print(personDetailsFromUATlist)

with open('ESBUserList1.csv', 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            logger.info(" ")
            
            # Reading the CSV file attributes
            
            firstName = row['firstName']
            logger.info('firstName: %s', firstName)
            
            lastName = row['lastName']
            logger.info('lastName: %s', lastName)            
            
            userNameString = firstName + '.' + lastName
            
            if userNameString in personDetailsFromUATlist:
                m = re.search(r'\d+$', userNameString)
                # if the string ends in digits m will be a Match object, or None otherwise.
                if m is not None:
                    number = int(m.group())
                    number += 1
                    userNameString = re.sub("\d+", "", userNameString)
                    userNameString = userNameString + str(number)
                    print ('User Name' + userNameString)
                else:
                    print(userNameString + ' exists')
                    userNameString = userNameString + str(1)
                    print(userNameString)