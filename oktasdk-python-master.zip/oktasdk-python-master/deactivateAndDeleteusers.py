try:
    import sys
    import csv
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName = "mlclimited-sit.oktapreview"
orgNameAdmin = "mlclimited-sit-admin.oktapreview"
fileName = 'C:/Users/debmalya.biswas/Desktop/deactivate.csv'

logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
logger.info('Start reading group CSV file')
logger.info("\n")    


try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            logger.info("Group number : %s in CSV File.", count)
            count=count+1 
            logger.info("#============ Group Name Check =================#")
            login = row['login']
            logger.info("User Login ::"+str(login))
            
            listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(login)+"\")"
            userList = oktaFunctions.GETObject(listUserUrl)
            for user in userList:
                userId = user["id"]
                profile = user['profile']
                login = profile['login']
                logger.info("User Login ::"+str(login))
                credentials = user["credentials"]
                provider = credentials["provider"]
                providerType = provider["type"]
                logger.info("provider Type :: "+str(providerType))
                logger.info("\n")
                
                deactivateUrl = "https://" + orgName + ".com/api/v1/users/"+str(userId)+"/lifecycle/deactivate"
                response = oktaFunctions.POSTRequest(deactivateUrl,"")
                logger.info(response)
                
                deleteUrl = "https://"+orgNameAdmin+".com/api/v1/users/"+str(userId)
                response = oktaFunctions.DELETEuser(deleteUrl)
                logger.info(response)
                logger.info("\n")
                
                

            
except Exception as e:
    logger.info(traceback.format_exc())