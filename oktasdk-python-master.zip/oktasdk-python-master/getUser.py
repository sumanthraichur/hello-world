try:
    import sys
    import csv
    import requests
    import logging
    import json
except:
    print ("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit ()

logging.basicConfig (level=logging.INFO)
logger = logging.getLogger (__name__)

url = "https://dev-530347.oktapreview.com/api/v1/groups"
apiKey = "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq"
apiUrl = "https://dev-530347.oktapreview.com"

payLoad1 = "{\n  \"profile\": {\n    \""
payLoad4 = "\"\n  }\n}"

headers = {
    'accept': "application/json" ,
    'content-type': "application/json" ,
    'authorization': "SSWS " + apiKey ,
    'cache-control': "no-cache"
}

logger.info ('Start reading group CSV file')
with open ('BulkGroupCreationTemplatev.01.csv' , 'r') as file:
    reader = csv.DictReader (file , delimiter=',')
    for row in reader:
        print (" ")

        grpName = row['groupName']
        print ("Group Name : {}".format (grpName))
        logger.debug ('GroupName: %s' , grpName)

        grpDesc = row['groupDescription']
        print ("Group Description : {}".format (grpDesc))
        logger.debug ('Group Description: %s' , grpDesc)

        grpType = row['groupType']
        print ("GroupType(Manual/Auto) : {}".format (grpType))
        logger.debug ('GroupType(Manual/Auto): %s' , grpType)

        grpMembershipRuleType = row['membershipRuleType']
        print ("Membership Rule Type : {}".format (grpMembershipRuleType))
        logger.debug ('Membership Rule Type: %s' , grpMembershipRuleType)

        grpCascadingName = row['cascadingGroupName']
        print ("Cascading Group Name : {}".format (grpCascadingName))
        logger.debug ('GroupType(Manual/Auto): %s' , grpCascadingName)

        grpAttributeRule = row['attributeRule']
        print ("Attribute Rule: {}".format (grpAttributeRule))
        logger.debug ('Attribute Rule: %s' , grpAttributeRule)

        grpManualMembershipAssistant = row['manualMembershipAssignment']
        print ("Manual Membership Assignment : {}".format (grpManualMembershipAssistant))
        logger.debug ('Manual Membership Assignment: %s' , grpManualMembershipAssistant)

        groupApplicationAssignment = row['groupApplicationAssignment']
        print ("Group Application Assignment : {}\n".format (groupApplicationAssignment))
        logger.debug ('Group Application Assignment: %s' , groupApplicationAssignment)

        payLoad2 = (("name\": \"{}").format (grpName))
        payLoad3 = (("\",\n    \"description\": \"{}").format (grpDesc))

        payload = payLoad1 + payLoad2 + payLoad3 + payLoad4
        print (payload)

        logger.info ('Creating Groups ...')

        response = requests.request ("POST" , url , data=payload , headers=headers)
        print (response.text)
        logger.info ('Response : %s' , response.text)
        logger.info ('Finished Creating Groups')

        if grpType.upper () == 'MANUAL':
            print ("Group Type is Manual, not creating group Rule")

        elif grpType.upper () == 'AUTO':
            print ("Creating Rule")

            grpRuleurl = "https://dev-530347.oktapreview.com/api/v1/groups/rules"

            querystring = {"q": "{}".format (grpName)}
            print (querystring)
            response = requests.request ("GET" , url , data=payload , headers=headers , params=querystring)
            print (response.text)
            json_dataGroup = json.loads (response.text)

            for itemGroup in json_dataGroup:
                grpUserId = '{}'.format (itemGroup['id'])
                print ("Group ID : {}".format (grpUserId))

                payload1 = "{\n      \"type\": \"group_rule\",\n      \""
                payLoad2 = (("name\": \"{} Rule\",\n      \"conditions\"").format (grpName))
                payLoad3 = ": {\n          \"people\": {\n            \"users\": {\n              \""
                payload4 = "exclude\": []\n            },\n            \""
                payload5 = "groups\": {\n              \"exclude\": []\n            }\n          },\n          \"expression\": {\n            \"value\""
                payload6 = ((": \"user.role==\\\"{}\\\"\",\n            \"").format (grpName))
                payload7 = "type\": \"urn:okta:expression:1.0\"\n          }\n"""
                payload8 = "        },\n      \"actions\": {\n        \"assignUserToGroups\""
                payload9 = ": {\n          \"groupIds\": [\n            \""
                payload10 = (("{}\"\n          ]\n        ").format (grpUserId))
                payload11 = "}\n      }\n    }"""
                payload = payLoad1 + payLoad2 + payLoad3 + payload4 + payload5 + payload6 + payload7 + payload8 + payload9 + payload10 + payload11
                print (payload)

                response = requests.request ("POST" , grpRuleurl , data=payload , headers=headers)
                print (response.text)
