try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    import OktaApiTokenDecrypt
    import csv
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "C:/python_logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = "mlclimited-sit.oktapreview"
attributeIsManager = readFromPropertiesFile.attributeIsManager


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA" ,
    }

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        return response.json()

def GETObject(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

fileName = 'C:/Users/debmalya.biswas/Desktop/UsersSIT.csv'   
try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            print("User Manager number : %s in CSV File.", count)
            count=count+1 
            print("#============ Manager Name Check =================#")
            managerLogin = row['manager']
            print("Manager Login ::"+str(managerLogin))
            print("\n")
            listManagerUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(managerLogin)+"\")"
            managerUserList = GETObject(listManagerUserUrl)
            for manager in managerUserList:
                managerUserId = manager["id"]
                managerProfile = manager['profile']
                managerUserUrl = "https://" + orgName + ".com/api/v1/users/" + str(managerUserId)
                managerUser_info = {}
                managerUser_info['profile'] = {}
                ismanagerValue= True
                managerUser_info['profile'] [attributeIsManager] = ismanagerValue
                managerUser_info_json = json.dumps(managerUser_info)
                response = POSTRequest(managerUserUrl, managerUser_info_json)
                if response != "Error":
                    print ("Attribute " + attributeIsManager + " Set to "+str(ismanagerValue)+" for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                    print("\n")
            
except Exception as e:
    print(traceback.format_exc())
