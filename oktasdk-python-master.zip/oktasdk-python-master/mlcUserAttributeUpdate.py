try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    import OktaApiTokenDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "C:/python_logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = readFromPropertiesFile.orgName
attributeNameStatus = readFromPropertiesFile.attributeNameStatus
attributeNameID = readFromPropertiesFile.attributeNameID
attributeManager = readFromPropertiesFile.attributeManager
attributeManagerID = readFromPropertiesFile.attributeManagerID


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()
    
def GetObject(url):
    response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            logger.info ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList
   
try:
    userSchemaUrl = "https://" + orgName + ".com/api/v1/meta/schemas/user/default"
    userSchema = GetObject(userSchemaUrl)
    baseAttributesList = userSchema["definitions"]["base"]["properties"]
    customAttributesList = userSchema["definitions"]["custom"]["properties"]
    if (((attributeNameStatus in baseAttributesList) or (attributeNameStatus in customAttributesList)) and ((attributeNameID in baseAttributesList) or (attributeNameID in customAttributesList))):
        listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\")"
        userList = GetPaginatedResponse(listUserUrl)
        dict = {}  # @ReservedAssignment
        for user in userList:
            profile = user['profile']
            if ("PersonId" in profile):
                dict[profile["PersonId"]] = profile["login"]
        for user in userList:
            userId = user["id"]
            profile = user['profile']
            userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
            user_info = {}
            user_info['profile'] = {}
            # User coming from Oracle HCM where mlcUserStatus is always set to 'Active'
            if ("mlcUserStatus" in profile):
                mlcUserStatus = profile["mlcUserStatus"]
                if (mlcUserStatus.upper() == "ACTIVE"):
                    if ("mlcUserId" not in profile):
                        logger.info("mlcUserStatus " + mlcUserStatus + " in profile but mlcUserId not in profile for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                        user_info['profile'] [attributeNameStatus] = user["status"]
                        user_info['profile'] [attributeNameID] = user["id"]
                        if("managerId" in profile) and ("PersonId" in profile) :
                            managerId = profile["managerId"]
                            PersonId = profile["PersonId"]
                            if (managerId in dict.keys()):
                                logger.info("User Login : " + profile["login"])
                                logger.info("Manager ID : " + managerId)
                                logger.info("Person ID : " + PersonId)
                                logger.info("Manager Login: " + dict[managerId])
                                user_info['profile'] [attributeManager] = dict[managerId]
                                 
                        user_info_json = json.dumps(user_info)
                        response = POSTRequest(userUrl, user_info_json)
                        if response != "Error":
                            logger.info ("Attribute " + attributeNameStatus + " Set to " + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                            logger.info ("Attribute " + attributeNameID + " Set to " + str(user["id"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                            if ("manager" in profile):
                                manager = profile["manager"]
                                logger.info ("Attribute " + attributeManager + " Set to " + manager + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                            logger.info ("\n")
             
            # User not coming from Oracle HCM       
            elif ("mlcUserStatus" not in profile):
                logger.info("mlcUserStatus and mlcUserId not in profile for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                user_info_json = "{\n  \"profile\": {\n\t\""
                user_info_json = user_info_json + "{}\":\"".format(attributeNameStatus)
                user_info_json = user_info_json + "{}\",\n\t\"".format(user["status"])
                user_info_json = user_info_json + "{}\":\"".format(attributeNameID)
                user_info_json = user_info_json + "{}\"\n  ".format(user["id"])
                user_info_json = user_info_json + "}\n}"
                response = POSTRequest(userUrl, user_info_json)
                if response != "Error":
                    logger.info ("Attribute " + attributeNameStatus + " Set to " + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                    logger.info ("Attribute " + attributeNameID + " Set to " + str(user["id"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                    logger.info ("\n")

    else:
        logger.info ("Attribute " + attributeNameStatus + " Not Found in User Schema. Please Create and Try Again.")
        logger.info ("Attribute " + attributeNameID + " Not Found in User Schema. Please Create and Try Again.")

except Exception as e:
    logger.info(traceback.format_exc())
