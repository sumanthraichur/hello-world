try:
    import sys
    import logging
    import traceback
    import errno
    import os
    import csv
    import oktaFunctions
    import re
    from datetime import datetime
    import oktaPayLoad
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = "mlcinsurance.okta"
fileName = "C:/Users/debmalya.biswas/Desktop/SNOWgroups.csv"
grpUrl = "https://"+orgName+".com/api/v1/groups"
ruleUrl = "https://" + orgName + ".com/api/v1/groups/rules"

try:
    
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            print("SNOW Group number : "+str(count)+" in CSV File.")
            count=count+1
             
            snowGrp = row['SNOW Group']
            print("SNOW Group :: "+str(snowGrp))
            
            grpName = snowGrp
            grpName = re.sub('[^A-Za-z0-9]+', '_', grpName)
            lastStringCheck = grpName[-1:]
            if "_" in lastStringCheck:
                grpName = grpName.rstrip('_')
            grpName = str("OKTA-")+grpName+str("-AppAssignment")
            print("Okta Group :: "+str(grpName))
            
            grpDesc = snowGrp
            grpDesc = re.sub('[^A-Za-z0-9]+', ' ', grpDesc)
            grpDesc = str("Group group for ")+grpDesc
            print("Okta Group Description :: "+str(grpDesc))
             
            groupPayLoad = oktaPayLoad.oktaGroupPayLoad(grpName, grpDesc)
            #Create group in Okta
            groupResponse = oktaFunctions.POSTRequest(grpUrl, groupPayLoad)
            if groupResponse != "Error":
                print ("Group "+str(grpName)+" is created in Okta")
            print("\n")
              
            groupList = []
            assignToGroup = groupResponse['id']
            groupList.append(assignToGroup)
            groupList = (', '.join('"' + item + '"' for item in groupList))
            print("Assign To Group ID :: "+str(groupList))
            
            ruleName = snowGrp
            ruleName = re.sub('[^A-Za-z0-9]+', ' ', ruleName)
            ruleName = str("Okta ")+ruleName+str(" Rule")
            if (len(ruleName)) > 50:
                ruleName=list(ruleName.split(" "))
                ruleName.pop(len(ruleName)-2)
                ruleName = ' '.join(ruleName)
                if (len(ruleName)) > 50:
                    ruleName=list(ruleName.split(" "))
                    ruleName.pop(len(ruleName)-2)
                    ruleName = ' '.join(ruleName)
            print("Okta Rule Name :: "+str(ruleName))
            print("\n")
            
            ###========== Find the SNOW Group ID ==========###
            findGroupUrl = grpUrl+"?q="+str(snowGrp)
            findGroupList = oktaFunctions.GETObject(findGroupUrl)
            groupsIdLst = []
            for groups in findGroupList:
                groupType = groups['type']
                if groupType == "APP_GROUP":
                    groupsId = groups["id"]
                    groupsIdLst.append(groupsId)
                    groupsIdLst=(', '.join('\\"' + item + '\\"' for item in groupsIdLst))
                    print("SNOW group ID :: "+str(groupsIdLst))
                print("\n")
             
            responseRulePayload = oktaPayLoad.groupRule(ruleName, groupsIdLst, groupList)
            print("RulePayload : "+str(responseRulePayload))
            responseRule = oktaFunctions.POSTRequest(ruleUrl, responseRulePayload)
            if responseRule != "Error":
                print(str(ruleName)+ " created in successfully")
                  
            #===================================================================
            # seacrhRule = responseRule['id']
            # ruleList = []
            # ruleList = seacrhRule
            # ruleList = ''.join(ruleList)
            # print("Rule ID for "+str(ruleName)+" :: "+str(ruleList))
            # activateRuleUrl = ruleUrl + "/" + ruleList + "/lifecycle/activate"
            # response = oktaFunctions.POSTRuleRequest(activateRuleUrl, "")
            # if response != "Error":
            #     print (str(ruleName)+" Activated")
            #===================================================================
            print("\n")

except Exception as e:
    print(traceback.format_exc())