try:    
    from ldap3 import Server, Connection
    import random
    import string
    import sys
    import os
    import errno
    from datetime import datetime
    import readFromPropertiesFile
    import json
    import smtplib
    from smtplib import SMTPException
    import traceback
    import AdTokenDecrypt
    import logging
    from email.header import Header
    from email.utils import formataddr
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "C:/python_logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends 


try:
    with Connection(Server(readFromPropertiesFile.hostName, port=389, get_info=all), user=readFromPropertiesFile.username, password=AdTokenDecrypt.adKeyDecoded) as c:
        c.search(search_base=readFromPropertiesFile.search_base, search_filter=readFromPropertiesFile.search_filter, attributes=['displayName', 'pwdLastSet', 'accountExpires', 'whenChanged', 'mail', 'sn', 'extensionAttribute1'])
        response = (c.response_to_json())
        json_response = json.loads(response) 
        for entry in json_response['entries']:
            attributes = entry['attributes']
            dn = entry['dn']
            logger.info ('dn :' + dn)
            for sn in attributes['sn']:
                logger.info ('sn :' + sn)
            for displayName in attributes['displayName']:
                logger.info ('displayName :' + displayName)
            for mail in attributes['mail']:
                logger.info ('mail :' + mail)
            for pwdLastSet in attributes['pwdLastSet']:
                logger.info ('pwdLastSet :' + pwdLastSet)
            for accountExpire in attributes['accountExpires']:
                logger.info ('accountExpires :' + accountExpire)
            for extensionAttribute1 in attributes['extensionAttribute1']:
                logger.info ('End Date :' + extensionAttribute1)
            for whenChanged in attributes['whenChanged']:
                logger.info ('whenChanged :' + whenChanged)
                logger.info('\n')
                

                
except Exception as e:
    logger.info("Could not search entries")
    logger.info(traceback.format_exc(e))
    sys.exit(0)
