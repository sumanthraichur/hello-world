try:
    import logging
    import traceback
    import os
    import errno
    from datetime import datetime
    import requests
    import json
    import sys
    from time import gmtime, strftime
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends

headers = {
     'accept': "application/json",
     'content-type': "application/json",
     'authorization': "SSWS 0028NKRFTn7N9YNGYq5qujBA82zPOKQQihwsdYyINA"
     #+ OktaApiTokenDecrypt.apiKeyOktaDecoded
     }

orgName="mlclimited-sit.oktapreview"

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        print ("\nYou encountered following Error: \n")
        print (responseJSON)
        print ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            print ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers, verify=False)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def POSTRequestPassword(url, querystring):
    if querystring != "":
        response = requests.post(url, headers=headers, params=querystring)
        response = "[" + response.text + "]"
        json_response = json.loads(response)
        for item in json_response:
            seacrhPassword = item['tempPassword']
            passwordList = []
            passwordList = seacrhPassword
        return passwordList

     
try:
    listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"PASSWORD_EXPIRED\")"
    userList = GetPaginatedResponse(listUserUrl)
    for user in userList:
        userId = user["id"]
        lastLogin = user["lastLogin"]
        passwordChanged = user["passwordChanged"]
        
        created = user["created"]
        created = created.replace("T", " ")
        created = created.replace(".000Z", "")
        
        profile = user['profile']
        login = profile['login']
        if ("vendorCompany" in profile):
            vendorCompany = profile['vendorCompany']
        else:
            vendorCompany = "None"

        if ("employeeType" in profile):
            employeeType = profile['employeeType']
        else:
            employeeType = "None"                   
        
        if (lastLogin == None) and (passwordChanged == None):
            if (employeeType == "Contingent Worker") and (vendorCompany != None):
                strftime = (strftime("%Y-%m-%d %H:%M:%S", gmtime()))
                fmt = "%Y-%m-%d %H:%M:%S"
                tdelta = datetime.strptime(strftime,fmt) - datetime.strptime(created,fmt)
                tdeltaSeconds = tdelta.total_seconds()
                tdeltaHours = tdeltaSeconds // 3600
                if tdeltaHours > 8:
                    expirePasswordUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId) + "/lifecycle/expire_password"
                    query = {"tempPassword":"true"}
                    print("User "+str(login)+" did not change temporary password in last 8 hours")
                    #response = POSTRequestPassword(expirePasswordUrl, query)                

except Exception as e:
    logger.info(traceback.format_exc())            