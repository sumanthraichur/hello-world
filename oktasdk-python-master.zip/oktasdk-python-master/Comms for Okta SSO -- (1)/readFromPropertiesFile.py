import configparser
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

config = configparser.ConfigParser()
config.sections()
config.read('config.properties')
config.sections()

#===============================================================================
# # print("Columns Names:")
# logger.info("Columns Names:")
#===============================================================================

for key in config['column']: 
    # print(key)
    # logger.info(key)
    column = config['column']
    orgName = (column['orgName'])
    attributeInitialLogin = (column['attributeInitialLogin'])
    notifyFromaddr = (column['notifyFromaddr'])
    sendUserPassword = (column['sendUserPassword'])
