import pyautogui, time
import pyperclip

for i in range(1000):
    pyautogui.moveTo(100, 100, duration=0.25)
    pyautogui.moveTo(200, 100, duration=0.25)
    pyautogui.moveTo(200, 200, duration=0.25)
    pyautogui.moveTo(100, 200, duration=0.25)
    time.sleep(5)
    # pyautogui.click(10, 5)
    distance = 2000
    while distance > 0:
        pyautogui.dragRel(distance, 0, duration=0.25)  # move right
        distance = distance - 5
        pyautogui.dragRel(0, distance, duration=0.25)  # move down
        pyautogui.dragRel(-distance, 0, duration=0.25)  # move left
        distance = distance - 5
        pyautogui.dragRel(0, -distance, duration=0.25)  # move up
        pyautogui.scroll(200)
        numbers = ''
        for i in range(200):
            numbers = numbers + str(i) + '\n'
            pyperclip.copy(numbers)
