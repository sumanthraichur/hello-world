try:
    import sys
    import csv
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
    import json
    import oktaFunctions
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()

orgName = "mlcinsurance.okta"
logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")

try:
    count=1
    listUserUrl = "https://" + orgName + ".com/api/v1/users"
    userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
    for user in userList:
        userId = user["id"]
        userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
        profile = user['profile']
        login = profile['login']
        user_info = {}
                    
        if "TM-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: TechM")
            user_info['profile'] ['vendorCompany'] = "TechM"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to TechM" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
            
        elif "ACC-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: Accenture")
            user_info['profile'] ['vendorCompany'] = "Accenture"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to Accenture" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
                        
        elif "INF-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: Infosys")
            user_info['profile'] ['vendorCompany'] = "Infosys"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to Infosys" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
                            
        elif "DTT-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: Deloitte")
            user_info['profile'] ['vendorCompany'] = "Deloitte"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to Deloitte" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
            
        elif "PIT-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: Plan IT")
            user_info['profile'] ['vendorCompany'] = "Plan IT"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to Plan IT" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
                          
        elif "TCS-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: TCS")
            user_info['profile'] ['vendorCompany'] = "TCS"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to TCS" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
                            
        elif "PH-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: Pure Hacking")
            user_info['profile'] ['vendorCompany'] = "Pure Hacking"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to Pure Hacking" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
                            
        elif "6TH-" in login.upper():
            print("User Login :: "+str(login))
            print("Vendor Company :: 6th Force")
            user_info['profile'] ['vendorCompany'] = "6th Force"
            user_info_json = json.dumps(user_info)
            response = oktaFunctions.POSTRequest(userUrl, user_info_json)
            if response != "Error":
                logger.info ("Attribute Vendor Company Set to 6th Force" + str(user["status"]) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                print('\n')
                            
except Exception as e:
    logger.info(traceback.format_exc())