Okta: The Official Okta SDK
===========================

This SDK allows you to manage your Okta instance using Python.

Contents
--------

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   api/clients/index