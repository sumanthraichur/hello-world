---------------
Installation
---------------

Install using pip:
::

    pip install okta