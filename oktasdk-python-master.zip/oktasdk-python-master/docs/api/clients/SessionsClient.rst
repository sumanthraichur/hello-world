:class:`SessionsClient`
=======================

.. currentmodule:: okta

.. autoclass:: SessionsClient
  :members: