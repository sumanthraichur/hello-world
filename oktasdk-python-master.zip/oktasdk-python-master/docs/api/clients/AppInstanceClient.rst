:class:`AppInstanceClient`
==========================

.. currentmodule:: okta

.. autoclass:: AppInstanceClient
  :members: