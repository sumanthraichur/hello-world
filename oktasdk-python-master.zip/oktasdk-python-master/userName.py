import re


esbUserName = "John.Collins19"
OktaUserLogin = "John.Collins19"
hcmUserName = re.search(r'\d+$', esbUserName)
print(hcmUserName)
if OktaUserLogin == esbUserName and not hcmUserName:
    esbUserName += "1"
    print("If Clause : " + esbUserName)
else:
    esbUserName = re.sub('\d(?!\d)', lambda x: str(int(x.group(0)) + 1), esbUserName)
    print("Else Clause : " + esbUserName)
    