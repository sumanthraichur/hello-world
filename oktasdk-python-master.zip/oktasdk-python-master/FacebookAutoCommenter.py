import requests
import json
     
#Insert facebook token here
access_token = "EAADtuch1AykBAK97A5JcZA2nt3BBZABx5Et25AlfksX6gJoonsUzpUjBZBCmff6QK7axRJPqNQFaKnhTTp0QoWk2vDeNCPkhNaDNoVZBHMKxPm6OgxB4HL0IeZBEenRGLYxHLHBlLlRsveU2qHDhFzZCibaNQzNc5L0emZB1QPMMAtwDgyF6Vp6KeRUGPeswYcZD"
     
def comment_on_posts(posts, amount):
    counter = 0
    for post in posts:
        if counter >= amount:
                break
        else:
            counter = counter + 1
        url = "https://graph.facebook.com/{0}/comments".format(post['id'])
        print(url)
        message = "Hi bro!"
        parameters = {'access_token' : access_token, 'message' : message}
        print(parameters)
        s = requests.post(url, data = parameters)
        print(s)
     
def get_posts():
    payload = {'access_token' : access_token}
    r = requests.get('https://graph.facebook.com/me/feed', params=payload)
    result = json.loads(r.text)
    return result['data']
     
if __name__ == "__main__":
    posts = get_posts()
    comment_on_posts(posts, 2)