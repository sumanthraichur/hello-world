
try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    import OktaApiTokenDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = readFromPropertiesFile.orgName
attributeManager = readFromPropertiesFile.attributeManager
attributeManagerID = readFromPropertiesFile.attributeManagerID


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    }

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()
    
def GetObject(url):
    response = requests.request("GET", url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            logger.info ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList


try:
    userSchemaUrl = "https://" + orgName + ".com/api/v1/meta/schemas/user/default"
    userSchema = GetObject(userSchemaUrl)
    baseAttributesList = userSchema["definitions"]["base"]["properties"]
    customAttributesList = userSchema["definitions"]["custom"]["properties"]
    if (((attributeManager in baseAttributesList) or (attributeManager in customAttributesList)) and ((attributeManagerID in baseAttributesList) or (attributeManagerID in customAttributesList))):
        listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\")"
        userList = GetPaginatedResponse(listUserUrl)
        dict = {}  # @ReservedAssignment
        for user in userList:
            profile = user['profile']
            if ("PersonId" in profile):
                dict[profile["PersonId"]] = profile["login"]
                
        for user in userList:
            userId = user["id"]
            profile = user['profile']
            userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
            user_info = {}
            user_info['profile'] = {}
            if ("managerId" in profile) and ("PersonId" in profile):
                managerId = profile["managerId"]
                PersonId = profile["PersonId"]
                if (managerId in dict.keys() and ("manager" not in profile)):
                      
                    logger.info("User Login : " + profile["login"])
                    logger.info("Manager ID : " + managerId)
                    logger.info("Person ID : " + PersonId)
                    logger.info("Manager Login: " + dict[managerId])
                    logger.info("\n")
                      
                    user_info['profile'] [attributeManager] = dict[managerId]
                    user_info_json = json.dumps(user_info)
                    response = POSTRequest(userUrl, user_info_json)
                       
                    if response != "Error":
                        logger.info ("Attribute " + attributeManager + " Set to " + dict[managerId] + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                        logger.info ("\n")
            
                elif ("manager" in profile) and (managerId == ""):
                    manager = profile["manager"]
                    if (manager in dict.values()):
                        managerKey = next(key for key, value in dict.items() if value == manager)
                        logger.info("User Login : " + profile["login"])
                        logger.info("Manager Login : " + manager)
                        logger.info("Person ID : " + PersonId)
                        logger.info("Manager ID: " + managerKey)
                        logger.info("\n")
                       
                        user_info['profile'] [attributeManagerID] = managerKey
                        user_info_json = json.dumps(user_info)
                        response = POSTRequest(userUrl, user_info_json)
                         
                        if response != "Error":
                            logger.info ("Attribute " + attributeManagerID + " Set to " + managerKey + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                            logger.info ("\n")
                        
            elif ("manager" in profile) and ("PersonId" in profile):
                manager = profile["manager"]
                PersonId = profile["PersonId"]
                if (manager in dict.values() and ("managerId" not in profile)):
                    managerKey = next(key for key, value in dict.items() if value == manager)
                     
                    logger.info("User Login : " + profile["login"])
                    logger.info("Manager Login : " + manager)
                    logger.info("Person ID : " + PersonId)
                    logger.info("Manager ID: " + managerKey)
                    logger.info("\n")
                      
                    user_info['profile'] [attributeManagerID] = managerKey
                    user_info_json = json.dumps(user_info)
                    response = POSTRequest(userUrl, user_info_json)
                        
                    if response != "Error":
                        logger.info ("Attribute " + attributeManagerID + " Set to " + managerKey + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                        logger.info ("\n")
                        
                
    else:
        logger.info ("Attribute " + attributeManager + " Not Found in User Schema. Please Create and Try Again.")
        logger.info ("Attribute " + attributeManagerID + " Not Found in User Schema. Please Create and Try Again.")

except Exception as e:
    logger.info(traceback.format_exc())
