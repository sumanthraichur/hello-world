try:   
    import sys
    import csv
    import requests
    import logging
    import json
    import re
    import os
    from datetime import datetime
    import errno
    import traceback
    import readFromPropertiesFile
    import OktaApiTokenDecrypt
    from okta import AppInstanceClient
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends
  
appInstanceClient = AppInstanceClient(readFromPropertiesFile.oktaUrl, OktaApiTokenDecrypt.apiKeyOktaDecoded)
apps = appInstanceClient.get_app_instances()

payLoad1 = "{\n  \"profile\": {\n    \""
payLoad4 = "\"\n  }\n}"

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + OktaApiTokenDecrypt.apiKeyOktaDecoded,
    'cache-control': "no-cache"
    }


logger.info("\n")
logger.info('Start reading group CSV file')

try:
    with open(readFromPropertiesFile.fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
        # print(" ")
            logger.info(" ")
        
        #==================================================================================================#
        # Reading the CSV file attributes
            grpName = row[readFromPropertiesFile.groupName]
        # print("Group Name : {}".format(grpName))
            logger.info('GroupName: %s', grpName)
         
            grpDesc = row[readFromPropertiesFile.groupDescription]
        # print("Group Description : {}".format(grpDesc))
            logger.info('Group Description: %s', grpDesc)
         
            grpType = row[readFromPropertiesFile.groupType]
        # print("GroupType(Manual/Auto) : {}".format(grpType))
            logger.info('GroupType(Manual/Auto): %s', grpType)
         
            grpMembershipRuleType = row[readFromPropertiesFile.membershipRuleType]
        # print("Membership Rule Type : {}".format(grpMembershipRuleType))
            logger.info('Membership Rule Type: %s', grpMembershipRuleType)
         
            grpCascadingName = row[readFromPropertiesFile.cascadingGroupName]
        # print("Cascading Group Name : {}".format(grpCascadingName))
            logger.info('GroupType(Manual/Auto): %s', grpCascadingName)
        
         
            grpAttributeRule = "[{" + row[readFromPropertiesFile.attributeRule] + "}]"
        # print("Attribute Rule: {}".format(grpAttributeRule))
            logger.info('Attribute Rule: %s', grpAttributeRule)
         
            grpManualMembershipAssistant = "[{" + row[readFromPropertiesFile.manualMembershipAssignment] + "}]"
        # print("Manual Membership Assignment : {}".format(grpManualMembershipAssistant))
            logger.info('Manual Membership Assignment: %s', grpManualMembershipAssistant)
         
            groupApplicationAssignment = row[readFromPropertiesFile.groupApplicationAssignment] 
        # print("Group Application Assignment : {}\n".format(groupApplicationAssignment))
            logger.info('Group Application Assignment: %s', groupApplicationAssignment)
         
            payLoad2 = (("name\": \"{}").format(grpName))
            payLoad3 = (("\",\n    \"description\": \"{}").format(grpDesc))
                 
            payload = payLoad1 + payLoad2 + payLoad3 + payLoad4
        # print(payload)
            logger.info("Creating group with parameter : {}".format(payload))
        # print("\n")
            logger.info("\n")
         
            logger.info('Creating Groups ...')
            responseGroup = requests.request("POST", readFromPropertiesFile.grpUrl, data=payload, headers=headers)
            logger.info('Finished Creating Groups')
            responseRuleGroup = "[" + responseGroup.text + "]"
        # print(responseRuleGroup)
            logger.info("Json output : {}".format(responseRuleGroup))
         
            json_responseSearchGroup = json.loads(responseRuleGroup) 
            for itemSeacrhGroup in json_responseSearchGroup:
                seacrhGroup = itemSeacrhGroup['id']
                groupList = []
                groupList = seacrhGroup
            # print("Searched Group ID : {}".format(groupList))
                logger.info("Searched Group ID : {}".format(groupList))
                if groupApplicationAssignment is not None:
                # print(groupApplicationAssignment)
                    logger.info(groupApplicationAssignment)
                    groupApplicationAssignment = re.split(r';', groupApplicationAssignment)
                    for i, valueOfApp in enumerate(groupApplicationAssignment):
                    # print(valueOfApp)
                        logger.info("Application Name: {}".format(valueOfApp))
                        for app in apps:
                            appId = app.id
                            appLabel = app.label
                            aDict = {}
                            aDict[appLabel] = appId
                            for appId in enumerate(aDict):
                                if valueOfApp == appLabel:
                                    applicationId = ''.join(aDict.values())
                                # print(applicationId)
                                    logger.info("Application ID : {}".format(applicationId))
                                    groupApplicationUrl = readFromPropertiesFile.appUrl + "/" + applicationId + "/groups/" + groupList
                                # print(groupApplicationUrl)
                                    logger.info("Assigning application to group URL : {}".format(groupApplicationUrl))
                                    payload = "{\n}"
                                    response = requests.request("PUT", groupApplicationUrl, data=payload, headers=headers)
                                # print(response.text)
                                    logger.info(response.text)
            
        #==================================================================================================#                           
        # When Membership Type is Attribute Rule and Group Rule Creation Type is Automatic    
            if grpType.upper() == 'AUTO' and grpMembershipRuleType.upper() == 'ATTRIBUTE':
                logger.info("When Membership Type is Attribute Rule and Group Rule Creation Type is Automatic") 
            # print("Creating User in AD in with values : {}".format(grpAttributeRule))
                logger.info("Creating User in AD in with values : {}".format(grpAttributeRule))
            # print(grpAttributeRule)
                logger.info("Group attribute rule data : {}".format(grpAttributeRule))
                json_response = json.loads(grpAttributeRule)
                for item in json_response:
                    grpAttributeRulejobFamily = item['jobFamily']
                    grpAttributeRulejobFunction = item['jobFunction']
                    grpAttributeRulejobRole = item['jobRole']
                # print("User job Family : {}".format(grpAttributeRulejobFamily))
                # print("User job Function : {}".format(grpAttributeRulejobFunction))
                # print("User job Role : {}\n".format(grpAttributeRulejobRole))
                
                    logger.info("User job Family : {}".format(grpAttributeRulejobFamily))
                    logger.info("User job Function : {}".format(grpAttributeRulejobFunction))
                    logger.info("User job Role : {}\n".format(grpAttributeRulejobRole))
                     
                    grpAttributeRulejobFamily = re.split(r';', grpAttributeRulejobFamily)
                    grpAttributeRulejobFunction = re.split(r';', grpAttributeRulejobFunction)
                    grpAttributeRulejobRole = re.split(r';', grpAttributeRulejobRole)
                     
                # print ("grpAttributeRulejobFamily : {}".format(grpAttributeRulejobFamily))
                # print ("grpAttributeRulejobFunction : {}".format(grpAttributeRulejobFunction))
                # print ("grpAttributeRulejobFunction : {}".format(grpAttributeRulejobRole))
                
                    logger.info ("grpAttributeRulejobFamily : {}".format(grpAttributeRulejobFamily))
                    logger.info ("grpAttributeRulejobFunction : {}".format(grpAttributeRulejobFunction))
                    logger.info ("grpAttributeRulejobFunction : {}".format(grpAttributeRulejobRole))
                     
                # print("\n")
                    logger.info("\n")
                     
                    grpAttributeRulejobFamily = '{\\"' + '\\",\\"'.join(grpAttributeRulejobFamily) + '\\"}' 
                # print(grpAttributeRulejobFamily)
                    logger.info("Group attribute rule job family value : {}".format(grpAttributeRulejobFamily))
                     
                # print("\n")
                    logger.info("\n")
                
                    grpAttributeRulejobFunction = '{\\"' + '\\",\\"'.join(grpAttributeRulejobFunction) + '\\"}' 
                # print(grpAttributeRulejobFunction)
                    logger.info("Group attribute Rule job function value : {}".format(grpAttributeRulejobFunction))
                     
                # print("\n")
                    logger.info("\n")
                
                    grpAttributeRulejobRole = '{\\"' + '\\",\\"'.join(grpAttributeRulejobRole) + '\\"}' 
                # print(grpAttributeRulejobRole)
                    logger.info("Group attribute Rule job role value: {}".format(grpAttributeRulejobRole))
                     
                    payload1 = "{\n      \"type\": \"group_rule\",\n      \"name\""
                    payload2 = (": \"{} rule\",\n      \"status\": \"INACTIVE\",\n      \"conditions\"").format(grpName)
                    payload3 = ": {\n          \"expression\": {\n            \"value\""
                    payload4 = ": \"Arrays.contains({},".format(grpAttributeRulejobFamily)
                    payload5 = "{})".format(readFromPropertiesFile.jobFamily)
                    payload6 = " and Arrays.contains({},".format(grpAttributeRulejobFunction)
                    payload7 = "{})".format(readFromPropertiesFile.jobFunction)
                    payload8 = " and Arrays.contains({},".format(grpAttributeRulejobRole)
                    payload9 = "{})\"".format(readFromPropertiesFile.jobRole)
                    payload10 = ",\n            \"type\": \"urn:okta:expression:1.0\"\n          }\n        },\n      \"actions\""
                    payload11 = ": {\n        \"assignUserToGroups\": {\n          \"groupIds\""
                    payload12 = ": [\n            \"{}\"\n          ]".format(groupList)
                    payload13 = "\n        }\n    }\n}\n"
                    payload = payload1 + payload2 + payload3 + payload4 + payload5 + payload6 + payload7 + payload8 + payload9 + payload10 + payload11 + payload12 + payload13
                # print(payload)
                    logger.info("Attribute Rule creation value: {}".format(payload))
                     
                    responseRule = requests.request("POST", readFromPropertiesFile.ruleUrl, data=payload, headers=headers)
                    responseRule = "[" + responseRule.text + "]"
                # print(responseRule)
                    logger.info("Attribute Rule creation response : {}".format(responseRule))
                # print("{} Rule Created".format(grpName))
                    logger.info("{} Rule Created".format(grpName))
                    json_responseSearchRule = json.loads(responseRule) 
                    for itemSeacrhRule in json_responseSearchRule:
                        seacrhRule = itemSeacrhRule['id']
                        ruleList = []
                        ruleList = seacrhRule
                    # print("Searched Rule ID : {}".format(ruleList))
                        logger.info("Searched Rule ID : {}".format(ruleList))
                 
                        activateRuleUrl = readFromPropertiesFile.ruleUrl + "/" + ruleList + "/lifecycle/activate"
                    # print(activateRuleUrl)
                        logger.info("Rule activation URL : {}".format(activateRuleUrl))
                        response = requests.request("POST", activateRuleUrl, data=payload, headers=headers)
                    # print(response.text)
                        logger.info("Rule activation response : {}".format(response.text))
                    # print ("{} Rule Activated".format(grpName))
                        logger.info ("{} Rule Activated".format(grpName))
          
        #==================================================================================================# 
        # When Membership Type is Cascade Rule and Group is not null 
            elif grpMembershipRuleType.upper() == 'CASCADE' and grpCascadingName is not None:
                logger.info("When Membership Type is Cascade Rule and Group is not null")
                cascadeGroupName = None
                grpCascadingName = re.split(r';', grpCascadingName)
            # print(grpCascadingName)
            # print("Group needed to be added to the created group : {}".format(grpCascadingName))
                for i, valueOfGroup in enumerate(grpCascadingName):
                    querystring = {"q":"" + valueOfGroup}
                    response = requests.request("GET", readFromPropertiesFile.grpUrl, headers=headers, params=querystring)
                    logger.info("Group search response : {}".format(response.text))
                    json_cascadeGroup = json.loads(response.text)
                    for item in (json_cascadeGroup):
                        cascadeGroupUserId = '{}'.format(item['id'])
                        cascadeGroupList = []
                        cascadeGroupList = (cascadeGroupUserId)
                        grpCascading = (cascadeGroupList) 
                    if cascadeGroupName is None:
                        cascadeGroupName = '(\\"' + grpCascading + '\\",'
                    elif cascadeGroupName is not None:
                        cascadeGroupName += '\\"' + grpCascading + '\\",'
                  
                cascadeGroupName = re.sub(',$', ')', cascadeGroupName)
            # print("Cascade Group Name: {}".format(cascadeGroupName))
                logger.info("Cascade Group Name: {}".format(cascadeGroupName))
              
                payload1 = "{\n      \"type\": \"group_rule\",\n      \""
                payload2 = "name\": \"{} Rule\",\n      \"".format(grpName)
                payload3 = "status\": \"INACTIVE\",\n      \"conditions\": {\n          \"expression\": {\n        \t\"value\": \""
                payload4 = "isMemberOfAnyGroup{}\"".format(cascadeGroupName)
                payload5 = ",\n           \"type\": \"urn:okta:expression:1.0\"\n          }\n        },\n      \"actions\": {\n        \"assignUserToGroups\": {\n          \"groupIds\""
                payload6 = ": [\n            \"{}\"\n          ]\n        ".format(groupList)
                payload7 = "}\n      }\n    }\n"
               
                payload = payload1 + payload2 + payload3 + payload4 + payload5 + payload6 + payload7
            # print(payload)
                logger.info("Is member of group value : {}".format(payload))
            
                responseRule = requests.request("POST", readFromPropertiesFile.ruleUrl, data=payload, headers=headers)
                responseRule = "[" + responseRule.text + "]"
            # print(responseRule)
                logger.info(responseRule)
            
            # print("{} Rule Created".format(grpName))
                logger.info("{} Rule Created".format(grpName))
            
                json_responseSearchRule = json.loads(responseRule) 
                for itemSeacrhRule in json_responseSearchRule:
                    seacrhRule = itemSeacrhRule['id']
                    ruleList = []
                    ruleList = seacrhRule
                # print("Searched Rule ID : {}".format(ruleList))
                    logger.info("Searched Rule ID : {}".format(ruleList))
                 
                    activateRuleUrl = readFromPropertiesFile.ruleUrl + "/" + ruleList + "/lifecycle/activate"
                # print(activateRuleUrl)
                    logger.info("Rule activation URL: {}".format(activateRuleUrl))
                
                    response = requests.request("POST", activateRuleUrl, data=payload, headers=headers)
                # print(response.text)
                    logger.info("Rule activation response: {}".format(response.text))
                # print ("{} Rule Activated".format(grpName))
                    logger.info ("{} Rule Activated".format(grpName))
          
        #==================================================================================================#  
        # When Membership Type is Manual, and user login is not null, adding user to that group
            elif grpMembershipRuleType.upper() == 'MANUAL'and grpManualMembershipAssistant is not None:
                logger.info("When Membership Type is Manual, and user login is not null, adding user to that group")
                json_response = json.loads(grpManualMembershipAssistant)
                for item in json_response:
                    grpManualMembershipAssistant = item[readFromPropertiesFile.userLogin]
                    grpmanualMembershipAssignment = re.split(r';', grpManualMembershipAssistant)
                    logger.info("Group membership user login value : {}".format(grpmanualMembershipAssignment))
                    for i, valueOfUser in enumerate(grpmanualMembershipAssignment):
                        querystring = {"filter":"" + readFromPropertiesFile.filterUserLogin + " eq \"" + valueOfUser + "\""}
                        response = requests.request("GET", readFromPropertiesFile.userUrl, headers=headers, params=querystring)
                        logger.info("Searched user id : {}".format(response.text))
                        json_manualMembershipAssignment = json.loads(response.text)
                        for item in (json_manualMembershipAssignment):
                            manualMembershipAssignmentUserId = '{}'.format(item['id'])
                            manualMembershipAssignmentUserIdList = []
                            manualMembershipAssignmentUserIdList = (manualMembershipAssignmentUserId)
                            manualMembershipAssignmentUserId = (manualMembershipAssignmentUserIdList)
                            logger.info("User id adding to group : {}".format(manualMembershipAssignmentUserId))
                            membershipUrl = readFromPropertiesFile.grpUrl + "/" + groupList + "/users/" + manualMembershipAssignmentUserId
                            logger.info("Adding User to group URL : {}".format(membershipUrl))
                            response = requests.request("PUT", membershipUrl, headers=headers)
                        # print(response.text)
                            logger.info(response.text)
                        # print ("User" + manualMembershipAssignmentUserId + " Added to group {} \n".format(grpName))
                            logger.info ("User" + manualMembershipAssignmentUserId + " Added to group {} \n".format(grpName))
                  
            else:
                break
except Exception as e:
    # print(traceback.format_exc())
    logging.error(traceback.format_exc())
