
try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    import OktaApiTokenDecrypt
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If oktaLogger file exists append oktaLogger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the oktaLogger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   

orgName = readFromPropertiesFile.orgName
attributeManager = readFromPropertiesFile.attributeManager
attributeManagerID = readFromPropertiesFile.attributeManagerID
attributeIsManager = readFromPropertiesFile.attributeIsManager


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS "+ OktaApiTokenDecrypt.apiKeyOktaDecoded
    }

def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers, verify=False)
    else:
        response = requests.post(url, headers=headers)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()
    
def GetObject(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()


def GETObject(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList+responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList

def GetPaginatedResponse(url):
    response = requests.request("GET", url, headers=headers, verify=False)
    returnResponseList = []
    responseJSON = json.dumps(response.json())
    responseList = json.loads(responseJSON)
    returnResponseList = returnResponseList + responseList
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        headerLink = response.headers["Link"]
        count = 1
        while str(headerLink).find("rel=\"next\"") > -1:
            linkItems = str(headerLink).split(",")
            nextCursorLink = ""
            for link in linkItems:
                if str(link).find("rel=\"next\"") > -1:
                    nextCursorLink = str(link)
            nextLink = str(nextCursorLink.split(";")[0]).strip()
            nextLink = nextLink[1:]
            nextLink = nextLink[:-1]
            url = nextLink
            logger.info ("\nCalling Paginated Url " + str(url) + "  " + str(count) + " \n")
            response = requests.request("GET", url, headers=headers)
            responseJSON = json.dumps(response.json())
            responseList = json.loads(responseJSON)
            returnResponseList = returnResponseList + responseList
            headerLink = response.headers["Link"]
            count += 1
        returnJSON = json.dumps(returnResponseList)  # @UnusedVariable
        return returnResponseList


try:
    userSchemaUrl = "https://" + orgName + ".com/api/v1/meta/schemas/user/default"
    userSchema = GetObject(userSchemaUrl)
    baseAttributesList = userSchema["definitions"]["base"]["properties"]
    customAttributesList = userSchema["definitions"]["custom"]["properties"]
    if (((attributeManager in baseAttributesList) or (attributeManager in customAttributesList)) and ((attributeManagerID in baseAttributesList) or (attributeManagerID in customAttributesList))):
        listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(status eq \"ACTIVE\" or status eq \"PROVISIONED\")"
        userList = GetPaginatedResponse(listUserUrl)
        dict = {}  # @ReservedAssignment
        for user in userList:
            profile = user['profile']
            if ("PersonId" in profile):
                dict[profile["PersonId"]] = profile["login"]
        for user in userList:
            userId = user["id"]
            profile = user['profile']
            login = profile['login']
            userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
            user_info = {}
            user_info['profile'] = {}
            # User coming from Oracle HCM
            if "isHCMUser" in profile:
                isHCMUser = profile['isHCMUser']
                if isHCMUser == True:
                    if ("managerId" in profile) and ("PersonId" in profile) and ("manager" in profile):
                        managerId = profile["managerId"]
                        manager = profile["manager"]
                        PersonId = profile["PersonId"]
                        if (managerId in dict.keys()) :
                            if(manager != dict[managerId]):
                                
                                logger.info("User Login : " + profile["login"])
                                logger.info("Manager ID : " + managerId)
                                logger.info("Person ID : " + PersonId)
                                logger.info("Manager Login: " + dict[managerId])
                                logger.info("\n")
                                
                                listManagerUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(dict[managerId])+"\")"
                                logger.info(listManagerUserUrl)
                                managerUserList = GETObject(listManagerUserUrl)
                                
                                for managerInfo in managerUserList:
                                    managerUserId = managerInfo["id"]
                                    managerProfile = managerInfo['profile']
                                    managerUserUrl = "https://" + orgName + ".com/api/v1/users/" + str(managerUserId)
                                    managerUser_info = {}
                                    managerUser_info['profile'] = {}
                                            
                                    if("isManager" not in managerProfile):
                                        managerUser_info['profile'] [attributeIsManager] = True
                                        managerUser_info_json = json.dumps(managerUser_info)
                                        response = POSTRequest(managerUserUrl, managerUser_info_json)
                                        if response != "Error":
                                            logger.info ("Attribute " + attributeIsManager + " Set to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                                    
                                    elif("isManager" in managerProfile):
                                            isManager = managerProfile["isManager"]
                                            if (isManager == True):
                                                logger.info ("Attribute " + attributeIsManager + " is already set to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                            elif (isManager != True):
                                                managerUser_info['profile'] [attributeIsManager] = True
                                                managerUser_info_json = json.dumps(managerUser_info)
                                                response = POSTRequest(managerUserUrl, managerUser_info_json)
                                                if response != "Error":
                                                    logger.info ("Attribute " + attributeIsManager + " already in manager profile, Setting it to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))                            
                                
                                user_info['profile'] [attributeManager] = dict[managerId]
                                user_info_json = json.dumps(user_info)
                                response = POSTRequest(userUrl, user_info_json)
                                if response != "Error":
                                    logger.info ("Attribute " + attributeManager + " Set to " + dict[managerId] + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                                    logger.info ("\n")
    
            # Contingent Worker :: Users not coming from Oracle HCM , manually created in Okta      
            elif "isHCMUser" not in profile:
                if "employeeType" in profile:
                    employeeType = profile['employeeType']
                    if employeeType == "Contingent Worker":
                        if ("resourceOwner" in profile) and ("manager" in profile):
                            resourceOwner = profile['resourceOwner']
                            logger.info(str(resourceOwner)+ " is resourceOwner for Contingent Worker "+str(profile["firstName"]) + " " + str(profile["lastName"]))
                            if (resourceOwner != None) or (resourceOwner != ""):
                                listManagerUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \""+str(resourceOwner)+"\")"
                                listManagerUserList = GETObject(listManagerUserUrl)
                                for managerUser in listManagerUserList:
                                    managerUserId = managerUser["id"]
                                    managerProfile = managerUser['profile']
                                    isHCMUser = managerProfile['isHCMUser']
                                    if isHCMUser == True:
                                        logger.info("isHCMUser value for  "+str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"])+" is TRUE, so updating manager value")
                                        managerUserUrl = "https://" + orgName + ".com/api/v1/users/" + str(managerUserId)
                                        managerUser_info = {}
                                        managerUser_info['profile'] = {}
                                        user_info['profile'] [attributeManager] = resourceOwner
                                        user_info_json = json.dumps(user_info)
                                        response = POSTRequest(userUrl, user_info_json)
                                        if response != "Error":
                                            logger.info ("Attribute " + attributeManager + " Set to " + str(resourceOwner) + " for " + str(profile["firstName"]) + " " + str(profile["lastName"]))
                                            
                                        if ("isManager" in managerProfile):
                                            if managerProfile ['isManager'] != True:
                                                managerUser_info['profile'] [attributeIsManager] = True
                                                managerUser_info_json = json.dumps(managerUser_info)
                                                response = POSTRequest(managerUserUrl, managerUser_info_json)
                                                if response != "Error":
                                                    logger.info ("Attribute isManager Setting to TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                            else:
                                                logger.info ("Attribute isManager is already TRUE for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                        else:
                                            managerUser_info['profile'] [attributeIsManager] = True
                                            managerUser_info_json = json.dumps(managerUser_info)
                                            response = POSTRequest(managerUserUrl, managerUser_info_json)
                                            if response != "Error":
                                                logger.info ("Attribute isManager not present, so Setting to TRUE  for " + str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"]))
                                    
                                    elif isHCMUser != True:
                                        logger.info("isHCMUser value for  "+str(managerProfile["firstName"]) + " " + str(managerProfile["lastName"])+" is FALSE, so not updating manager value")
                                               
                            else:
                                logger.info ("Attribute resourceOwner has null value for " + str(profile["firstName"]) + " " + str(profile["lastName"]))                   
                            logger.info ("\n")
    else:
        logger.info ("Attribute " + attributeManager + " Not Found in User Schema. Please Create and Try Again.")
        logger.info ("Attribute " + attributeManagerID + " Not Found in User Schema. Please Create and Try Again.")

except Exception as e:
    logger.info(traceback.format_exc())
