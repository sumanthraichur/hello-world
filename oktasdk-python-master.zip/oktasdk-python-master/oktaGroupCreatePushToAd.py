try:
    import sys
    import csv
    import oktaFunctions
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName = "mlcinsurance.okta"
orgNameAdmin = "mlcinsurance-admin.okta"
fileName = 'C:/Users/debmalya.biswas/Desktop/groupPush.csv'
distinguishedName = "OU=Applications,OU=Groups,OU=Australia,OU=MLCLCore,DC=ad,DC=mlclife,DC=com,DC=au"  
adUrl = "https://" + orgName + ".com/api/v1/apps/user/types?expand=app%2CappLogo&category=directory" 
grpUrl = "https://"+orgName+".com/api/v1/groups"



logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
logger.info('Start reading group CSV file')
logger.info("\n")    
    
try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            logger.info("Group number : %s in CSV File.", count)
            count=count+1 
            logger.info("#============ Group Name Check =================#")
            grpName = row['Group Name']
            logger.info("Group Name ::"+str(grpName))
            
            grpDesc = row['Group Description']
            logger.info("Group description ::"+str(grpDesc))
            
            groupPayLoad = oktaPayLoad.oktaGroupPayLoad(grpName, grpDesc)
            #Create group in Okta
            groupResponse = oktaFunctions.POSTRequest(grpUrl, groupPayLoad)
            if groupResponse != "Error":
                logger.info ("Group "+str(grpName)+" is created in Okta")
                logger.info ("\n")
                            
            querystring = {"q":""+str(grpName)+""}
            groupResponse = oktaFunctions.GETGroupRequest(grpUrl, querystring)
            for group in groupResponse:
                userGroupId = group["id"]
                pushPayLoad = oktaPayLoad.groupPushPayLoad(userGroupId, distinguishedName, grpName)
                logger.info ("Push Group Payload :: \n"+str(pushPayLoad))
                adIdList = oktaFunctions.GetPaginatedResponse(adUrl)
                for adId in adIdList:
                    adEmbedded = adId["_embedded"]
                    adApp = adEmbedded["app"]
                    adAppId = adApp["id"]
                    pushGrpUrl = "https://"+orgNameAdmin+".com/api/internal/instance/"+str(adAppId)+"/grouppush"
                    logger.info ("Push Group URL :: "+str(pushGrpUrl))
                    #Push group in AD
                    pushResponse = oktaFunctions.POSTRequest(pushGrpUrl, pushPayLoad)
                    if pushResponse != "Error":
                        logger.info ("Group "+str(grpName)+" pushed to AD")
                        logger.info ("\n")
            
except Exception as e:
    logger.info(traceback.format_exc())