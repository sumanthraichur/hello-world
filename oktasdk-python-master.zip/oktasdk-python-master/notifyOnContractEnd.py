try:
    import smtplib
    from smtplib import SMTPException
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    import okta
    import time
    import datetime
    import sys
    from okta import UsersClient
    from okta.models.user import User
    from okta.models.user import UserProfile
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
usersClient = UsersClient("https://dev-530347.oktapreview.com", "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq")
users = usersClient.get_users()

while True:
    for user in users :
            if (user.profile.contractEndDate) is not None and (user.profile.managerId) is not None :
                contractEndDate = (user.profile.contractEndDate)
                print(contractEndDate)
                currentDate = datetime.datetime.now()
                print(currentDate)
                #===============================================================
                # print("User Login :         {}".format(user.profile.login))
                # print("Contract End Date :  {}".format((user.profile.contractEndDate).strftime("%Y-%m-%d")))
                # print("Manager ID :         {}".format(user.profile.managerId))
                # print("Current Date :       {}".format(time.strftime("%Y-%m-%d")))              
                #===============================================================

                notifyIn = ((contractEndDate - currentDate).days)
                print("Account " + user.profile.login + " expiring in {} days".format(notifyIn))
        
                if notifyIn <= 6:
                        fromaddr = "oktaAdmin@oktademo.com"
                        toaddr = user.profile.managerId
                        msg = MIMEMultipart()
                        msg['From'] = fromaddr
                        msg['To'] = toaddr
                        msg['Subject'] = "***Alert*** Notification for User Okta Account " + user.profile.firstName + " " + user.profile.lastName + " Deactivation Reminder"
                        body = "<body><div><p><span>Hi " + user.profile.manager + "," + "<p></p></span></p>" + "<p><span> This is to inform you that Okta account of user " + user.profile.firstName + " " + user.profile.lastName + " will soon get deactivated on " + ((user.profile.contractEndDate).strftime("%Y-%m-%d")) + "<p><span>If you experience difficulties accessing your account, you can send a help request to your Okta system administrator.<p></p></span></p><p><span>This is an automatically generated message by Okta. Replies are not monitored or answered.<p></p></span></p><p><span><p>&nbsp;</p></span></p><p><b><span>Regards,<p></p></span></b></p><p><b><span>Okta Admin Team.<p></p></span></b></p><p><p>&nbsp;</p></p></div></body>"
                        msg.attach(MIMEText(body, 'HTML'))
            
                        try:
                            smtpObj = smtplib.SMTP('10.197.55.70', 25)
                            text = msg.as_string()
                            smtpObj.sendmail(fromaddr, toaddr, text)
                            smtpObj.quit()
                            print ("Email was sent to user manager: {}\n".format(user.profile.managerId))
        
                        except SMTPException as error:
                            print ("Error: unable to send email :  {err}".format(err=error))
         
    else:
        break