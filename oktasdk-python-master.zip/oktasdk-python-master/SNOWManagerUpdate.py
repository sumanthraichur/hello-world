try:
    import sys
    import csv
    import re
    import oktaFunctions
    import oktaLogger
    import traceback
    from collections import Counter
    import string
    import json
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName = "mlcinsurance.okta"
fileName = 'C:/Users/debmalya.biswas/Desktop/oktasdk-python-master/manager.csv'
domain = "@ad.mlclife.com.au"
   
    
oktaLogger.logger.info("\n")
oktaLogger.logger.info('Start reading group CSV file')
oktaLogger.logger.info("\n")
try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            
            #============ User Check =================#
            oktaLogger.logger.info("User number : %s in CSV File.", count)
            count=count+1 
            oktaLogger.logger.info("#============ User Check =================#")
            empName = row['Employee User name From ServiceNow']
            empLogin = empName.split(" ")
            #Checking special character in User Firstname
            if re.match("^[a-zA-Z0-9_]*$", empLogin[0]):
                empFN = empLogin[0]
            else:
                empFN = empLogin[0].replace("'", "")
            oktaLogger.logger.info('Employee Firstname: %s', empFN)
            
            #Checking special character in User Lastname
            if re.match("^[a-zA-Z0-9_]*$", empLogin[-1]):
                empLN = empLogin[-1]
            else:
                empLN = empLogin[-1].replace("'", "")
            oktaLogger.logger.info('Employee Lastname: %s', empLN)
            empLogin=empFN+"."+empLN+domain
            
            
            #============ Username count =================#
            valid_letters = string.ascii_letters
            userNameCounter = Counter(empFN+"."+empLN)  # this counts all the letters, including invalid ones
            userNameCount = sum(userNameCounter[letter] for letter in valid_letters) + 1  # add up valid letters
            oktaLogger.logger.info("For user : "+str(empFN.title())+"."+(empLN.title()) +", Username Count is : "+str(userNameCount))
            
            #============ User Search in Okta =================#
            if (userNameCount <= 20):
                listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \"{}\")".format(empLogin)
                userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
                oktaLogger.logger.info("User List : {}".format(userList))
                
                #User not found in OKta
                if not userList:
                    oktaLogger.logger.info('Employee Login: %s not present in Okta', empLogin)
                    oktaLogger.logger.info('Trying to search in Okta again with another User Login approach')
                    empLogin = (empFN.title())+"."+(empLN.title())+domain
                    listUserUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \"{}\")".format(empLogin)
                    userList = oktaFunctions.GetPaginatedResponse(listUserUrl)
                    oktaLogger.logger.info("New User List : {}".format(userList))
                    if not userList:
                        oktaLogger.logger.info('Employee Login: %s still not present in Okta', empLogin)
                        oktaLogger.logger.info('Please check the user : '+str(empFN)+" "+str(empLN)+', manually in Okta')
                        oktaLogger.logger.info('Skipping User Manager Check')
                        oktaLogger.logger.info("\n")
                        continue
                else:
                    oktaLogger.logger.info('Employee Login: %s present in Okta', empLogin)
            
            elif (userNameCount >= 20):
                oktaLogger.logger.info("Username count is more than 20, skipping User Manager Check ")
                oktaLogger.logger.info("Please check AD provisioning for user : "+str(empFN.title())+"."+(empLN.title())+" in Okta Dashboard : "+str("https://"+orgName+".com/admin/tasks"))
                oktaLogger.logger.info("\n")
                continue
            oktaLogger.logger.info("\n")
            
              
            #============ User Manager Check =================#
            oktaLogger.logger.info("#============ User Manager Check =================#")
            managerName = row['Manager Name']
            oktaLogger.logger.info('Manager Display Name: %s', managerName)
            managerLogin = managerName.split(" ")

            #Checking special character in Manager Firstname
            if re.match("^[a-zA-Z0-9_]*$", managerLogin[0]):
                mngrFN = managerLogin[0]
            else:
                mngrFN = managerLogin[0].replace("'", "")
            oktaLogger.logger.info('Manager Firstname: %s', mngrFN)
            
            #Checking special character in Manager Lastname
            if re.match("^[a-zA-Z0-9_]*$", managerLogin[-1]):
                mngrLN = managerLogin[-1]
            else:
                mngrLN = managerLogin[-1].replace("'", "")
            oktaLogger.logger.info('Manager Lastname: %s', mngrLN)
            
            managerLogin=mngrFN+"."+mngrLN+domain
            listMngrUrl = "https://" + orgName + ".com/api/v1/users?filter=(profile.login eq \"{}\")".format(managerLogin)
            mngrList = oktaFunctions.GetPaginatedResponse(listMngrUrl)
            oktaLogger.logger.info("Manager List : {}".format(mngrList))
            if not mngrList:
                managerLogin = (mngrFN.title())+"."+(mngrLN.title())+domain
            oktaLogger.logger.info('Manager Login: %s present in Okta', managerLogin)
            oktaLogger.logger.info("\n")
            
            
            #============ User Manager Update =================#
            oktaLogger.logger.info("#============ User Manager Update =================#")
            for user in userList:
                userId = user["id"]
                profile = user['profile']
                userUrl = "https://" + orgName + ".com/api/v1/users/" + str(userId)
                user_info = {}
                user_info['profile'] = {}
                user_info['profile']['manager'] = managerLogin
                user_info_json = json.dumps(user_info)
    #===========================================================================
    #             response = oktaFunctions.POSTRequest(userUrl, user_info_json)
    #             if response != "Error":
    #                 oktaLogger.logger.info ("Attribute Manager Set to " + str(managerLogin) + " for user " + str(profile["firstName"]) + " " + str(profile["lastName"]))
    #         oktaLogger.logger.info("\n")
    # oktaLogger.logger.info("\n")
    # oktaLogger.logger.info("Updated manager names for users present in CSV.")
    #===========================================================================
    
except Exception as e:
    oktaLogger.logger.info(traceback.format_exc())
