try:
    import sys
    import readFromPropertiesFile
    import logging
    import traceback
    import requests
    import json
    import errno
    import os
    from datetime import datetime
    from ldap3 import Server, Connection
    from ldap3 import *
    import AdTokenDecrypt
    import OktaApiTokenDecrypt
    from datetime import datetime
    from dateutil import tz
    import csv
    import re
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


# Logger File Logic <--> Starts
dateTime = datetime.now().strftime('%d_%m_%Y')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    folderName = "logs/logs_{}".format(dateTime)
    # If folder does not exists create 'logs_<current date>' folder
    if not os.path.exists(folderName):
        os.makedirs(folderName)
except OSError as e:
    if (e.errno != errno.EEXIST):
        raise
    
filename = os.path.basename(__file__)
filename = os.path.splitext(filename)[0]
filename = folderName + "/" + filename + "_" + dateTime + ".log"

# If logger file exists append logger
if os.path.exists(filename):
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

else:
    # creating a file handler
    handler = logging.FileHandler(filename)
    handler.setLevel(logging.INFO)

    # creating a logging format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # adding the handlers to the logger
    logger.addHandler(handler)   

# Logger File Logic <--> Ends   


from_zone = tz.gettz('UTC')
to_zone = tz.gettz('Australia/Sydney')


def zuluToHumanTime(time):
    from_zone = tz.tzutc()
    to_zone = tz.tzlocal()
    string = time
    string = string.replace(".0Z", "")
    string = string[:4] + '-' + string[4:]
    string = string[:7] + '-' + string[7:]
    string = string[:10] + ' ' + string[10:]
    string = string[:13] + ':' + string[13:]
    string = string[:16] + ':' + string[16:]
    utc = datetime.strptime(string, '%Y-%m-%d %H:%M:%S')
    utc = utc.replace(tzinfo=from_zone)
    aest = str(utc.astimezone(to_zone))
    aest = aest.replace("+10:00", "")
    return aest


fileName = "C:/Users/debmalya.biswas/Desktop/UsersSIT.csv"

try:
    ou = "UsersSIT"
    header = ("sAMAccountName,userAccountControl,ou")
    filename = 'C:/Users/debmalya.biswas/Desktop/AD/UsersAD'+str(ou)+'.csv'
    if os.path.exists(filename):
        logger.info("File exists")
    elif not os.path.exists(filename):
        logger.info("File does not exists, creating new file")
        file = open(filename, 'w+')
        file.write(header)
        file.write('\n')
    
    search_base = "DC=ad,DC=mlclife,DC=com,DC=au"
    hostName = "ad.mlclife.com.au"
    username = "mlcl\svc-OktaADAgent"
     
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            logger.info("Group number : %s in CSV File.", count)
            count=count+1 
            logger.info("#============ Group Name =================#")
            login = row['login']
            logger.info("login ::"+str(login))  
            search_filter = "(userPrincipalName="+str(login)+")"
            logger.info("AD search filter :: "+search_filter)
            with Connection(Server(hostName, port=389, get_info=all), user=username, password=AdTokenDecrypt.adKeyDecoded) as c:
                c.search(search_base=search_base, search_filter=search_filter, attributes=['sAMAccountName','userAccountControl','whenChanged'])
                response = (c.response_to_json())
                json_response = json.loads(response)
                lst=[]
                for entry in json_response['entries']:
                    attributes = entry['attributes']
                    logger.info(attributes)
                    dn = entry['dn']
                    logger.info("DN :: "+str(dn))
                    lst.append(dn)
                    strl = ','.join(lst)
                    line = re.sub(',DC=ad,DC=mlclife,DC=com,DC=au', '', strl)
                    line = line.split(",")
                    line.pop(0)
                    lineLen = len(line)
                    if lineLen == 1:
                        line.insert(0,"")
                        line.insert(1,"")
                        line.insert(2,"")
                        ou = ','.join(line)
                        logger.info("OU :: "+str(ou))
                    elif lineLen == 2:
                        line.insert(0,"")
                        line.insert(1,"")
                        ou = ','.join(line)
                        logger.info("OU :: "+str(ou))
                    elif lineLen == 3:
                        line.insert(0,"")
                        ou = ','.join(line)
                        logger.info("OU :: "+str(ou))
                    else:
                        ou = ','.join(line)
                        logger.info("OU :: "+str(ou))                                          
                    for sAMAccountName in attributes['sAMAccountName']:
                        logger.info('sAMAccountName :' + sAMAccountName)                
                    for whenChanged in attributes['whenChanged']:
                        whenChanged = zuluToHumanTime(whenChanged)
                        logger.info('whenChanged :' + whenChanged)
                    for userAccountControl in attributes['userAccountControl']:
                        logger.info('userAccountControl :' + userAccountControl)
                        logger.info('\n')                        
                        addingValues = '{},{},{}'.format(sAMAccountName,userAccountControl,ou)
    
                        # Amending with user values to the csv
                        with open(filename, "a") as file:
                            file.write(addingValues)
                            file.write('\n')
                        file.close()  
                   
except Exception as e:
    logger.info(traceback.format_exc())
