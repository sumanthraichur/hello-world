class TempPassword:

    types = {
        'tempPassword': str
    }

    def __init__(self):

        self.tempPassword = None  # str
