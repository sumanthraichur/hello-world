import unittest
import os
import json

from okta import EventsClient

class EventsClientTest(unittest.TestCase):

    def tests_client_initializer_args(self):
        client = EventsClient('https://dev-530347.oktapreview.com', '00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq')

    def tests_client_initializer_kwargs(self):
        client = EventsClient(base_url='https://dev-530347.oktapreview.com', api_token='00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq')
