try:   
    import requests
    from urllib.request import urlopen
    import json
    import logging
    from pprint import pprint
    import requests
    import okta
    import sys
    import itertools
    import numpy as np
    import csv
    from okta import UsersClient
    from okta.models.user import User
    from okta.models.user import UserProfile
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()



apiKey = "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq"
apiUrl = "https://dev-530347.oktapreview.com"
adGid = "00gajjoz9cHY525Hk0h7"
muleSoftGid = "00gaj3yg4rrwxHE9z0h7"
aDurl = apiUrl + "/api/v1/groups/" + adGid + "/users/"
muleSofturl = apiUrl + "/api/v1/groups/" + muleSoftGid + "/users/"
print("Active Directory Provisioning Group Okta Postman URL : {}".format(aDurl))
print("Mulesoft Group Okta Postman URL : {}\n".format(muleSofturl))


headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + apiKey,
    'cache-control': "no-cache"
    }

responseAd = requests.request("GET", aDurl, headers=headers)
json_dataAd = json.loads(responseAd.text)

responseMuleSoft = requests.request("GET", muleSofturl, headers=headers)
json_dataMuleSoft = json.loads(responseMuleSoft.text)

print("List Of User present in AD")
for itemAd in json_dataAd:
    adUserId = '{}'.format(itemAd['id'])
    adList = []
    adList = adUserId
    print(adList)
print("\n")

print("List Of User present in MuleSoft")       
for itemMuleSoft in json_dataMuleSoft:
    muleSoftUserId = '{}'.format(itemMuleSoft['id'])
    muleList = []
    muleList = muleSoftUserId
    print(muleList)
print("\n")
    
if (adList == muleList) is False:
    outputlist = []
    FinalList = adList + muleList
    FinalList = [x for x in FinalList if x not in muleList]
    
    for i in range(0, len(FinalList)):
        if ((FinalList[i] not in adList) or (FinalList[i] not in muleList)) and (FinalList[i] not in outputlist):
                outputlist[len(outputlist):] = [FinalList[i]]
                muleUserId = ''.join(FinalList[i])
                
                muleSoftAnypointPlatformUrl = apiUrl + "/api/v1/groups/" + muleSoftGid + "/users/" + muleUserId
                print("MuleSoft - Anypoint Platform Okta Postman : {} URL ".format(muleSoftAnypointPlatformUrl))
                response = requests.request("PUT", muleSoftAnypointPlatformUrl, headers=headers)
                print("Users : {} added to MuleSoft - Anypoint Platform group \n".format(muleUserId))
                print(response.text)
                
elif (adList == muleList) is True:
    print ("No more Users to add to MuleSoft - Anypoint Platform group")