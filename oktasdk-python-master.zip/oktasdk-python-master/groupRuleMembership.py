try:
    import requests
    import okta
    import sys
    from okta import UsersClient
    from okta.models.user import User
    from okta.models.user import UserProfile
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()
    
apiKey = "00LJYP8KYNTu6laQdakudsHbr8tG16gzSyIXHjN6Bq"
apiUrl = "https://dev-530347.oktapreview.com" 
usersClient = UsersClient(apiUrl, apiKey)
users = usersClient.get_users()
url = apiUrl + "/api/v1/groups/rules"
print ("Application URL to create group rules : {}\n".format(url))

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS " + apiKey,
    'cache-control': "no-cache"
    }

payload = "{\n\"type\":\"group_rule\",\n\"name\":\"Manager group rule\",\n\"conditions\":{\n\"people\":{\n\"users\":{\n\"exclude\":[]\n },\n\"groups\":{\n\"exclude\":[]\n }\n},\n\"expression\": {\n\"value\":\"user.login==\\\"david.jones@oktatrial.com\\\"\",\n \"type\":\"urn:okta:expression:1.0\"\n}\n},\n\"actions\":{\n\"assignUserToGroups\":{\n\"groupIds\":[\n\"00gaj3yg4rrwxHE9z0h7\"\n]\n}\n}\n}"
while True:
    for user in users :
            if (user.profile.managerId) is not None :
                print("User Login :         {}".format(user.profile.login))
                print("Manager ID :         {}\n".format(user.profile.managerId))
                
    else:
        break
