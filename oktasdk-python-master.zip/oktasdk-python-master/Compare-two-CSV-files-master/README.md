# Compare two .CSV files  [![Build Status](https://travis-ci.org/H-Darji/Compare-two-CSV-files.svg?branch=master)](https://travis-ci.org/H-Darji/Compare-two-CSV-files)
- Simple **Python program** that **compares two .CSV files** and **inserts matched rows in third(or new) .CSV file**.<br>
- Both **sample** .CSV files that I used contains just few records, so user may **need to change** this program **based on his/her needs**.
