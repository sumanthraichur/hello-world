try:
    import sys
    import csv
    import oktaFunctions
    import oktaLogger
    import traceback
    import oktaPayLoad
    import os
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


orgName = "mlclimited-prodsup.oktapreview"
orgNameAdmin = "mlclimited-prodsup-admin.oktapreview"
fileName = 'C:/Users/debmalya.biswas/Desktop/OktaExternalgroupPush.csv'
grpUrl = "https://"+orgName+".com/api/v1/groups"



logger = oktaLogger.loggerFilename(os.path.basename(__file__))    
logger.info("\n")
logger.info('Start reading group CSV file')
logger.info("\n")    
    
try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            logger.info("Group number : %s in CSV File.", count)
            count=count+1 
            logger.info("#============ Group Name Check =================#")
            grpName = row['Group Name']
            logger.info("Group Name ::"+str(grpName))
            
            grpDesc = row['Group Description']
            logger.info("Group description ::"+str(grpDesc))
            
            groupPayLoad = oktaPayLoad.oktaGroupPayLoad(grpName, grpDesc)
            #Create group in Okta
            groupResponse = oktaFunctions.POSTRequest(grpUrl, groupPayLoad)
            if groupResponse != "Error":
                logger.info ("Group "+str(grpName)+" is created in Okta")
                logger.info ("\n")
                            
            querystring = {"q":""+str(grpName)+""}
            groupResponse = oktaFunctions.GETGroupRequest(grpUrl, querystring)
            for group in groupResponse:
                userGroupId = group["id"]
                pushPayLoad = oktaPayLoad.oktaExternalGroupPushPayLoad(userGroupId)
                logger.info ("Okta External Push Group Payload :: \n"+str(pushPayLoad))
                oktaExtAppUrl = "https://"+orgName+".com/api/v1/apps?q=Okta External"
                oktaExtAppList = oktaFunctions.GETObject(oktaExtAppUrl)
                for oktaExt in oktaExtAppList:
                    oktaExtId = oktaExt["id"]
                    pushGrpUrl = "https://"+orgNameAdmin+".com/api/internal/instance/"+str(oktaExtId)+"/grouppush"
                    logger.info ("Push Group URL :: "+str(pushGrpUrl))
                    #Push group in Okta External
                    pushResponse = oktaFunctions.POSTRequest(pushGrpUrl, pushPayLoad)
                    if pushResponse != "Error":
                        logger.info ("Group "+str(grpName)+" pushed to Okta External")
                        logger.info ("\n")
            
except Exception as e:
    logger.info(traceback.format_exc())