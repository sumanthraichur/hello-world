try:   
    import sys
    import csv
    import requests
    import logging
    import json
    import re
    import os
    from datetime import datetime
    import errno
    import traceback
    import readFromPropertiesFile
    import OktaApiTokenDecrypt
    import oktaLogger
except:
    print("Please install okta/Python libaries. Refer to documentation for help")
    sys.exit()


logger = oktaLogger.loggerFilename(os.path.basename(__file__))
orgName = "mlclimited.oktapreview"

oktaUrl = "https://" + orgName + ".com"
grpUrl = "https://" + orgName + ".com/api/v1/groups"
ruleUrl = "https://" + orgName + ".com/api/v1/groups/rules"
fileName = "C:/Users/debmalya.biswas/Desktop/mlcDependantRuleCreation.csv"

logger.info("\n")
logger.info('Start reading group CSV file')

headers = {
    'accept': "application/json",
    'content-type': "application/json",
    'authorization': "SSWS 00pCgoznpH2YD1vE4PFdHpFXCDm0ncUFUgIs90Hiih"
    }


def POSTRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers, verify=False)
    else:
        response = requests.post(url, headers=headers, verify=False)
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()



def POSTRuleRequest(url, data):
    if data != "":
        response = requests.post(url, data=data, headers=headers, verify=False)
    else:
        response = requests.post(url, headers=headers, verify=False)
    responseJSON = response
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response


def GETRequest(url,params):
    if params!="":
        response = requests.request("GET", url,params=querystring, headers=headers, verify=False)
    else:
        response = requests.request("GET",url, headers=headers, verify=False)    
    responseJSON = response.json()
    if "errorCode" in responseJSON:
        logger.info ("\nYou encountered following Error: \n")
        logger.info (responseJSON)
        logger.info ("\n")
        return "Error"
    else:
        return response.json()

try:
    count=1
    with open(fileName, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            #============ User Check =================#
            logger.info("Group number : %s in CSV File.", count)
            count=count+1 
            logger.info("#============ Group Name =================#")
            grpName = row['Group Name']
            logger.info("Group Name ::"+str(grpName))
            casGroupName=None
            grpCasName = re.split(r',', grpName)
            logger.info("Cascading Group Name: {}".format(grpCasName))
            for i, valueOfGroup in enumerate(grpCasName):
                querystring = {"q":"" + valueOfGroup}
                response = GETRequest(grpUrl, querystring)
                for item in response:
                    cascadeGroupUserId = item['id']
                    cascadeGroupList = []
                    cascadeGroupList = (cascadeGroupUserId)
                    grpCascading = (cascadeGroupList) 
                if casGroupName is None:
                    casGroupName = '\\"' + grpCascading + '\\",'
                elif casGroupName is not None:
                    casGroupName += '\\"' + grpCascading + '\\",'
                  
            casGroupName = re.sub(',$', ')', casGroupName)
            logger.info("Parent Groups: {}".format(casGroupName))
            
            
            grpDep = row['Dependent Groups']
            cascadeGroupName=None
            grpCascadingName = re.split(r',', grpDep)
            logger.info("Cascading Group Name: {}".format(grpCascadingName))
            for i, valueOfGroup in enumerate(grpCascadingName):
                querystring = {"q":"" + valueOfGroup}
                response = GETRequest(grpUrl, querystring)
                for item in response:
                    cascadeGroupUserId = item['id']
                    cascadeGroupList = []
                    cascadeGroupList = (cascadeGroupUserId)
                    grpCascading = (cascadeGroupList) 
                if cascadeGroupName is None:
                    cascadeGroupName = '"' + grpCascading + '",'
                elif cascadeGroupName is not None:
                    cascadeGroupName += '"' + grpCascading + '",'
                  
            cascadeGroupName = re.sub(',$', '', cascadeGroupName)
            logger.info("Dependent Groups: {}".format(cascadeGroupName))
             
            payload = "{\n        \"type\": \"group_rule\",\n        \"status\": \"INACTIVE\",\n        \"name\": \""+str(grpName)+" Rule" "\",\n        \"conditions\": {\n            \"expression\": {\n                \"value\": \"isMemberOfAnyGroup("+str(casGroupName)+"\",\n                \"type\": \"urn:okta:expression:1.0\"\n            }\n        },\n        \"actions\": {\n            \"assignUserToGroups\": {\n                \"groupIds\": [\n                    "+str(cascadeGroupName)+"\n                ]\n            }\n        }\n    }"
            logger.info("Dependent Group Rule Payload : {}".format(payload))          
                  
            responseRule = POSTRequest(ruleUrl, payload)
            logger.info("Attribute Rule creation response : {}".format(responseRule))
            logger.info("{} Rule Created".format(grpName))
            seacrhRule = responseRule['id']
            ruleList = []
            ruleList = seacrhRule
            logger.info("Searched Rule ID : {}".format(ruleList))
                        
            activateRuleUrl = ruleUrl + "/" + ruleList + "/lifecycle/activate"
            logger.info("Rule activation URL : {}".format(activateRuleUrl))
            response = POSTRuleRequest(activateRuleUrl, payload)
            logger.info ("{} Rule Activated".format(grpName))
            logger.info("\n")            

except Exception as e:
    logger.info(traceback.format_exc())